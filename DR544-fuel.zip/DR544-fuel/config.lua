Config = {}

-- Ausführliche Debug-Prints (z.B. jeder Verbrauchs-Tick) nur bei true in
-- der Konsole anzeigen. Für den normalen Betrieb aus lassen.
Config.Debug = false

Config.Framework = 'esx'
Config.PaymentAccount = 'bank'

-- Konto, auf das die Steuer (siehe Config.TaxRate) beim Tanken fließt.
-- ANPASSEN falls dein Server einen anderen Society-Account für den Staat
-- nutzt (z.B. 'society_government' bei manchen ESX-Ablegern).
Config.GovernmentAccount = 'society_government'

-- ============================================================
-- FAHRZEUG-TANKSTAND (Ersatz für LegacyFuel)
-- ============================================================

-- Tankstand wird 0-100 (Prozent) geführt, wie bei LegacyFuel.
Config.DefaultFuelLevel = 100.0

-- Basis-Verbrauch pro Sekunde (in Fuel-Prozent) bei konstant hoher
-- Drehzahl/Geschwindigkeit. Wird in client/main.lua mit RPM/Speed skaliert.
--
-- FAUSTREGEL/HERLEITUNG (normale, an LegacyFuel-Standardwerte angelehnte
-- Balance): Der Verbrauchs-Thread tickt 1x/Sekunde und multipliziert diese
-- Basisrate mit rpmFactor (0.3 - 1.0) * speedFactor (1.0 - 1.5) *
-- Klassen-Multiplikator. Bei gemischtem Fahrverhalten (Stadt+Landstraße,
-- Durchschnitt rpmFactor*speedFactor ~ 0.81) und einem Standard-PKW
-- (classMult 1.0) ergibt 0.045 einen vollen Tank (100%) von ca.
-- 100 / (0.045 * 0.81) ≈ 2740 Sekunden ≈ 46 Minuten aktive Fahrzeit -
-- also im gewünschten 40-70-Minuten-Fenster, weder "in wenigen Minuten
-- leer" noch "hält ewig". Bei Vollgas/hoher Drehzahl (Faktor bis 1.5)
-- sinkt das auf ca. 30 Minuten, im reinen Leerlauf hält der Tank deutlich
-- länger. Nachjustieren: höher = schnellerer Verbrauch.
Config.FuelConsumptionRate = 0.045

-- Verbrauchs-Multiplikator je nach Fahrzeugklasse (GetVehicleClass).
-- Fehlt eine Klasse hier, wird 1.0 (Standard) angenommen.
Config.FuelConsumptionClassMultiplier = {
    [0] = 0.9,  -- Compacts
    [2] = 1.3,  -- SUVs
    [6] = 0.8,  -- Muscle
    [8] = 0.6,  -- Motorräder
    [9] = 1.6,  -- Offroad
    [12] = 2.4, -- LKW
    [14] = 2.0, -- Boote (falls relevant)
    [16] = 2.8, -- Industrie/Baufahrzeuge
    [18] = 2.2, -- Nutzfahrzeuge
    [19] = 3.5, -- Militär/Panzer
    [20] = 1.4, -- Kombis
}

-- Ab diesem Fuel-Level (Prozent) beginnt der Motor zu stottern
-- (RandomEngineDamage), unterhalb von 0 wird der Motor komplett blockiert.
-- 8% ist normale LegacyFuel-Faustregel (Reserve-Warnung kurz vor leer).
Config.LowFuelThreshold = 8.0
Config.BlockEngineWhenEmpty = true

-- Elektrofahrzeuge werden von wcc_fuel komplett ignoriert (kein Verbrauch,
-- kein Motor-Block, keine Zapfpistolen-Interaktion) - die gehören
-- ausschließlich wcc_chargingstations. WICHTIG: diese Liste MUSS synchron
-- zu wcc_chargingstations/config.lua (Config.ElectricVehicleModels)
-- gehalten werden - bei neuen E-Auto-Modellen an BEIDEN Stellen ergänzen.
Config.ElectricVehicleModels = {
    'neon',
    'khamelion',
    'raiden',
    'tezeract',
    'cyclone2',
    'voltic',
    'voltic2',
    'imorgon',
    'dilettante2',
    'surge',
    'powersurge',
    'rcv',
    'gblod4',
    'teslapd',
    'ikx3rebel22'
}

-- Wie oft (ms) der Client den aktuellen Tankstand ans Server-Kompat-Save
-- meldet bzw. lokal in owned_vehicles/eigene Tabelle persistiert.
Config.FuelSaveInterval = 60000

-- LegacyFuel-Kompatibilität: Andere Ressourcen (z.B. HUD-Scripts), die
-- noch `LegacyFuel:GetFuel` / `LegacyFuel:SetFuel` Events oder
-- `exports['LegacyFuel']:GetFuel` erwarten, funktionieren über die in
-- client/main.lua registrierten Kompat-Handler unverändert weiter.
Config.EnableLegacyFuelCompat = true

-- ============================================================
-- TANKSTELLEN (Standard GTA-Tankstellen ohne Zapfsäulen-Prop)
-- ============================================================

-- Allgemeine "bin ich an der Station"-Distanz (Kauf/Boss/Job/Abladen, siehe
-- client/markers.lua + server-seitige IsPlayerNearCoords-Prüfungen).
Config.MaxDistanceToPump = 8.0

-- ============================================================
-- TANKEN ALS PROP/ROPE/LIVE-SESSION (wie E-Auto-Laden in wcc_chargingstations)
-- ============================================================

-- Vanilla-GTA-Prop (kein eigener Stream nötig) für die "Zapfpistole" als
-- Hand-Prop, sobald der Spieler sie nimmt/einsteckt.
Config.CableNozzleProp = 'prop_cs_fuel_nozle'

-- Bekannte Vanilla-GTA-V-Zapfsäulen-Prop-Modelle. Es werden KEINE eigenen
-- Props mehr gespawnt - stattdessen dienen die bereits im Map-Streaming
-- vorhandenen, echten Tankstellen-Zapfsäulen selbst als ox_target-Ziel
-- (siehe client/target.lua, client/pump_resolver.lua). WICHTIG: das ist nur
-- eine Startliste - manche dieser Modelle funktionieren ggf. nicht
-- zuverlässig mit ox_target (z.B. weil sie Teil eines zusammengesetzten
-- Map-Objekts/LOD sind statt eines eigenständigen CObject). Im Zweifel
-- ingame mit `/fuelscanpumps` (siehe client/debug.lua) prüfen, welche
-- Modelle tatsächlich erkannt/zugeordnet werden, und die Liste danach
-- anpassen/erweitern.
Config.KnownPumpModels = {
    'prop_gas_pump_1a',
    'prop_gas_pump_1b',
    'prop_gas_pump_1c',
    'prop_gas_pump_1d',
    'prop_gas_pump_2a',
    'prop_gas_pump_2b',
    'prop_gas_pump_2c',
    'prop_gas_pump_2d',
    'prop_gas_pump_old1',
    'prop_gas_pump_old2',
}

-- Radius (Meter) um cfg.coords einer Station, in dem ein gefundenes
-- Zapfsäulen-Prop dieser Station zugeordnet wird (nächstgelegene Station,
-- siehe WF_FindStationByPumpEntity in client/pump_resolver.lua). Liegt
-- kein Prop innerhalb des Radius um eine Station, gibt es dort keine
-- Interaktion.
Config.PumpStationLinkRadius = 50.0

-- License des einzigen Spielers, der den Debug-Befehl `/fuelscanpumps`
-- nutzen darf (server-seitig geprüft, siehe server/main.lua).
Config.DebugAdminLicense = 'license:7983531ed736c3986d460c1a40cacdafa741443c'

-- Wie weit man sich von der Zapfpistole/Pumpe entfernen darf, während man
-- sie in der Hand trägt (noch nicht eingesteckt) - klein gehalten, analog
-- Config.MaxDistanceFromCharger bei wcc_chargingstations.
Config.MaxDistanceFromPump = 7.5

-- Wie viele Sekunden ein Tankvorgang von 0 auf 100% Tankfüllung braucht
-- (linear hochgerechnet), analog Config.MaxFullChargeSeconds beim Laden.
-- 50s für 100% = 5s pro 10%.
Config.MaxFullTankSeconds = 50

-- Intervall (Sekunden) des serverseitigen Abrechnungs-Threads während einer
-- laufenden Tank-Session.
Config.RefuelBillingInterval = 5

-- Preisspanne für Stationen OHNE Besitzer: jede dieser Stationen bekommt
-- beim ersten Laden (bzw. nach einer Enteignung) einmalig einen zufälligen,
-- danach STABILEN Preis aus dieser Spanne (siehe WccFuel_RandomOwnerlessPrice
-- in server/main.lua) - nicht bei jeder Anfrage neu gewürfelt.
Config.OwnerlessFuelPriceMin = 13.0
Config.OwnerlessFuelPriceMax = 18.0

-- Grenzen für den vom Besitzer im Boss-Menü frei wählbaren Preis
Config.MinOwnerFuelPrice = 12.0
Config.MaxOwnerFuelPrice = 100.0

-- Wie viel Liter ein voller Tankvorgang durchschnittlich braucht (Standard-
-- Fahrzeugtank), rein zur Umrechnung Fuel-Prozent <-> Liter.
Config.LitersPerFullTank = 65.0

-- Steuer, die bei jedem Tankvorgang an eine Tankstelle MIT Besitzer an den
-- Staat geht. Der Rest (1 - TaxRate) geht in die Bank der Tankstelle.
Config.TaxRate = 0.30

-- ============================================================
-- KAUF / BESITZ
-- ============================================================

Config.MaxStationsPerPlayer = 3

-- ============================================================
-- LEVEL-SYSTEM (max Level 10)
-- ============================================================

Config.MaxStationLevel = 10

-- Tank-Kapazität (Liter) der Station je Level. Linear von 5.000L (Level 1)
-- bis 50.000L (Level 10) skaliert (Schrittweite 5.000L pro Level).
Config.StationTankCapacityByLevel = {
    [1] = 5000,   [2] = 10000,  [3] = 15000,  [4] = 20000,  [5] = 25000,
    [6] = 30000,  [7] = 35000,  [8] = 40000,  [9] = 45000,  [10] = 50000,
}

-- Kosten für ein Level-Up (Index = Ausgangslevel, z.B. [1] = Kosten für
-- Level 1 -> 2). Leicht gestaffelt/exponentiell von 10.000$ bis 150.000$.
Config.StationLevelUpCost = {
    [1] = 10000,  [2] = 17000,  [3] = 27000,  [4] = 40000,
    [5] = 55000,  [6] = 75000,  [7] = 100000, [8] = 125000,
    [9] = 150000,
}

-- LKW-Ladekapazität (Liter) je LKW-Level, separat upgradebar.
-- Von 1.000L (Level 1) bis 7.500L (Level 10).
Config.TruckCapacityByLevel = {
    [1] = 1000,  [2] = 1725,  [3] = 2445,  [4] = 3165,  [5] = 3890,
    [6] = 4610,  [7] = 5335,  [8] = 6055,  [9] = 6780,  [10] = 7500,
}

-- Kosten für ein LKW-Level-Up (Index = Ausgangslevel)
Config.TruckLevelUpCost = {
    [1] = 5000,  [2] = 8500,  [3] = 13500, [4] = 20000,
    [5] = 28000, [6] = 38000, [7] = 50000, [8] = 64000,
    [9] = 80000,
}

-- Kommunikations-Level (separat vom Stations-/Tank- und LKW-Level):
-- bestimmt, WIE NAH die zufälligen Job-Abholpunkte liegen (siehe
-- GetJobPickupGroupForLevel in server/job.lua) - Level 1 (Standard, kein
-- Upgrade nötig) = immer die 3 am weitesten entfernten Punkte, Level 10 =
-- die 3 nächstgelegenen. Kosten analog zu den anderen Upgrade-Tracks.
Config.CommsLevelUpCost = {
    [1] = 8000,   [2] = 14000,  [3] = 22000,  [4] = 32000,
    [5] = 44000,  [6] = 58000,  [7] = 75000,  [8] = 95000,
    [9] = 120000,
}

-- ============================================================
-- TANKSTELLEN-BANK
-- ============================================================

Config.MaxDepositPerTransaction = 30000
Config.DepositCooldownSeconds = 12 * 3600 -- 12 Echtzeit-Stunden

-- ============================================================
-- INAKTIVITÄTS-REFUND
-- ============================================================

-- Ist der Stationstank Config.EmptyRefundDays Tage AM STÜCK bei 0 Litern,
-- verliert der Besitzer die Station automatisch (siehe server/stations.lua
-- CheckInactiveStations). Es zählt ausschließlich "Tank leer", NICHT ob
-- der Besitzer online/aktiv ist.
Config.EmptyRefundDays = 3

-- Wie oft (ms) der Server den Inaktivitäts-Check durchführt.
Config.InactivityCheckInterval = 30 * 60 * 1000 -- alle 30 Minuten

-- Verhalten bei Verlust der Station (Default-Entscheidung, siehe README):
-- Der Besitzer bekommt das aktuelle Bank-Guthaben der Station als Restwert
-- auf sein Bankkonto ausgezahlt (fair, verhindert Frust bei Serverneustart-
-- Pech), danach wird die Bank auf 0 zurückgesetzt und die Station komplett
-- auf Standard (kein Besitzer, Standardname/-preis/-blip) zurückgesetzt.
Config.RefundBankOnRepossession = true

-- ============================================================
-- MITARBEITER / LÖHNE
-- ============================================================

Config.MaxEmployeesPerStation = 3

-- Default-Intervall für neue/bestehende Stationen ohne eigenen Wert, sowie
-- die im Boss-Menü (NUR vor Ort, NUR Besitzer) wählbaren Intervalle für die
-- automatische Lohn-Auszahlung (auch an offline Mitarbeiter). 1h = Minimum.
Config.DefaultWageIntervalHours = 12
Config.WageIntervalOptions = { 1, 3, 6, 12, 24 }

-- ============================================================
-- TRUCKING-JOB
-- ============================================================

Config.JobTruckModel = 'packer'
Config.JobTrailerModel = 'tanker'
Config.JobLoadDuration = 12000 -- ms Ladezeit-Progressbar am Abholpunkt
Config.JobUnloadDuration = 8000 -- ms Abladezeit-Progressbar an der Station
Config.JobMaxDistanceToPoint = 12.0

-- Strafe (aus der Tankstellen-Bank, NICHT vom Spieler), wenn der Miet-LKW
-- oder -Anhänger während eines laufenden Jobs zerstört wird/verschwindet.
-- Wird nie über den aktuellen Bank-Kontostand hinaus abgezogen (Bank kann
-- dadurch nicht ins Minus rutschen) - siehe server/job.lua.
Config.JobVehicleLossPenalty = 1000

-- Flacher Pool aller Abholpunkte (Koordinaten/Labels unverändert gegenüber
-- vorher, nur nicht mehr fest einem Level zugeordnet) - welche 3 Punkte ein
-- Level tatsächlich bekommt, wird jetzt PRO STATION dynamisch anhand der
-- Entfernung berechnet (siehe GetJobPickupGroupForLevel in server/job.lua):
-- Level 1 = die für DIESE Station am weitesten entfernte Dreiergruppe,
-- jedes höhere Level eine näher gelegene - unabhängig davon, wo auf der
-- Karte die Station selbst liegt (Station in Paleto -> Level 1 tendenziell
-- Richtung Süden/Hafen; Station am Würfelpark -> Level 1 tendenziell
-- Richtung Paleto/Norden, jeweils das für DIESE Station am weitesten
-- entfernte Ziel). Die Koordinaten liegen an plausiblen Industrie-/
-- Ölfeld-/Hafen-Arealen der GTA-V-Karte; sie müssen laut Vorgabe nicht
-- pixelgenau sein.
Config.JobPickupPoints = {
    { coords = vec4(2535.4209, 2586.7151, 37.9448, 206.8727), label = 'Ölfeld Grand Senora' },
    { coords = vec4(2687.1338, 2763.6213, 37.8780, 214.6214), label = 'Ölfeld Grand Senora Nord' },
    { coords = vec4(2362.4238, 3074.0586, 48.1765, 90.9496), label = 'Ölfeld Grand Senora West' },
    { coords = vec4(1996.6765, 3061.4524, 47.0491, 237.7454), label = 'Ölfeld Sandy Shores' },
    { coords = vec4(21649.8373, 3523.1113, 35.8538, 28.8875), label = 'Ölfeld Sandy Shores Ost' },
    { coords = vec4(1373.7396, 3619.3206, 34.8895, 353.0008), label = 'Ölfeld Sandy Shores Süd' },
    { coords = vec4(44.9227, 6295.9551, 31.2403, 102.6358), label = 'Paleto Industrie' },
    { coords = vec4(-512.8063, 5243.3916, 80.3047, 285.2420), label = 'Paleto Sägewerk' },
    { coords = vec4(-179.9542, 6255.6641, 31.4866, 319.1246), label = 'Paleto Lager' },
    { coords = vec4(-1705.9751, 2947.9639, 32.8642, 262.1175), label = 'Route 68 Raffinerie' },
    { coords = vec4(-92.4375, 2799.5618, 53.3215, 276.5970), label = 'Route 68 Raffinerie Nord' },
    { coords = vec4(820.1010, 2182.7559, 52.2991, 155.5084), label = 'Route 68 Raffinerie West' },
    { coords = vec4(1108.5281, -3295.4883, 5.8972, 88.2281), label = 'Elysian Island Raffinerie' },
    { coords = vec4(637.0724, -2760.3198, 6.0907, 121.1065), label = 'Elysian Island Tanklager' },
    { coords = vec4(542.0248, -2742.0339, 6.0556, 104.8873), label = 'Elysian Island Hafenbecken' },
    { coords = vec4(-801.3424, -2860.3115, 13.9474, 87.1260), label = 'LS Terminal' },
    { coords = vec4(-866.6955, -3010.7996, 13.9657, 330.5118), label = 'LS Terminal Süd' },
    { coords = vec4(-554.5855, -2321.2205, 13.7792, 135.1006), label = 'LS Terminal Nord' },
}

-- ============================================================
-- TANKSTELLEN-STANDORTE (Standard-GTA-Tankstellen, ~30 Stück)
-- ============================================================
-- coords = Position der ox_target-Interaktionszone an der Zapfsäule
-- (keine eigenen Props - es wird die vorhandene GTA-Tankstelle genutzt).
-- blipCoords = Position des Karten-Blips.
-- buyPrice = Kaufpreis (200.000 - 400.000$, je nach Lage der Station).
-- jobTruckSpawnCoords = vec4(x, y, z, heading), wo der Miet-LKW+Anhänger für
-- den Trucking-Job spawnt. Standardmäßig (0,0,0,0) = Platzhalter, dann
-- spawnt der LKW ersatzweise direkt neben coords (siehe client/job.lua).
-- Bitte pro Station ingame einen freien Platz suchen und hier eintragen.
-- buyMarkerCoords = vec4(x, y, z, heading), wo der [E]-Kauf-Marker steht
-- (idealerweise vor dem Tankstellen-Gebäude/Shop). Standardmäßig (0,0,0,0)
-- = Platzhalter, dann weicht der Marker auf eine grobe Position neben
-- coords aus (siehe Schleife weiter unten).
Config.Stations = {
    { id = 1,  name = 'Route 68 Tankstelle',        coords = vec3(49.4, 2778.6, 58.0),      blipCoords = vec3(49.4, 2778.6, 58.0),      buyPrice = 210000, jobTruckSpawnCoords = vec4(41.4343, 2802.1187, 57.8782, 144.7015), buyMarkerCoords = vec4(46.3791, 2789.1106, 57.8783, 328.2935) },
    { id = 2,  name = 'Route 68 Tankstelle Süd',     coords = vec3(263.5, 2606.5, 44.9),     blipCoords = vec3(263.5, 2606.5, 44.9),     buyPrice = 215000, jobTruckSpawnCoords = vec4(242.6189, 2598.5068, 45.1498, 105.9854), buyMarkerCoords = vec4(265.9724, 2598.4797, 44.8150, 17.9163) },
    { id = 3,  name = 'Harmony Tankstelle',          coords = vec3(1207.5458, 2659.6711, 37.8997),    blipCoords = vec3(1207.5458, 2659.6711, 37.8997),    buyPrice = 240000, jobTruckSpawnCoords = vec4(1211.1708, 2646.6360, 37.8321, 335.6346), buyMarkerCoords = vec4(1202.0100, 2655.6692, 37.8519, 155.1306) },
    { id = 4,  name = 'Grapeseed Tankstelle',        coords = vec3(1687.2371, 4929.8394, 42.0782),    blipCoords = vec3(1687.2371, 4929.8394, 42.0782),    buyPrice = 235000, jobTruckSpawnCoords = vec4(1693.5839, 4917.2241, 42.0781, 57.8784), buyMarkerCoords = vec4(1707.0334, 4919.2896, 42.0637, 207.4175) },
    { id = 6,  name = 'Paleto Bay Tankstelle',         coords = vec3(179.5, 6602.7, 31.8),     blipCoords = vec3(179.5, 6602.7, 31.8),     buyPrice = 245000, jobTruckSpawnCoords = vec4(122.5618, 6657.5078, 31.6649, 311.6450), buyMarkerCoords = vec4(161.9454, 6636.5200, 31.5599, 58.4842) },
    { id = 7,  name = 'Grand Senora Tankstelle',     coords = vec3(2004.9, 3773.6, 32.4),    blipCoords = vec3(2004.9, 3773.6, 32.4),    buyPrice = 230000, jobTruckSpawnCoords = vec4(1984.6178, 3755.2700, 32.1740, 204.9244), buyMarkerCoords = vec4(2002.0880, 3779.7373, 32.1808, 80.9147) },
    { id = 8,  name = 'Sandy Shores Tankstelle',     coords = vec3(1785.2574, 3330.4380, 41.3783),    blipCoords = vec3(1785.2574, 3330.4380, 41.3783),    buyPrice = 225000, jobTruckSpawnCoords = vec4(1775.9762, 3348.2705, 40.5744, 313.9740), buyMarkerCoords = vec4(1776.6595, 3327.3650, 41.4333, 248.3801) },
    { id = 9,  name = 'Grand Senora Desert Ost',     coords = vec3(2679.9, 3264.2, 55.2),    blipCoords = vec3(2679.9, 3264.2, 55.2),    buyPrice = 220000, jobTruckSpawnCoords = vec4(2656.9910, 3245.6719, 54.7264, 221.8477), buyMarkerCoords = vec4(2674.8047, 3288.4314, 55.2412, 34.0276) },
    { id = 10, name = 'Paleto Bay Nord',             coords = vec3(-94.1, 6419.6, 31.5),     blipCoords = vec3(-94.1, 6419.6, 31.5),     buyPrice = 240000, jobTruckSpawnCoords = vec4(-102.6958, 6403.3594, 31.4632, 40.5514), buyMarkerCoords = vec4(-93.0505, 6410.1895, 31.6404, 235.2287) },
    { id = 11, name = 'Route 68 Westlich',           coords = vec3(-2554.6, 2334.3, 33.1),   blipCoords = vec3(-2554.6, 2334.3, 33.1),   buyPrice = 205000, jobTruckSpawnCoords = vec4(-2522.2932, 2335.3911, 33.0599, 215.3061), buyMarkerCoords = vec4(-2543.9792, 2316.3274, 33.2160, 185.5450) },
    { id = 12, name = 'Textile City Tankstelle',     coords = vec3(-724.6, -935.1, 19.2),    blipCoords = vec3(-724.6, -935.1, 19.2),    buyPrice = 320000, jobTruckSpawnCoords = vec4(-707.0621, -942.7380, 19.1010, 179.1945), buyMarkerCoords = vec4(-708.6843, -904.2182, 19.2156, 6.3756) },
    { id = 13, name = 'Pillbox Hill Tankstelle',     coords = vec3(-527.7, -1211.5, 18.2),   blipCoords = vec3(-527.7, -1211.5, 18.2),   buyPrice = 340000, jobTruckSpawnCoords = vec4(-542.7435, -1216.4824, 18.2868, 334.9821), buyMarkerCoords = vec4(-531.4091, -1221.1589, 18.4550, 137.1347) },
    { id = 14, name = 'Strawberry Tankstelle',       coords = vec3(-70.3, -1761.5, 29.5),    blipCoords = vec3(-70.3, -1761.5, 29.5),    buyPrice = 300000, jobTruckSpawnCoords = vec4(-45.9393, -1741.6584, 29.2077, 49.3688), buyMarkerCoords = vec4(-42.7370, -1749.2958, 29.4210, 344.6459) },
    { id = 15, name = 'Textile City Süd',            coords = vec3(265.2, -1261.4, 29.3),    blipCoords = vec3(265.2, -1261.4, 29.3),    buyPrice = 310000, jobTruckSpawnCoords = vec4(284.6339, -1260.0922, 29.2653, 0.7815), buyMarkerCoords = vec4(288.7457, -1266.8585, 29.4407, 338.8521) },
    { id = 16, name = 'Popular Street Tankstelle',   coords = vec3(819.9, -1028.7, 26.4),    blipCoords = vec3(819.9, -1028.7, 26.4),    buyPrice = 315000, jobTruckSpawnCoords = vec4(826.1421, -1046.1075, 27.3399, 351.1326), buyMarkerCoords = vec4(818.2070, -1040.6754, 26.7508, 77.7174) },
    { id = 18, name = 'Murrieta Heights Tankstelle', coords = vec3(1207.4, -1402.3, 34.9),   blipCoords = vec3(1207.4, -1402.3, 34.9),   buyPrice = 285000, jobTruckSpawnCoords = vec4(1198.0081, -1396.9795, 35.2270, 178.9225), buyMarkerCoords = vec4(1211.3193, -1389.6045, 35.3769, 189.0135) },
    { id = 19, name = 'Rockford Hills Tankstelle',   coords = vec3(620.9, 269.1, 103.1),     blipCoords = vec3(620.9, 269.1, 103.1),     buyPrice = 400000, jobTruckSpawnCoords = vec4(640.3632, 268.7345, 103.1091, 148.3189), buyMarkerCoords = vec4(645.7874, 267.6781, 103.2327, 267.2765) },
    { id = 20, name = 'Pacific Bluffs Tankstelle',   coords = vec3(-1437.9, -276.5, 46.2),   blipCoords = vec3(-1437.9, -276.5, 46.2),   buyPrice = 380000, jobTruckSpawnCoords = vec4(-1416.5894, -284.6409, 46.2931, 130.1852), buyMarkerCoords = vec4(-1428.9982, -269.3112, 46.2076, 308.1654) },
    { id = 22, name = 'Vespucci Tankstelle',         coords = vec3(-319.7, -1471.2, 29.9),   blipCoords = vec3(-319.7, -1471.2, 29.9),   buyPrice = 355000, jobTruckSpawnCoords = vec4(-358.9259, -1490.3602, 30.0006, 177.1255), buyMarkerCoords = vec4(-341.5575, -1482.6145, 30.6769, 124.2783) },
    { id = 26, name = 'Alta Tankstelle',             coords = vec3(1181.7185, -330.4607, 69.3163),    blipCoords = vec3(1181.7185, -330.4607, 69.3163),    buyPrice = 275000, jobTruckSpawnCoords = vec4(1189.7828, -313.2411, 69.1718, 277.2891), buyMarkerCoords = vec4(1160.5939, -314.1431, 69.2050, 45.8730) },
    { id = 27, name = 'Innocence Blvd Tankstelle',   coords = vec3(178.2, -1562.4, 29.3),    blipCoords = vec3(178.2, -1562.4, 29.3),    buyPrice = 295000, jobTruckSpawnCoords = vec4(157.4643, -1564.8309, 29.2616, 245.8542), buyMarkerCoords = vec4(167.2079, -1553.8307, 29.2618, 39.2325) },
    { id = 30, name = 'Grand Senora Nord',           coords = vec3(2581.1396, 361.8633, 108.4705),    blipCoords = vec3(2581.1396, 361.8633, 108.4705),    buyPrice = 215000, jobTruckSpawnCoords = vec4(2560.2456, 426.4865, 108.4557, 314.7793), buyMarkerCoords = vec4(2559.4600, 373.7845, 108.6209, 69.0385) },
    { id = 31, name = 'Great Ocean Highway North',   coords = vec3(1701.8027, 6416.5269, 34.2317),    blipCoords = vec3(1701.8027, 6416.5269, 34.2317),    buyPrice = 245000, jobTruckSpawnCoords = vec4(1717.4127, 6416.6675, 33.4202, 149.9028), buyMarkerCoords = vec4(1736.7107, 6418.9771, 35.0374, 310.9017) },
    { id = 32, name = 'Great Ocean Highway Süd',     coords = vec3(-2097.3789, -319.9632, 13.1686),   blipCoords = vec3(-2097.3789, -319.9632, 13.1686),   buyPrice = 285000, jobTruckSpawnCoords = vec4(-2108.5879, -293.5035, 13.0468, 87.8541), buyMarkerCoords = vec4(-2073.3997, -327.2137, 13.3160, 185.7847) },
    { id = 33, name = 'Würfelpark Tankstelle',     coords = vec3(205.0321, -889.1855, 29.7449),    blipCoords = vec3(205.0321, -889.1855, 29.7449),    buyPrice = 500000, jobTruckSpawnCoords = vec4(227.5345, -907.9484, 29.5644, 341.5459), buyMarkerCoords = vec4(244.3058, -905.7303, 29.6234, 244.7464) },
}

-- Nachschlagetabelle nach cfg.id statt Array-Position: der Code greift an
-- vielen Stellen per Config.StationById[stationId] zu. Damit bleibt das
-- auch korrekt, wenn Config.Stations von Hand umsortiert/erweitert/gekürzt
-- wird und Array-Index nicht mehr zwingend == id ist.
Config.StationById = {}
for _, cfg in ipairs(Config.Stations) do
    Config.StationById[cfg.id] = cfg
end

-- ============================================================
-- KAUF-MARKER (Punkt 2: ox_target-frei, DrawMarker + [E])
-- ============================================================
-- Radius, in dem der [E]-Marker/Hilfstext für Kaufen/Boss-Menü/Job-Start/
-- Abladen an einer Station erscheint.
Config.MarkerInteractionDistance = 3.0

-- buyMarkerCoords steht jetzt direkt als Feld in jeder Station oben in
-- Config.Stations (Platzhalter vec4(0,0,0,0)). Solange eine Station dort
-- noch auf dem Platzhalter steht, weicht diese Schleife auf einen groben
-- Not-Standort (cfg.coords + kleiner Offset, NEBEN der Zapfsäule) aus,
-- damit der Kauf-Marker nicht am Weltursprung (0,0,0) landet - bitte pro
-- Station trotzdem einmal ingame vorbeischauen und das echte
-- `buyMarkerCoords = vec4(x, y, z, heading)` (idealerweise vor dem
-- Tankstellen-Gebäude/Shop) direkt in Config.Stations eintragen.
for _, cfg in ipairs(Config.Stations) do
    local bm = cfg.buyMarkerCoords
    local isPlaceholder = not bm or (bm.x == 0.0 and bm.y == 0.0 and bm.z == 0.0)
    if isPlaceholder then
        cfg.buyMarkerCoords = vec4(cfg.coords.x + 3.0, cfg.coords.y + 3.0, cfg.coords.z, 0.0)
    end
end

-- jobTruckSpawnCoords steht jetzt direkt als Feld in jeder Station oben in
-- Config.Stations (siehe Kommentar dort) - diese Schleife ist nur noch ein
-- Sicherheitsnetz, falls mal eine Station ohne dieses Feld ergänzt wird.
for _, cfg in ipairs(Config.Stations) do
    if not cfg.jobTruckSpawnCoords then
        cfg.jobTruckSpawnCoords = vec4(0.0, 0.0, 0.0, 0.0)
    end
end

-- Standard-Blip aller Tankstellen ohne Besitzer (bzw. Ausgangswert für
-- neu gekaufte Stationen, bis der Besitzer ihn im Boss-Menü ändert).
Config.DefaultBlip = { sprite = 361, color = 5, scale = 0.85 }
