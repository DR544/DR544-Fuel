-- ============================================================
-- wcc_fuel - client/bossmenu_bridge.lua
-- Schmale Brücke zwischen der Phone-App (wcc_fuelmanager) und diesem
-- Hauptscript: Job-Start aus der App heraus (falls der Spieler an der
-- eigenen Tankstelle steht), sowie Distanzberechnung für die App-Liste.
-- ============================================================

-- Von der Phone-App per Event ausgelöst, wenn im Boss-Menü auf
-- "Job starten" gedrückt wird. Prüft lokal, ob der Spieler nah genug an
-- SEINER Tankstelle ist (die eigentliche Berechtigungsprüfung passiert
-- ohnehin serverseitig in wcc_fuel:startJob).
RegisterNetEvent('wcc_fuel:bossmenu:startJobRequest', function(stationId)
    local cfg = Config.StationById[stationId]
    if not cfg then return end

    local ped = PlayerPedId()
    local dist = #(GetEntityCoords(ped) - cfg.coords)

    if dist > 25.0 then
        lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = 'Du musst dich an deiner Tankstelle befinden, um den Job zu starten.', type = 'error', duration = 5000 })
        return
    end

    WCC_StartJob(stationId)
end)

-- Liefert die aktuelle Spielerposition für Distanzanzeigen in der App
-- (die eigentliche serverseitige Distanzberechnung übernimmt
-- wcc_fuelmanager/server/main.lua analog zur Charging-App)
RegisterNUICallback = RegisterNUICallback -- no-op, NUI-Callbacks laufen in wcc_fuelmanager selbst
