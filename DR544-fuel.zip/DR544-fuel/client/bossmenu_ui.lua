-- ============================================================
-- wcc_fuel - client/bossmenu_ui.lua
-- Eigenständiges NUI-Boss-Menü DIREKT an der Tankstelle (kein Handy
-- nötig, aber inhaltlich identisch zur Boss-Seite der Phone-App
-- wcc_fuelmanager) - ruft dieselben ox_lib-Server-Callbacks auf wie
-- die Phone-App, da beides derselben Ressource (wcc_fuel) angehört.
-- ============================================================

local isOpen = false
local openStationId = nil

local function CloseBossMenu()
    if not isOpen then return end
    isOpen = false
    openStationId = nil
    WF_NuiWindowClosed('boss')
    SendNUIMessage({ action = 'close' })
end

WF_RegisterNuiWindow('boss', CloseBossMenu)

-- Von client/stations.lua aufgerufen, wenn "Boss-Menü" ausgewählt wird.
-- Jetzt auch für MITARBEITER zugänglich (nicht mehr nur Besitzer) - das
-- NUI bekommt die passende "role" mitgeschickt und blendet je nachdem
-- Bank/Upgrades/Mitarbeiterverwaltung/Einstellungen aus (die eigentliche
-- Rechteprüfung passiert ohnehin nochmal serverseitig bei jeder einzelnen
-- sensiblen Aktion im Menü, s. IsOwner() in server/stations.lua).
function WCC_OpenBossMenu(stationId)
    if isOpen then return end

    local myStations = lib.callback.await('wcc_fuel:getMyStations', false)
    local role = nil
    for _, s in ipairs(myStations or {}) do
        if s.id == stationId then role = s.role break end
    end

    if not role then
        lib.notify({ position = 'bottom-right', title = 'Boss-Menü', description = 'Du bist weder Besitzer noch Mitarbeiter dieser Tankstelle.', type = 'error', duration = 5000 })
        return
    end

    isOpen = true
    openStationId = stationId
    WF_NuiWindowOpened('boss')
    -- WICHTIG: jobActive wird bei JEDEM Öffnen live aus WCC_JobActive
    -- (client/job.lua) mitgeschickt - vorher setzte die NUI-Seite ihr
    -- eigenes window.WCC_JobActiveState nur einmalig beim Klick auf
    -- "Job starten" auf true und NIE wieder zurück, wodurch "Job läuft
    -- bereits" fälschlich dauerhaft stehen blieb, selbst nachdem der Job
    -- längst beendet/abgebrochen war (Fahrzeug verloren, Teleport zurück
    -- zur Station etc.).
    SendNUIMessage({ action = 'open', stationId = stationId, role = role, jobActive = WCC_JobActive == true })
end

RegisterNUICallback('boss:close', function(_, cb)
    CloseBossMenu()
    cb('ok')
end)

-- Alle folgenden Callbacks sind reine Durchreicher zu den bereits
-- vorhandenen, serverseitig voll validierten ox_lib-Callbacks (dieselben,
-- die auch die Phone-App nutzt - keine doppelte Logik).

RegisterNUICallback('boss:getMyStations', function(_, cb)
    local result = lib.callback.await('wcc_fuel:getMyStations', false)
    cb(result or {})
end)

RegisterNUICallback('boss:updateSettings', function(data, cb)
    local result = lib.callback.await('wcc_fuel:updateStationSettings', false, data.stationId, data.name, data.price, data.blipSprite, data.blipColor)
    cb(result)
end)

RegisterNUICallback('boss:levelUpStation', function(data, cb)
    local result = lib.callback.await('wcc_fuel:levelUpStation', false, data.stationId)
    cb(result)
end)

RegisterNUICallback('boss:levelUpTruck', function(data, cb)
    local result = lib.callback.await('wcc_fuel:levelUpTruck', false, data.stationId)
    cb(result)
end)

RegisterNUICallback('boss:levelUpComms', function(data, cb)
    local result = lib.callback.await('wcc_fuel:levelUpComms', false, data.stationId)
    cb(result)
end)

RegisterNUICallback('boss:deposit', function(data, cb)
    local result = lib.callback.await('wcc_fuel:depositBank', false, data.stationId, data.amount)
    cb(result)
end)

RegisterNUICallback('boss:withdraw', function(data, cb)
    local result = lib.callback.await('wcc_fuel:withdrawBank', false, data.stationId, data.amount)
    cb(result)
end)

-- Lohn-Intervall (1h/3h/6h/12h/24h) - NUR hier im on-site Boss-Menü
-- verfügbar, bewusst NICHT in der Phone-App (siehe wcc_fuelmanager).
RegisterNUICallback('boss:setWageInterval', function(data, cb)
    local result = lib.callback.await('wcc_fuel:setWageInterval', false, data.stationId, data.hours)
    cb(result)
end)

RegisterNUICallback('boss:getEmployees', function(data, cb)
    local result = lib.callback.await('wcc_fuel:getEmployees', false, data.stationId)
    cb(result or {})
end)

RegisterNUICallback('boss:searchPlayers', function(data, cb)
    local result = lib.callback.await('wcc_fuel:searchPlayers', false, data.query)
    cb(result or {})
end)

RegisterNUICallback('boss:addEmployee', function(data, cb)
    local result = lib.callback.await('wcc_fuel:addEmployee', false, data.stationId, data.identifier, data.name)
    cb(result)
end)

RegisterNUICallback('boss:removeEmployee', function(data, cb)
    local result = lib.callback.await('wcc_fuel:removeEmployee', false, data.stationId, data.identifier)
    cb(result)
end)

RegisterNUICallback('boss:setEmployeeWage', function(data, cb)
    local result = lib.callback.await('wcc_fuel:setEmployeeWage', false, data.stationId, data.identifier, data.wage)
    cb(result)
end)

-- Job-Start direkt aus dem Boss-Menü heraus schließt das Menü und startet
-- den Trucking-Job wie beim separaten "Trucking-Job starten"-Interaktionspunkt.
RegisterNUICallback('boss:startJob', function(data, cb)
    CloseBossMenu()
    WCC_StartJob(data.stationId)
    cb('ok')
end)

-- Fallback: ESC/Backspace schließt das Menü auch, falls das JS im NUI aus
-- irgendeinem Grund keinen close-Callback mehr feuert.
CreateThread(function()
    while true do
        Wait(0)
        if isOpen then
            if IsControlJustPressed(0, 200) or IsControlJustPressed(0, 322) then -- INPUT_FRONTEND_PAUSE / INPUT_FRONTEND_CANCEL
                CloseBossMenu()
            end
        else
            Wait(400)
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() and isOpen then
        CloseBossMenu()
    end
end)
