-- ============================================================
-- wcc_fuel - client/refuel.lua
-- Kernlogik des Tankvorgangs: Zapfpistole greifen/zurückbringen, einstecken,
-- Live-Session, Distanz-Check, 3D-Text-Anzeige. Sinngemäß 1:1 vom
-- Lade-Mechanismus aus wcc_chargingstations/client/charging.lua übernommen,
-- für Sprit/Liter neu geschrieben.
-- ============================================================

WF_State = {
    nozzleHeld = false,
    nozzleProp = nil,
    rope = nil,

    -- true, sobald die Zapfpistole im Tankstutzen steckt (unabhängig davon,
    -- ob gerade aktiv abgerechnet wird) - erst wenn wieder false, kann die
    -- Pistole zurückgebracht oder an einem anderen Auto eingesteckt werden.
    pluggedIn = false,

    stationId = nil,
    stationCoords = nil,
    stationEntity = nil,

    refueling = false,
    vehicle = nil,
    vehNetId = nil,
    lastVehicle = nil,

    startFuel = 0,
    fuel = 0,
    pricePerLiter = 0,
    litersFilled = 0.0,
    totalCost = 0.0,
    finishedReason = nil,
}

-- ------------------------------------------------------------
-- Hilfsfunktionen
-- ------------------------------------------------------------

function WF_PlaySound(name, set)
    PlaySoundFrontend(-1, name, set, true)
end

function WF_FormatMoney(amount)
    local formatted = tostring(math.floor(amount + 0.5))
    local reversed = formatted:reverse()
    reversed = reversed:gsub('(%d%d%d)', '%1.')
    formatted = reversed:reverse():gsub('^%.', '')
    return formatted .. ' $'
end

function WF_DrawText3D(coords, text)
    local onScreen, x, y = World3dToScreen2d(coords.x, coords.y, coords.z)
    if not onScreen then return end

    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry('STRING')
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(x, y)
end

-- Setzt NUR die Native + den lokalen Fuel-Cache aus client/main.lua (KEIN
-- TriggerServerEvent mehr) - der Server schreibt während einer laufenden
-- Session ohnehin selbst autoritativ in die DB (siehe server/fuel.lua).
function WccFuel_ApplyServerFuel(veh, value)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    value = math.max(0.0, math.min(100.0, tonumber(value) or 0.0))

    local plate = GetVehicleNumberPlateText(veh):gsub('%s+', '')
    if WccFuel_SetLocalFuelCache then
        WccFuel_SetLocalFuelCache(plate, value)
    end

    SetVehicleFuelLevel(veh, value + 0.0)
end

local function WF_GetLocalAccountMoney()
    local ESX = exports['es_extended']:getSharedObject()
    local playerData = ESX.GetPlayerData()
    if not playerData or not playerData.accounts then return 0 end

    for _, account in ipairs(playerData.accounts) do
        if account.name == Config.PaymentAccount then
            return account.money or 0
        end
    end

    return 0
end

-- ------------------------------------------------------------
-- Zapfpistole greifen / zurückbringen
-- ------------------------------------------------------------

function WF_GrabNozzle(stationId, pumpEntity)
    local cfg = Config.StationById[stationId]
    if not cfg then return end

    if WF_GetLocalAccountMoney() < 1 then
        WF_PlaySound('ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
        lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Du hast nicht genug Geld auf dem Konto, um zu tanken.', type = 'error', duration = 5000 })
        return
    end

    local ped = PlayerPedId()

    local success = lib.progressCircle({
        duration = 1200,
        label = 'Zapfpistole wird genommen…',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = { dict = 'anim@heists@narcotics@trash', clip = 'artificial_trash_pickup' },
    })

    if not success then return end

    if not WF_RequestModel(Config.CableNozzleProp) then
        lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Zapfpistole konnte nicht geladen werden.', type = 'error', duration = 5000 })
        return
    end

    local coords = GetEntityCoords(ped)
    local prop = CreateObject(joaat(Config.CableNozzleProp), coords.x, coords.y, coords.z, true, true, false)
    SetEntityCollision(prop, false, false)

    -- Bone/Offset/Rotation 1:1 von einem echten, produktiv laufenden
    -- Referenz-Script übernommen (ND-Framework/ND_Fuel) - unsere eigenen
    -- Werte (Bone 28422 + eigene Offsets/Rotation) haben trotz hartem
    -- Pinning sichtbar "komisch"/wackelig in der Hand gesessen.
    local boneIndex = GetPedBoneIndex(ped, 0x49D9) -- rechte Hand (Prop-Slot)
    AttachEntityToEntity(prop, ped, boneIndex, 0.11, 0.02, 0.02, -80.0, -90.0, 15.0, true, true, false, true, 1, true)

    -- stationEntity ist jetzt das ECHTE, im Streaming vorhandene Zapfsäulen-
    -- Prop, das der Spieler per ox_target angeklickt hat (kein eigenes
    -- gespawntes Anker-Prop mehr, siehe client/pump_resolver.lua).
    local stationEntity = pumpEntity

    -- WICHTIG: für Rope-Ankerpunkt UND Distanz-Check die tatsächliche
    -- Position der ECHTEN Zapfsäule (stationEntity) verwenden, NICHT
    -- cfg.coords - das ist nur eine grobe Näherungskoordinate der Station
    -- (Zuordnung per Radius, siehe Config.PumpStationLinkRadius), die
    -- Zapfsäule selbst kann davon mehrere Meter entfernt stehen. Mit
    -- cfg.coords als Referenz löste der Distanz-Check sofort "zu weit
    -- entfernt" aus, obwohl man direkt an der echten Pumpe stand.
    local c = (stationEntity and DoesEntityExist(stationEntity)) and GetEntityCoords(stationEntity) or cfg.coords
    local rope = WF_CreateRope(vector3(c.x, c.y, c.z + 1.0))

    -- Offset (0.0, -0.033, -0.195) ist der exakte lokale Punkt am
    -- "prop_cs_fuel_nozle"-Modell, an dem der Schlauch/Anschluss sitzt
    -- (aus dem Referenz-Script übernommen) - VORHER war es (0,0,0), also
    -- die Mitte des Props, wodurch das Seil sichtbar "im Prop drin" statt
    -- am eigentlichen Anschlussende ankam.
    local nozzleAnchor = vector3(0.0, -0.033, -0.195)

    if stationEntity and DoesEntityExist(stationEntity) then
        WF_AttachRopeToEntities(rope, stationEntity, nil, vector3(0.0, 0.0, 0.5), prop, nil, nozzleAnchor, 2.2)
    else
        WF_AttachRopeToEntities(rope, ped, nil, vector3(0.0, 0.0, 0.0), prop, nil, nozzleAnchor, 0.8)
    end

    WF_State.nozzleHeld = true
    WF_State.nozzleProp = prop
    WF_State.rope = rope
    WF_State.stationEntity = stationEntity
    WF_State.stationId = stationId
    WF_State.stationCoords = vector3(c.x, c.y, c.z)

    WF_PlaySound('SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
    lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Du hast die Zapfpistole genommen.', type = 'inform', duration = 5000 })
end

-- Hängt die Zapfpistole vom Fahrzeug zurück in die Hand (+ Seil wieder zur
-- Säule) - OHNE Progressbar/Notify, da sowohl vom manuellen "Abziehen"
-- (mit eigener Progressbar drumherum) als auch automatisch bei vollem
-- Tank (siehe Tick-Thread weiter unten) genutzt.
local function WF_ReattachNozzleToHand()
    local ped = PlayerPedId()

    if WF_State.nozzleProp and DoesEntityExist(WF_State.nozzleProp) then
        DetachEntity(WF_State.nozzleProp, true, true)
        local boneIndex = GetPedBoneIndex(ped, 0x49D9)
        AttachEntityToEntity(WF_State.nozzleProp, ped, boneIndex, 0.11, 0.02, 0.02, -80.0, -90.0, 15.0, true, true, false, true, 1, true)
    end

    if WF_State.rope then
        WF_DeleteRope(WF_State.rope)
        WF_State.rope = nil
    end

    local stationEntity = WF_State.stationEntity
    if stationEntity and DoesEntityExist(stationEntity) and WF_State.stationCoords then
        local rope = WF_CreateRope(WF_State.stationCoords + vector3(0.0, 0.0, 1.0))
        WF_AttachRopeToEntities(rope, stationEntity, nil, vector3(0.0, 0.0, 0.5), WF_State.nozzleProp, nil, vector3(0.0, -0.033, -0.195), 2.2)
        WF_State.rope = rope
    end

    WF_State.pluggedIn = false
    WF_State.lastVehicle = nil
end

function WF_UnplugNozzle()
    if not WF_State.nozzleHeld or not WF_State.pluggedIn or WF_State.refueling then return end

    local success = lib.progressCircle({
        duration = 1000,
        label = 'Zapfpistole wird abgezogen…',
        canCancel = true,
        disable = { move = true, car = true, combat = true },
    })

    if not success then return end

    WF_ReattachNozzleToHand()

    WF_PlaySound('SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
    lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Du hast die Zapfpistole abgezogen.', type = 'inform', duration = 5000 })
end

function WF_ReturnNozzle()
    if WF_State.refueling then
        lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Beende zuerst den Tankvorgang.', type = 'error', duration = 5000 })
        return
    end

    if WF_State.pluggedIn then
        lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Ziehe zuerst die Zapfpistole vom Fahrzeug ab.', type = 'error', duration = 5000 })
        return
    end

    local success = lib.progressCircle({
        duration = 1000,
        label = 'Zapfpistole wird zurückgebracht…',
        canCancel = true,
        disable = { move = true, car = true, combat = true },
    })

    if not success then return end

    WF_CleanupNozzle()
    WF_PlaySound('SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
    lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Du hast die Zapfpistole zurückgebracht.', type = 'inform', duration = 5000 })
end

function WF_CleanupNozzle()
    if WF_State.rope then
        WF_DeleteRope(WF_State.rope)
        WF_State.rope = nil
    end

    if WF_State.nozzleProp and DoesEntityExist(WF_State.nozzleProp) then
        DeleteEntity(WF_State.nozzleProp)
    end
    WF_State.nozzleProp = nil

    WF_State.nozzleHeld = false
    WF_State.pluggedIn = false
    WF_State.lastVehicle = nil
    WF_State.stationId = nil
    WF_State.stationCoords = nil
    WF_State.stationEntity = nil
end

-- ------------------------------------------------------------
-- Einstecken / Tankvorgang starten
-- ------------------------------------------------------------

function WF_PlugIn(veh)
    if not WF_State.nozzleHeld or WF_State.refueling or WF_State.pluggedIn then return end

    local ped = PlayerPedId()

    if WF_IsElectricVehicle(veh) then
        lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Dieses Fahrzeug ist ein Elektrofahrzeug, bitte an einer Ladestation laden.', type = 'error', duration = 5000 })
        return
    end

    local fuel = WccFuel_GetFuel(veh)
    if fuel >= 100.0 then
        lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Der Tank ist bereits voll.', type = 'inform', duration = 5000 })
        return
    end

    local success = lib.progressCircle({
        duration = 1500,
        label = 'Zapfpistole wird eingesteckt…',
        canCancel = true,
        disable = { move = true, car = true, combat = true },
    })

    if not success then return end

    SetEntityCollision(WF_State.nozzleProp, false, false)

    -- Offset/Rotation von einem echten, produktiv laufenden Referenz-Script
    -- übernommen (ND-Framework/ND_Fuel) - unsere eigene Rotation (0,0,0)
    -- ließ den Zapfhahn einfach mit der Standard-Ausrichtung im Tankstutzen
    -- "schweben" statt realistisch angewinkelt eingesteckt auszusehen.
    local petrolBone = GetEntityBoneIndexByName(veh, 'petrolcap')
    local plugBoneName = nil
    if petrolBone and petrolBone ~= -1 then
        plugBoneName = 'petrolcap'
        -- X näher an 0 = näher am Bone/mittiger statt weit außen am
        -- Fahrzeug zu hängen. Z angehoben für eine höhere Position am
        -- Tankstutzen.
        AttachEntityToEntity(WF_State.nozzleProp, veh, petrolBone, -0.06, 0.0, 0.15, -125.0, -90.0, -90.0, true, true, false, false, 1, true)
    else
        -- Fallback ohne echten "petrolcap"-Bone am Modell: realistisch
        -- seitlich am Heck statt starr mittig/im Fahrzeug - automatisch
        -- die Seite (links = min.x, rechts = max.x) wählen, die näher an
        -- der eigenen Tankstelle liegt, ähnlich wie ND_Fuel es über die
        -- Fallback-Bones (petroltank_l/hub_lr) tendenziell an einer Seite
        -- verankert.
        local model = GetEntityModel(veh)
        local min, max = GetModelDimensions(model)
        local rearY = min.y + 0.3
        local heightZ = min.z + 0.65
        local leftPoint = GetOffsetFromEntityInWorldCoords(veh, min.x, rearY, heightZ)
        local rightPoint = GetOffsetFromEntityInWorldCoords(veh, max.x, rearY, heightZ)
        local refCoords = WF_State.stationCoords or GetEntityCoords(ped)
        local sideX = (#(refCoords - leftPoint) <= #(refCoords - rightPoint)) and min.x or max.x

        AttachEntityToEntity(WF_State.nozzleProp, veh, 0, sideX, rearY, heightZ, -125.0, -90.0, -90.0, true, true, false, false, 1, true)
    end

    if WF_State.rope then
        WF_DeleteRope(WF_State.rope)
    end
    WF_State.rope = WF_CreateRope(WF_State.stationCoords + vector3(0.0, 0.0, 1.0))

    -- WICHTIG: die Rope hängt jetzt am Zapfhahn-PROP selbst (mit seinem
    -- eigenen Anschluss-Offset, siehe WF_ReattachNozzleToHand) statt am
    -- Fahrzeug/Bone direkt - vorher landete der Rope-Anker (Bone-Weltposition
    -- + roher, NICHT mitgedrehter Offset) je nach Fahrzeug-Ausrichtung
    -- teils mitten im Fahrzeug statt am Zapfhahn.
    local stationEntity = WF_State.stationEntity
    if stationEntity and DoesEntityExist(stationEntity) then
        WF_AttachRopeToEntities(WF_State.rope, stationEntity, nil, vector3(0.0, 0.0, 0.5), WF_State.nozzleProp, nil, vector3(0.0, -0.033, -0.195), 2.8)
    else
        WF_AttachRopeToEntities(WF_State.rope, veh, plugBoneName, vector3(0.0, 0.0, 0.0), WF_State.nozzleProp, nil, vector3(0.0, -0.033, -0.195), 0.8)
    end

    WF_State.pluggedIn = true

    local netId = NetworkGetNetworkIdFromEntity(veh)
    local plate = GetVehicleNumberPlateText(veh):gsub('%s+', '')

    lib.callback('wcc_fuel:requestStartRefuel', 3000, function(response)
        if not response or not response.ok then
            WF_State.pluggedIn = false
            WF_PlaySound('ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
            lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = (response and response.reason) or 'Tankvorgang konnte nicht gestartet werden.', type = 'error', duration = 5000 })
            WF_CleanupNozzle()
            return
        end

        WF_State.refueling = true
        WF_State.vehicle = veh
        WF_State.vehNetId = netId
        WF_State.startFuel = fuel
        WF_State.fuel = fuel
        WF_State.pricePerLiter = response.pricePerLiter
        WF_State.litersFilled = 0.0
        WF_State.totalCost = 0.0

        WF_PlaySound('CONFIRM_BEEP', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
        lib.notify({ position = 'bottom-right',
            title = 'Tankstellen',
            description = ('Tankvorgang gestartet · %.2f $/L'):format(response.pricePerLiter),
            type = 'success',
            duration = 5000,
        })
    end, WF_State.stationId, netId, plate)
end

-- ------------------------------------------------------------
-- Tankvorgang beenden (manuell, voll oder Fehler)
-- ------------------------------------------------------------

function WF_StopRefuel(reason)
    if not WF_State.refueling then return end

    local veh = WF_State.vehicle
    local netId = WF_State.vehNetId

    WF_State.refueling = false
    WF_State.finishedReason = reason

    TriggerServerEvent('wcc_fuel:requestStopRefuel', netId, reason)

    if veh and DoesEntityExist(veh) then
        WccFuel_ApplyServerFuel(veh, WF_State.fuel)
    end

    if WF_State.rope then
        WF_DeleteRope(WF_State.rope)
        WF_State.rope = nil
    end

    WF_State.lastVehicle = veh
    WF_State.vehicle = nil
    WF_State.vehNetId = nil
end

RegisterNetEvent('wcc_fuel:forceStopped', function(reasonText)
    if not WF_State.refueling then return end
    WF_StopRefuel('server')
    WF_PlaySound('ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
    lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = reasonText or 'Tankvorgang wurde abgebrochen.', type = 'error', duration = 5000 })
end)

RegisterNetEvent('wcc_fuel:refuelTickUpdate', function(newFuelPercent, totalLiters, totalCost)
    if not WF_State.refueling then return end
    WF_State.fuel = newFuelPercent
    WF_State.litersFilled = totalLiters
    WF_State.totalCost = totalCost

    if WF_State.vehicle and DoesEntityExist(WF_State.vehicle) then
        WccFuel_ApplyServerFuel(WF_State.vehicle, newFuelPercent)
    end
end)

RegisterNetEvent('wcc_fuel:refuelComplete', function(totalLiters, totalCost)
    WF_PlaySound('RANK_UP', 'HUD_AWARDS')
    lib.notify({ position = 'bottom-right',
        title = 'Tankstellen',
        description = ('Tank zu 100%% voll: %.1f Liter für %s. Zapfpistole abziehen zum Beenden.'):format(totalLiters, WF_FormatMoney(totalCost)),
        type = 'success',
        duration = 8000,
    })

    -- Der Server hat die Session bei vollem Tank bereits selbst sauber
    -- beendet (siehe EndSession in server/fuel.lua) - hier NUR noch den
    -- lokalen "refueling"-Status zurücksetzen, OHNE erneut
    -- requestStopRefuel zu senden (Session existiert serverseitig schon
    -- nicht mehr). Vorher blieb WF_State.refueling fälschlich auf true
    -- stehen, wodurch "Zapfpistole abziehen" im ox_target-Menü gar nicht
    -- erst anwählbar war - man musste zuerst unnötig manuell "Tankvorgang
    -- abbrechen" drücken. Das Abziehen selbst bleibt weiterhin ein
    -- bewusster, manueller Schritt (siehe WF_UnplugNozzle).
    WF_State.refueling = false
    WF_State.finishedReason = 'full'
    WF_State.lastVehicle = WF_State.vehicle
    WF_State.vehicle = nil
    WF_State.vehNetId = nil

    if WF_State.rope then
        WF_DeleteRope(WF_State.rope)
        WF_State.rope = nil
    end
end)

-- ------------------------------------------------------------
-- 3D-Text-Anzeige während des Tankens / nach Abschluss
-- ------------------------------------------------------------

CreateThread(function()
    while true do
        local wait = 500

        if WF_State.refueling and WF_State.vehicle and DoesEntityExist(WF_State.vehicle) then
            wait = 0

            local remainingFuel = 100.0 - WF_State.fuel
            local remainingSec = (remainingFuel / 100.0) * Config.MaxFullTankSeconds

            local vehCoords = GetEntityCoords(WF_State.vehicle)
            local textCoords = vehCoords + vector3(0.0, 0.0, 1.0)

            WF_DrawText3D(textCoords, string.format(
                '~y~Tankvorgang~s~\n%.0f%% ~s~· %.1f Liter\nPreis: %.2f $/L\nKosten bisher: %s\nVerbleibend: ~y~%ds~s~',
                WF_State.fuel, WF_State.litersFilled, WF_State.pricePerLiter, WF_FormatMoney(WF_State.totalCost), math.max(0, math.floor(remainingSec))
            ))
        elseif WF_State.pluggedIn and not WF_State.refueling and WF_State.lastVehicle and DoesEntityExist(WF_State.lastVehicle) then
            wait = 0

            local vehCoords = GetEntityCoords(WF_State.lastVehicle)
            local textCoords = vehCoords + vector3(0.0, 0.0, 1.0)

            if WF_State.fuel >= 100.0 then
                WF_DrawText3D(textCoords, string.format(
                    '~g~Tank voll~s~\n%.0f%% ~s~· %.1f Liter getankt\nPreis: %.2f $/L\n~g~Kosten gesamt: %s~s~\n~y~Zapfpistole abziehen zum Beenden~s~',
                    WF_State.fuel, WF_State.litersFilled, WF_State.pricePerLiter, WF_FormatMoney(WF_State.totalCost)
                ))
            else
                WF_DrawText3D(textCoords, string.format(
                    '~o~Tankvorgang beendet~s~\n%.0f%% ~s~· %.1f Liter getankt\nPreis: %.2f $/L\n~o~Kosten gesamt: %s~s~\n~y~Zapfpistole abziehen zum Beenden~s~',
                    WF_State.fuel, WF_State.litersFilled, WF_State.pricePerLiter, WF_FormatMoney(WF_State.totalCost)
                ))
            end
        end

        Wait(wait)
    end
end)

-- Distanz-Check: gilt NUR solange man die Zapfpistole lose in der Hand
-- trägt und noch NICHT eingesteckt hat.
CreateThread(function()
    while true do
        Wait(1000)

        if WF_State.nozzleHeld and not WF_State.pluggedIn and WF_State.stationCoords then
            local ped = PlayerPedId()
            local dist = #(GetEntityCoords(ped) - WF_State.stationCoords)

            if dist > Config.MaxDistanceFromPump then
                if WF_State.refueling then
                    WF_StopRefuel('distance')
                end
                WF_CleanupNozzle()
                WF_PlaySound('ERROR', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
                lib.notify({ position = 'bottom-right',
                    title = 'Tankstellen',
                    description = 'Du hast dich zu weit von der Zapfsäule entfernt. Zapfpistole wurde zurückgesetzt.',
                    type = 'error',
                    duration = 5000,
                })
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    WF_CleanupNozzle()
end)
