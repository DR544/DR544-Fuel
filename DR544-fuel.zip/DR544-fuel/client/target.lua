-- ============================================================
-- wcc_fuel - client/target.lua
-- ox_target Interaktionen: Zapfpistole nehmen/zurückbringen an der Pumpe,
-- Zapfpistole einstecken/abziehen/abbrechen am Fahrzeug.
-- WICHTIG: ox_target wird im gesamten wcc_fuel NUR HIER (Tanken) verwendet -
-- Kaufen/Boss-Menü/Job/Abladen laufen über native Marker (client/markers.lua).
--
-- Es werden KEINE eigenen Props mehr gespawnt: addModel reagiert
-- automatisch auf alle bereits im Streaming vorhandenen echten GTA-
-- Zapfsäulen-Props (Config.KnownPumpModels), die Zuordnung zur Station
-- läuft über WF_FindStationByPumpEntity (client/pump_resolver.lua).
-- ============================================================

exports.ox_target:addModel(Config.KnownPumpModels, {
    {
        name = 'wcc_fuel_nozzle_grab',
        label = 'Zapfpistole nehmen',
        icon = 'fas fa-gas-pump',
        distance = 2.5,
        canInteract = function(entity)
            if WF_State.nozzleHeld or WF_State.refueling then return false end
            return WF_FindStationByPumpEntity(entity) ~= nil
        end,
        onSelect = function(data)
            local stationId = WF_FindStationByPumpEntity(data.entity)
            if stationId then
                WF_GrabNozzle(stationId, data.entity)
            end
        end,
    },
    {
        name = 'wcc_fuel_nozzle_return',
        label = 'Zapfpistole zurückbringen',
        icon = 'fas fa-rotate-left',
        distance = 2.5,
        canInteract = function(entity)
            if not WF_State.nozzleHeld or WF_State.refueling then return false end
            local stationId = WF_FindStationByPumpEntity(entity)
            return stationId ~= nil and stationId == WF_State.stationId
        end,
        onSelect = function()
            WF_ReturnNozzle()
        end,
    },
})

-- Globale Fahrzeug-Optionen: Einstecken / Tankvorgang abbrechen / abziehen
exports.ox_target:addGlobalVehicle({
    {
        name = 'wcc_fuel_nozzle_plug',
        label = 'Zapfpistole einstecken',
        icon = 'fas fa-plug-circle-bolt',
        distance = 3.0,
        canInteract = function(entity)
            if not WF_State.nozzleHeld or WF_State.refueling or WF_State.pluggedIn then return false end
            return true
        end,
        onSelect = function(data)
            WF_PlugIn(data.entity)
        end,
    },
    {
        name = 'wcc_fuel_nozzle_cancel',
        label = 'Tankvorgang abbrechen',
        icon = 'fas fa-plug-circle-minus',
        distance = 3.0,
        canInteract = function(entity)
            return WF_State.refueling and WF_State.vehicle == entity
        end,
        onSelect = function()
            WF_StopRefuel('manual')
        end,
    },
    {
        -- Getrennt vom Abbrechen: greift auch NACH vollem Tank (WF_State.refueling
        -- ist dann schon false, aber die Zapfpistole steckt noch am Auto).
        name = 'wcc_fuel_nozzle_detach',
        label = 'Zapfpistole abziehen',
        icon = 'fas fa-plug-circle-xmark',
        distance = 3.0,
        canInteract = function(entity)
            return WF_State.pluggedIn and not WF_State.refueling and WF_State.nozzleProp ~= nil
        end,
        onSelect = function()
            WF_UnplugNozzle()
        end,
    },
})
