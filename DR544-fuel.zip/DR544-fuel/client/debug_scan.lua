-- ============================================================
-- wcc_fuel - client/debug_scan.lua
-- Reines Diagnose-Kommando (kein UI, kein Setup-Workflow): listet alle
-- gerade geladenen Zapfsäulen-Props (Config.KnownPumpModels) in der Nähe
-- des Spielers auf, inkl. zugeordneter Station - hilft dabei,
-- Config.KnownPumpModels/Config.PumpStationLinkRadius nachzujustieren.
-- Nur für die im Server per License freigeschaltete Admin-Identität
-- nutzbar (siehe server/debug_scan.lua).
-- ============================================================

local pumpModelHashes = {}
for _, model in ipairs(Config.KnownPumpModels) do
    pumpModelHashes[joaat(model)] = model
end

RegisterCommand('fuelscanpumps', function()
    -- Serverseitige Berechtigungsprüfung zuerst (Client-Command könnte von
    -- jedem eingegeben werden, das Ergebnis kommt aber nur zurück, wenn der
    -- Server die License bestätigt).
    lib.callback('wcc_fuel:debugCheckPumpScanPermission', false, function(allowed)
        if not allowed then
            lib.notify({ position = 'bottom-right', title = 'wcc_fuel', description = 'Keine Berechtigung für /fuelscanpumps.', type = 'error', duration = 5000 })
            return
        end

        local ped = PlayerPedId()
        local playerCoords = GetEntityCoords(ped)

        local found = {}
        local pool = GetGamePool('CObject')
        for _, entity in ipairs(pool) do
            local model = GetEntityModel(entity)
            local modelName = pumpModelHashes[model]
            if modelName then
                local coords = GetEntityCoords(entity)
                local dist = #(coords - playerCoords)
                if dist <= 100.0 then
                    found[#found + 1] = { entity = entity, model = modelName, coords = coords, dist = dist }
                end
            end
        end

        table.sort(found, function(a, b) return a.dist < b.dist end)

        if #found == 0 then
            lib.notify({ position = 'bottom-right', title = 'wcc_fuel', description = 'Keine Zapfsäulen-Props (Config.KnownPumpModels) im Umkreis von 100m gefunden.', type = 'inform', duration = 5000 })
            print('[wcc_fuel][fuelscanpumps] Keine passenden Props im Umkreis von 100m gefunden.')
            return
        end

        print(('[wcc_fuel][fuelscanpumps] %d Zapfsäulen-Prop(s) im Umkreis von 100m:'):format(#found))
        for _, entry in ipairs(found) do
            local stationId = WF_FindStationByPumpEntity(entry.entity)
            local cfg = stationId and Config.StationById[stationId]
            local stationLabel = cfg and ('#%d %s'):format(cfg.id, cfg.name) or '~r~KEINE Station im Radius zugeordnet~s~'

            print(('  - %s @ (%.1f, %.1f, %.1f) · %.1fm entfernt -> %s')
                :format(entry.model, entry.coords.x, entry.coords.y, entry.coords.z, entry.dist, cfg and stationLabel or 'KEINE Station im Radius zugeordnet'))
        end

        lib.notify({ position = 'bottom-right',
            title = 'wcc_fuel',
            description = ('%d Zapfsäulen-Prop(s) gefunden, Details in der F8-Konsole.'):format(#found),
            type = 'success',
            duration = 5000,
        })
    end)
end, false)
