-- ============================================================
-- wcc_fuel - client/main.lua
-- Fahrzeug-Tankstand, Verbrauchssimulation (RPM/Speed-abhängig),
-- Motor-Blockade bei leerem Tank, LegacyFuel-Kompatibilitätsschicht.
-- ============================================================

-- plate -> fuel (0-100), lokaler Cache damit nicht bei jedem Tick die DB
-- gefragt werden muss. Wird beim ersten Betreten des Fahrzeugs geladen
-- und periodisch (Config.FuelSaveInterval) an den Server gemeldet.
local fuelCache = {}
local lastSaveTime = {}

-- ------------------------------------------------------------
-- Hilfsfunktionen
-- ------------------------------------------------------------

local function GetPlate(veh)
    return GetVehicleNumberPlateText(veh):gsub('%s+', '')
end

-- E-Auto-Erkennung (Config.ElectricVehicleModels, MUSS synchron zu
-- wcc_chargingstations/config.lua gehalten werden). E-Autos werden von
-- wcc_fuel komplett ignoriert (kein Verbrauch, kein Motor-Block, keine
-- Zapfpistolen-Interaktion) - die gehören ausschließlich
-- wcc_chargingstations. Analog zu WCC_IsElectricVehicle dort.
local electricModelHashes = {}
for _, model in ipairs(Config.ElectricVehicleModels) do
    electricModelHashes[joaat(model)] = true
end

function WF_IsElectricVehicle(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return false end
    if GetEntityType(veh) ~= 2 then return false end -- 2 = Vehicle

    local ok, model = pcall(GetEntityModel, veh)
    if not ok or not model then return false end

    return electricModelHashes[model] == true
end

local function EnsureFuelLoaded(veh, plate)
    if fuelCache[plate] ~= nil then return fuelCache[plate] end

    local fuel = lib.callback.await('wcc_fuel:loadVehicleFuel', false, plate)
    fuelCache[plate] = fuel or Config.DefaultFuelLevel
    return fuelCache[plate]
end

local function SaveFuel(veh, plate, fuel)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    local netId = NetworkGetNetworkIdFromEntity(veh)
    TriggerServerEvent('wcc_fuel:saveVehicleFuel', netId, plate, fuel)
end

-- ------------------------------------------------------------
-- Öffentliche Get/Set-Funktionen (von Kompat-Layer & Tankvorgang genutzt)
-- ------------------------------------------------------------

function WccFuel_GetFuel(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return 0.0 end
    local plate = GetPlate(veh)
    return EnsureFuelLoaded(veh, plate)
end

function WccFuel_SetFuel(veh, value)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    value = math.max(0.0, math.min(100.0, tonumber(value) or 0.0))

    local plate = GetPlate(veh)
    fuelCache[plate] = value

    SetVehicleFuelLevel(veh, value + 0.0)
    SaveFuel(veh, plate, value)
end

-- Setzt NUR den lokalen Cache (kein SaveFuel/TriggerServerEvent) - wird von
-- client/refuel.lua während einer laufenden Tank-Session genutzt, weil der
-- Server während der Session ohnehin selbst autoritativ in die DB schreibt.
function WccFuel_SetLocalFuelCache(plate, value)
    if not plate or plate == '' then return end
    fuelCache[plate] = math.max(0.0, math.min(100.0, tonumber(value) or 0.0))
end

exports('GetFuel', function(veh) return WccFuel_GetFuel(veh) end)
exports('SetFuel', function(veh, value) WccFuel_SetFuel(veh, value) end)

-- ------------------------------------------------------------
-- LegacyFuel-Kompatibilität: andere Ressourcen (HUDs etc.), die noch die
-- klassischen LegacyFuel-Events/-Exports erwarten, funktionieren
-- unverändert weiter.
-- ------------------------------------------------------------

if Config.EnableLegacyFuelCompat then
    RegisterNetEvent('LegacyFuel:GetFuel', function(veh)
        -- Manche Implementierungen erwarten ein direktes Rückgabe-Event,
        -- andere nutzen es als reinen Trigger - wir bedienen beide Fälle
        -- über den Export, das Event hier bleibt als reiner Kompat-Stub.
    end)

    RegisterNetEvent('LegacyFuel:SetFuel', function(veh, value)
        WccFuel_SetFuel(veh, value)
    end)
end

-- ------------------------------------------------------------
-- Verbrauchssimulation
-- ------------------------------------------------------------
-- Sinngemäß wie LegacyFuel: Verbrauch skaliert mit Drehzahl (RPM) und
-- Geschwindigkeit, außerdem mit einem Klassen-Multiplikator (LKW/SUV
-- verbrauchen mehr als Kompaktwagen). Kein Verbrauch im Stand mit
-- ausgeschaltetem Motor.
-- ------------------------------------------------------------

CreateThread(function()
    while true do
        Wait(1000)

        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)

            -- Nur der Fahrer verbraucht/persistiert Sprit, sonst würde bei
            -- mehreren Mitfahrern der Tankstand mehrfach verrechnet.
            if GetPedInVehicleSeat(veh, -1) == ped and not IsEntityDead(ped) then
                local plate = GetPlate(veh)
                local fuel = EnsureFuelLoaded(veh, plate)

                local engineOn = GetIsVehicleEngineRunning(veh)

                if engineOn and fuel > 0 then
                    local rpm = GetVehicleCurrentRpm(veh) -- 0.0 - 1.0
                    local speed = GetEntitySpeed(veh) -- m/s

                    local vehClass = GetVehicleClass(veh)
                    local classMult = Config.FuelConsumptionClassMultiplier[vehClass] or 1.0

                    -- Verbrauch: Grundrate * (0.3 Leerlauf-Anteil + 0.7 * RPM) skaliert
                    -- zusätzlich leicht mit der Geschwindigkeit (schnelleres Fahren
                    -- = etwas höherer Verbrauch on top vom reinen RPM-Wert).
                    local rpmFactor = 0.3 + (rpm * 0.7)
                    local speedFactor = 1.0 + math.min(speed / 40.0, 1.0) * 0.5

                    local consumption = Config.FuelConsumptionRate * rpmFactor * speedFactor * classMult

                    fuel = math.max(0.0, fuel - consumption)
                    fuelCache[plate] = fuel
                    SetVehicleFuelLevel(veh, fuel + 0.0)

                    if Config.Debug then
                        print(('[wcc_fuel] %s fuel=%.2f consumption=%.3f rpm=%.2f speed=%.2f'):format(plate, fuel, consumption, rpm, speed))
                    end
                elseif engineOn and fuel <= 0 then
                    -- Motor läuft, aber Tank leer -> Motor ausschalten
                    if Config.BlockEngineWhenEmpty then
                        SetVehicleEngineOn(veh, false, false, true)
                    end
                end

                -- Motor stottern lassen bei niedrigem Füllstand (unterhalb
                -- Config.LowFuelThreshold), simuliert unrunden Leerlauf.
                if engineOn and fuel > 0 and fuel <= Config.LowFuelThreshold then
                    if math.random(1, 100) <= 8 then
                        SetVehicleEngineOn(veh, false, true, false)
                        Wait(150)
                        if fuel > 0 then
                            SetVehicleEngineOn(veh, true, true, false)
                        end
                    end
                end

                -- Periodisch speichern, statt bei jedem Tick (DB-Last sparen)
                local now = GetGameTimer()
                if not lastSaveTime[plate] or (now - lastSaveTime[plate]) >= Config.FuelSaveInterval then
                    lastSaveTime[plate] = now
                    SaveFuel(veh, plate, fuel)
                end
            end
        end
    end
end)

-- Sorgt dafür, dass der zuletzt bekannte Tankstand nicht erst bis zu
-- Config.FuelSaveInterval verzögert gespeichert wird, wenn das Script neu
-- gestartet wird (z.B. Resource-Restart) - ohne das würde ein kurz davor
-- verbrauchter Tankstand verloren gehen und beim nächsten Laden zu hoch
-- wiederhergestellt werden.
AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then
        local veh = GetVehiclePedIsIn(ped, false)
        if GetPedInVehicleSeat(veh, -1) == ped then
            local plate = GetPlate(veh)
            if fuelCache[plate] ~= nil then
                SaveFuel(veh, plate, fuelCache[plate])
            end
        end
    end
end)

-- Setzt beim Einsteigen sofort den korrekt geladenen Tankstand am
-- Fahrzeug-Handle (sonst würde GTA den Tank z.B. immer "voll" anzeigen,
-- bis der Verbrauchs-Thread das erste Mal greift).
CreateThread(function()
    local lastVeh = nil
    while true do
        Wait(500)
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= lastVeh and GetPedInVehicleSeat(veh, -1) == ped then
                lastVeh = veh
                local plate = GetPlate(veh)
                local fuel = EnsureFuelLoaded(veh, plate)
                SetVehicleFuelLevel(veh, fuel + 0.0)
            end
        else
            lastVeh = nil
        end
    end
end)
