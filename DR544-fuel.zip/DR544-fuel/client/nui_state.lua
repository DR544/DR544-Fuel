-- ============================================================
-- wcc_fuel - client/nui_state.lua
-- Zentrale Verwaltung von SetNuiFocus für ALLE eigenen NUI-Fenster
-- (Boss-Menü + Kauf-Screen, siehe client/bossmenu_ui.lua und
-- client/marker_ui.lua). Beide UIs verwalten ihren eigenen "ist offen"-
-- Zustand getrennt - ohne diese zentrale Stelle konnte es passieren, dass
-- z.B. der Fokus/die Maus beim Schließen EINES Fensters aufgehoben wird,
-- während (durch einen Doppel-Trigger) technisch noch ein anderes unserer
-- Fenster "offen" war, wodurch der Mauszeiger fälschlich hängen blieb bzw.
-- ein Fenster nicht mehr neu geöffnet werden konnte. Jetzt wird
-- SetNuiFocus nur noch an den echten Übergängen (0 -> 1 offene Fenster
-- bzw. 1 -> 0) aufgerufen, und beim Öffnen eines Fensters wird ein
-- eventuell anderes eigenes Fenster automatisch zuerst geschlossen.
-- ============================================================

local openWindows = {} -- z.B. { boss = true } oder { buy = true }

-- Schließt alle ANDEREN eigenen NUI-Fenster (per Callback), bevor ein neues
-- geöffnet wird - verhindert zwei gleichzeitig "offene" Fenster.
local closers = {}

function WF_RegisterNuiWindow(kind, closeFn)
    closers[kind] = closeFn
end

function WF_NuiWindowIsOpen(kind)
    return openWindows[kind] == true
end

function WF_AnyNuiWindowOpen()
    return next(openWindows) ~= nil
end

-- Von den einzelnen UIs beim Öffnen aufgerufen. Schließt zuerst alle
-- anderen eigenen Fenster, setzt dann den Fokus (nur falls vorher kein
-- Fenster offen war - sonst ist er schon an).
function WF_NuiWindowOpened(kind)
    for otherKind, closeFn in pairs(closers) do
        if otherKind ~= kind and openWindows[otherKind] then
            closeFn()
        end
    end

    local wasAnyOpen = WF_AnyNuiWindowOpen()
    openWindows[kind] = true

    if not wasAnyOpen then
        SetNuiFocus(true, true)
    end
end

-- Von den einzelnen UIs beim Schließen aufgerufen. Gibt den Fokus NUR frei,
-- wenn danach wirklich KEIN eigenes Fenster mehr offen ist.
function WF_NuiWindowClosed(kind)
    if not openWindows[kind] then return end
    openWindows[kind] = nil

    if not WF_AnyNuiWindowOpen() then
        SetNuiFocus(false, false)
    end
end

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    -- Sicherheitsnetz: Fokus IMMER freigeben, egal was die einzelnen UIs
    -- an Zustand hatten, damit nach einem Resource-Restart nie eine
    -- "gefangene" Maus zurückbleibt.
    SetNuiFocus(false, false)
end)
