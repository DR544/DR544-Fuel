-- ============================================================
-- wcc_fuel - client/pump_resolver.lua
-- Ordnet ein ECHTES, bereits im GTA-Map-Streaming vorhandenes
-- Zapfsäulen-Prop-Entity (siehe Config.KnownPumpModels) der nächstgelegenen
-- Station aus Config.Stations zu. Es werden KEINE eigenen Props mehr
-- gespawnt (ehemals client/props.lua) - ox_target reagiert automatisch auf
-- alle bereits gestreamten Entities dieser Modelle, ein eigener Spawn-/
-- Nähe-Scan-Thread ist dafür nicht mehr nötig.
-- ============================================================

-- Liefert die stationId der nächstgelegenen Station innerhalb von
-- Config.PumpStationLinkRadius für ein gegebenes Prop-Entity, sonst nil.
function WF_FindStationByPumpEntity(entity)
    if not entity or not DoesEntityExist(entity) then return nil end

    local coords = GetEntityCoords(entity)

    local bestId, bestDist = nil, Config.PumpStationLinkRadius
    for _, cfg in ipairs(Config.Stations) do
        local dist = #(coords - cfg.coords)
        if dist <= bestDist then
            bestDist = dist
            bestId = cfg.id
        end
    end

    return bestId
end
