-- ============================================================
-- wcc_fuel - client/markers.lua
-- Native DrawMarker + [E]-Interaktionen an jeder Station: Kaufen (kein
-- Besitzer), Boss-Menü + Trucking-Job starten (Besitzer/Mitarbeiter), LKW
-- abladen (während aktivem Job an DIESER Station). Ersetzt die früheren
-- ox_target-Optionen aus client/stations.lua - ox_target wird in wcc_fuel
-- nur noch für die Zapfpistole verwendet (siehe client/target.lua).
-- ============================================================

local function DrawStationMarker(coords, r, g, b, a)
    DrawMarker(1, coords.x, coords.y, coords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.4, 1.4, 0.9, r, g, b, a, false, true, 2, false, nil, nil, false)
end

CreateThread(function()
    while true do
        local wait = 500
        local ped = PlayerPedId()
        local playerCoords = GetEntityCoords(ped)

        for _, cfg in ipairs(Config.Stations) do
            local mc = cfg.buyMarkerCoords
            local markerCoords = vector3(mc.x, mc.y, mc.z)
            local dist = #(playerCoords - markerCoords)

            -- Nur zeichnen, wenn überhaupt in grober Reichweite (spart Performance
            -- bei ~30 Stationen, die meisten davon weit weg vom Spieler)
            if dist < 20.0 then
                wait = 0

                local data = WCC_FuelStations[cfg.id]
                local hasOwner = data and data.hasOwner

                -- Pulsieren über Zeit-basierte Skalierung/Alpha (kein zusätzlicher
                -- Zustand nötig, GetGameTimer liefert einen stetig wachsenden Takt)
                local pulse = (math.sin(GetGameTimer() / 350.0) + 1.0) / 2.0 -- 0..1

                if not hasOwner then
                    -- Kein Besitzer: goldener/oranger pulsierender Marker
                    local alpha = math.floor(110 + pulse * 90)
                    DrawStationMarker(markerCoords, 255, 176, 32, alpha)

                    if dist < Config.MarkerInteractionDistance then
                        WF_DrawText3D(markerCoords + vector3(0.0, 0.0, 1.0), ('~o~[E] Tankstelle kaufen~s~\n%s\n~g~%d$~s~'):format(cfg.name, cfg.buyPrice))
                        if IsControlJustPressed(0, 38) then
                            WF_OpenBuyMenu(cfg.id)
                        end
                    end
                else
                    -- Mit Besitzer: dezenter blauer Marker, mehrzeiliger
                    -- Hilfstext statt mehrerer überlappender Marker.
                    DrawStationMarker(markerCoords, 80, 170, 255, 90)

                    if dist < Config.MarkerInteractionDistance then
                        -- Trucking-Job wird jetzt AUSSCHLIESSLICH über den
                        -- "Job"-Reiter im Boss-Menü gestartet (inkl.
                        -- Bestätigen-Dialog dort) - kein direkter Shortcut
                        -- mehr am Marker, damit auch Mitarbeiter (mit
                        -- eingeschränktem Zugriff) den gleichen, sauberen
                        -- Weg nutzen. "Mietlkw abladen" ist HIER raus - das
                        -- passiert jetzt an einem eigenen Marker am
                        -- LKW-Spawnpunkt weiter unten, nicht mehr hier am
                        -- Kauf-/Boss-Marker.
                        WF_DrawText3D(markerCoords + vector3(0.0, 0.0, 1.0), '~b~[E] Boss-Menü öffnen~s~')

                        if IsControlJustPressed(0, 38) then -- E
                            WCC_OpenBossMenu(cfg.id)
                        end
                    end
                end
            end

            -- Eigener Marker am LKW-Spawnpunkt zum Abladen, solange dort
            -- der eigene Job läuft - der Spieler soll den Mietlkw da
            -- abgeben, wo er ihn auch bekommen hat, nicht am allgemeinen
            -- Stations-/Boss-Marker.
            if WCC_JobActive and WCC_JobStationId == cfg.id then
                local sp = cfg.jobTruckSpawnCoords
                local hasCustomSpawn = sp and (sp.x ~= 0.0 or sp.y ~= 0.0)
                local unloadCoords = hasCustomSpawn and vector3(sp.x, sp.y, sp.z) or markerCoords
                local unloadDist = #(playerCoords - unloadCoords)

                if unloadDist < 20.0 then
                    wait = 0

                    local pulse = (math.sin(GetGameTimer() / 350.0) + 1.0) / 2.0
                    local alpha = math.floor(110 + pulse * 90)
                    DrawStationMarker(unloadCoords, 255, 220, 60, alpha)

                    if unloadDist < Config.MarkerInteractionDistance + 3.0 then
                        WF_DrawText3D(unloadCoords + vector3(0.0, 0.0, 1.0), '~y~[H] Mietlkw abladen~s~')
                        if IsControlJustPressed(0, 74) then -- H
                            WCC_UnloadTruck()
                        end
                    end
                end
            end
        end

        Wait(wait)
    end
end)
