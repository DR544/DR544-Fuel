-- ============================================================
-- wcc_fuel - client/rope.lua
-- Hilfsfunktionen für Zapfpistolen-Prop + Seil (Rope) zwischen
-- Zapfsäule <-> Hand und Zapfsäule <-> Fahrzeug.
-- Sinngemäß 1:1 vom Lade-Mechanismus aus wcc_chargingstations/client/rope.lua
-- übernommen, eigener Funktions-Namensraum (WF_*) da eigenständige Ressource.
-- ============================================================

-- Lädt ein Prop-Modell synchron (mit Timeout) und gibt true/false zurück
function WF_RequestModel(model)
    local hash = type(model) == 'string' and joaat(model) or model

    if HasModelLoaded(hash) then return true end

    RequestModel(hash)

    local timeout = 0
    while not HasModelLoaded(hash) and timeout < 5000 do
        Wait(10)
        timeout = timeout + 10
    end

    return HasModelLoaded(hash)
end

-- Erstellt ein physisches Seil ("Noodle") zwischen zwei Koordinaten. Wird
-- danach per WF_AttachRopeToEntities an zwei Entities gehängt und durch die
-- Rope-Physik-Engine des Spiels jeden Frame aktuell gehalten.
function WF_CreateRope(coordsFrom)
    local timeout = 0
    while not RopeAreTexturesLoaded() and timeout < 3000 do
        RopeLoadTextures()
        Wait(10)
        timeout = timeout + 10
    end

    if not RopeAreTexturesLoaded() then
        print('[wcc_fuel] Rope-Texturen konnten nicht geladen werden (Timeout).')
    end

    -- Parameterreihenfolge gegen ein echtes, produktiv laufendes FiveM-
    -- Fuel-Script gegengeprüft (MSK-Scripts/msk_fuel, client/fuel.lua) -
    -- die zuvor per Web-Suche "gefundene" abweichende Reihenfolge war
    -- falsch/halluziniert und hat die Rope kaputter gemacht statt sie zu
    -- reparieren. Echte Reihenfolge (durch das funktionierende Referenz-
    -- Script bestätigt):
    --   x, y, z, rotX, rotY, rotZ, length(initial), ropeType, maxLength,
    --   minLength, lengthChangeRate, rigid, breakWhenShot, p13,
    --   timeMultiplier, breakable
    -- D.h. der urspüngliche Code hier hatte die Reihenfolge schon richtig -
    -- der eigentliche Fehler war einzig, dass maxLength (Position 9) mit
    -- 1.5 viel zu klein war (man darf mit der Zapfpistole in der Hand laut
    -- Config.MaxDistanceFromPump bis 7.5m von der Säule weg). Jetzt
    -- großzügig hochgesetzt, der Rest bleibt nah am bestätigt
    -- funktionierenden Referenzwert. ropeType-Index (0=Rope, 1=Thick rope,
    -- 2=Thick cable, 3=Medium cable, 4=Cable, ...): 2 = deutlich dickere
    -- Kabel-Optik als vorher (war 4 = "Cable", jetzt "Thick cable").
    local rope = AddRope(
        coordsFrom.x, coordsFrom.y, coordsFrom.z,
        0.0, 0.0, 0.0,
        1.2,   -- length (initiale Länge -> sichtbarer Durchhang beim Anlegen)
        2,     -- ropeType (Thick cable - dicker als vorher)
        12.0,  -- maxLength (>= Config.MaxDistanceFromPump + Puffer)
        0.3,   -- minLength
        1.5,   -- lengthChangeRate
        false, -- rigid
        false, -- breakWhenShot
        false, -- p13
        1.0,   -- timeMultiplier
        true   -- breakable
    )

    if not rope or rope == 0 or not DoesRopeExist(rope) then
        print('[wcc_fuel] AddRope hat kein gültiges Rope-Handle geliefert!')
        return nil
    end

    -- ActivatePhysics statt StartRopeUnwindingFront - laut zwei echten,
    -- produktiv laufenden Referenz-Scripts (ND-Framework/ND_Fuel,
    -- MSK-Scripts/msk_fuel) ist DAS der Schritt, der die Rope tatsächlich
    -- sichtbar/simuliert macht, wenn sie direkt per AttachEntitiesToRope
    -- zwischen zwei Entities gespannt wird (StartRopeUnwindingFront ist
    -- eher für Winden/Abrollen aus einer "aufgerollten" Ausgangslänge
    -- gedacht und hat hier offenbar dazu geführt, dass gar nichts
    -- gerendert wurde). Kurzer Wait danach, damit die Physik einmal
    -- "ankommt", bevor der Aufrufer die Rope an die Entities hängt.
    ActivatePhysics(rope)
    Wait(50)

    return rope
end

-- Berechnet den WELT-Koordinaten-Anker für ein Entity (+ optionalem Bone),
-- den AttachEntitiesToRope tatsächlich erwartet (siehe Kommentar unten).
local function WF_GetRopeAnchorWorldCoords(entity, boneName, offset)
    if boneName then
        local boneIndex = GetEntityBoneIndexByName(entity, boneName)
        if boneIndex and boneIndex ~= -1 then
            local bonePos = GetWorldPositionOfEntityBone(entity, boneIndex)
            return vector3(bonePos.x + offset.x, bonePos.y + offset.y, bonePos.z + offset.z)
        end
    end

    return GetOffsetFromEntityInWorldCoords(entity, offset.x, offset.y, offset.z)
end

-- Verbindet zwei Entities per Seil.
function WF_AttachRopeToEntities(rope, entA, boneA, offsetA, entB, boneB, offsetB, length)
    if not rope or not DoesRopeExist(rope) then
        print('[wcc_fuel] WF_AttachRopeToEntities: ungültiges Rope-Handle, breche ab.')
        return
    end

    if not entA or not DoesEntityExist(entA) or not entB or not DoesEntityExist(entB) then
        print('[wcc_fuel] WF_AttachRopeToEntities: entA/entB existiert nicht.')
        return
    end

    -- WICHTIG: die x/y/z-Parameter von ATTACH_ENTITIES_TO_ROPE sind KEINE
    -- lokalen Offsets relativ zur Entity (so wurde es hier vorher benutzt),
    -- sondern absolute WELT-Koordinaten - bestätigt durch zwei echte,
    -- produktiv laufende Referenz-Scripts (ND-Framework/ND_Fuel,
    -- MSK-Scripts/msk_fuel), die dafür extra GetOffsetFromEntityInWorldCoords
    -- verwenden. Mit rohen kleinen Offsets wie (0,0,0.5) landete der
    -- Rope-Anker dadurch fälschlich in der Nähe des Karten-Nullpunkts
    -- (sichtbar als Seil "irgendwo in der Luft", nicht an Säule/Hand).
    -- Bone-Namen werden jetzt selbst in Weltkoordinaten aufgelöst (siehe
    -- WF_GetRopeAnchorWorldCoords) statt sie zusätzlich an das Native zu
    -- übergeben - vermeidet, dass Bone-Parameter und explizite Koordinaten
    -- sich gegenseitig widersprechen.
    local posA = WF_GetRopeAnchorWorldCoords(entA, boneA, offsetA)
    local posB = WF_GetRopeAnchorWorldCoords(entB, boneB, offsetB)

    AttachEntitiesToRope(
        rope,
        entA, entB,
        posA.x, posA.y, posA.z,
        posB.x, posB.y, posB.z,
        length, false, false,
        '', ''
    )
end

function WF_DeleteRope(rope)
    if rope and DoesRopeExist(rope) then
        DeleteRope(rope)
    end
end
