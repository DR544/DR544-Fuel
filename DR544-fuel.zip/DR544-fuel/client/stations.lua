-- ============================================================
-- wcc_fuel - client/stations.lua
-- Blip-Verwaltung + Server-Sync-Empfang für die ca. 30 Standard-GTA-
-- Tankstellen. Interaktionen (Tanken/Kaufen/Boss/Job/Abladen) laufen in
-- eigenen Dateien (client/target.lua, client/markers.lua).
-- ============================================================

-- Öffentlicher Live-Zustand aller Stationen (vom Server synchronisiert)
WCC_FuelStations = WCC_FuelStations or {}

local blips = {}

-- ------------------------------------------------------------
-- Blip-Verwaltung
-- ------------------------------------------------------------

local function RemoveStationBlip(id)
    if blips[id] then
        RemoveBlip(blips[id])
        blips[id] = nil
    end
end

local function CreateOrUpdateBlip(id, data)
    local cfg = Config.StationById[id]
    if not cfg then return end

    RemoveStationBlip(id)

    local blip = AddBlipForCoord(cfg.blipCoords.x, cfg.blipCoords.y, cfg.blipCoords.z)
    SetBlipSprite(blip, data.blip and data.blip.sprite or Config.DefaultBlip.sprite)
    SetBlipColour(blip, data.blip and data.blip.color or Config.DefaultBlip.color)
    SetBlipScale(blip, Config.DefaultBlip.scale)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(data.name or cfg.name)
    EndTextCommandSetBlipName(blip)

    blips[id] = blip
end

-- Für client/job.lua: den bestehenden Stations-Blip herausgeben, um z.B.
-- nach dem Beladen des Mietlkw die Route dorthin einzuzeichnen
-- (SetBlipRoute), statt einen zusätzlichen separaten Wegpunkt-Blip zu
-- erzeugen.
function WCC_GetStationBlip(id)
    return blips[id]
end

-- ------------------------------------------------------------
-- Server-Sync empfangen
-- ------------------------------------------------------------

RegisterNetEvent('wcc_fuel:syncStations', function(stations)
    WCC_FuelStations = stations

    for id, data in pairs(stations) do
        CreateOrUpdateBlip(id, data)
    end
end)

CreateThread(function()
    Wait(1000)
    TriggerServerEvent('wcc_fuel:requestSync')
end)

-- ------------------------------------------------------------
-- Tanken läuft jetzt komplett über den Prop/Rope-Flow (client/props.lua,
-- client/target.lua, client/refuel.lua). Kaufen/Boss-Menü/Job-Start/Abladen
-- laufen über native Marker + [E] (client/markers.lua) - ox_target wird in
-- dieser Ressource NUR NOCH für die Zapfpistole verwendet.
-- ------------------------------------------------------------
