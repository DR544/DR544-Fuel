-- ============================================================
-- wcc_fuel - client/marker_ui.lua
-- Kauf-Bestätigungs-UI (NUI), geöffnet vom [E]-Marker an unverkauften
-- Stationen (siehe client/markers.lua). Nutzt denselben Backdrop/Panel wie
-- das Boss-Menü (web/index.html, state.mode = 'buy'), ruft den bereits
-- bestehenden wcc_fuel:buyStation-Callback auf - keine doppelte Logik.
-- ============================================================

local isBuyOpen = false

local function CloseBuyMenu()
    if not isBuyOpen then return end
    isBuyOpen = false
    WF_NuiWindowClosed('buy')
    SendNUIMessage({ action = 'close' })
end

WF_RegisterNuiWindow('buy', CloseBuyMenu)

function WF_OpenBuyMenu(stationId)
    if isBuyOpen then return end

    local cfg = Config.StationById[stationId]
    if not cfg then return end

    local data = WCC_FuelStations[stationId]
    if data and data.hasOwner then
        lib.notify({ position = 'bottom-right', title = 'Tankstellen', description = 'Diese Tankstelle gehört bereits jemandem.', type = 'error', duration = 5000 })
        return
    end

    isBuyOpen = true
    WF_NuiWindowOpened('buy')
    SendNUIMessage({
        action = 'openBuy',
        stationId = stationId,
        name = cfg.name,
        buyPrice = cfg.buyPrice,
    })
end

RegisterNUICallback('buy:close', function(_, cb)
    CloseBuyMenu()
    cb('ok')
end)

RegisterNUICallback('buy:confirm', function(data, cb)
    local result = lib.callback.await('wcc_fuel:buyStation', false, data.stationId)
    cb(result)
    if result and result.ok then
        CloseBuyMenu()
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        if isBuyOpen then
            if IsControlJustPressed(0, 200) or IsControlJustPressed(0, 322) then
                CloseBuyMenu()
            end
        else
            Wait(400)
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() and isBuyOpen then
        CloseBuyMenu()
    end
end)
