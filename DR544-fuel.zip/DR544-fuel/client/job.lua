-- ============================================================
-- wcc_fuel - client/job.lua
-- Trucking-Job: LKW+Tankanhänger spawnen, zum ausgelosten Abholpunkt
-- fahren, dort beladen (Marker + [E] + Progressbar), zur eigenen Tankstelle
-- zurückfahren und abladen (siehe client/markers.lua für die
-- "LKW abladen"-Option).
-- ============================================================

WCC_JobActive = false
WCC_JobStationId = nil

local jobTruck = nil
local jobTrailer = nil
local pickupBlip = nil
local pickupCoords = nil
local pickupLabel = nil

local function DeleteJobVehicle()
    if jobTrailer and DoesEntityExist(jobTrailer) then
        DeleteEntity(jobTrailer)
    end
    if jobTruck and DoesEntityExist(jobTruck) then
        DeleteEntity(jobTruck)
    end
    jobTruck = nil
    jobTrailer = nil
end

local function RemovePickupZone()
    pickupCoords = nil
    pickupLabel = nil
    if pickupBlip then
        RemoveBlip(pickupBlip)
        pickupBlip = nil
    end
end

local function EndJob()
    -- Vor dem Zurücksetzen von WCC_JobStationId noch die zuletzt per
    -- SetBlipRoute markierte Rückweg-Route auf dem Stations-Blip wieder
    -- ausschalten - sonst bliebe die GPS-Linie zur Station dauerhaft
    -- eingezeichnet, auch nachdem der Job längst vorbei/abgebrochen ist.
    if WCC_JobStationId and WCC_GetStationBlip then
        local stationBlip = WCC_GetStationBlip(WCC_JobStationId)
        if stationBlip then
            SetBlipRoute(stationBlip, false)
        end
    end

    WCC_JobActive = false
    WCC_JobStationId = nil
    RemovePickupZone()
    DeleteJobVehicle()
    TriggerServerEvent('wcc_fuel:cancelJob')

    -- Aktiven GPS-Wegpunkt (Fallback-SetNewWaypoint beim Beladen, s.u.)
    -- zurücksetzen - sonst bleibt die Distanz-/Richtungsanzeige unten
    -- links dauerhaft sichtbar, auch nachdem der Job längst vorbei/
    -- abgebrochen ist.
    SetWaypointOff()
end

-- Manueller Notausstieg, falls ein Job aus irgendeinem Grund "hängen"
-- bleibt (z.B. LKW irgendwo verloren, ohne dass er zerstört wurde) - räumt
-- garantiert auf und schaltet u.a. den Wegpunkt/Marker-Text wieder ab.
RegisterCommand('fuelcanceljob', function()
    if not WCC_JobActive then
        lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = 'Du hast aktuell keinen laufenden Job.', type = 'inform', duration = 5000 })
        return
    end

    lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = 'Job abgebrochen.', type = 'inform', duration = 5000 })
    EndJob()
end, false)

-- ------------------------------------------------------------
-- Beladen am Abholpunkt
-- ------------------------------------------------------------

local function DoLoadTruck()
    if not lib.progressBar({
        duration = Config.JobLoadDuration,
        label = 'Mietlkw wird beladen...',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
    }) then
        return
    end

    -- WICHTIG: result kann nil sein (Server-Timeout/-Fehler), nicht nur
    -- { ok = false } - ein direktes result.ok ohne diesen Guard crashte
    -- hier mit "attempt to index a nil value", WOMIT RemovePickupZone()
    -- weiter unten nie erreicht wurde und sowohl der Missionstext als auch
    -- die alte Route zum Abholpunkt für immer hängen blieben.
    local result = lib.callback.await('wcc_fuel:loadTruck', false)
    if not result or not result.ok then
        lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = (result and result.reason) or 'Beladen fehlgeschlagen (keine Antwort vom Server).', type = 'error', duration = 5000 })
        return
    end

    lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = ('Mietlkw beladen: %d Liter. Fahre zurück zur Tankstelle.'):format(result.loaded), type = 'success', duration = 5000 })
    RemovePickupZone()

    -- Rückweg zur eigenen Tankstelle markieren. SetNewWaypoint ist hier
    -- bewusst die PRIMÄRE Methode (nicht nur Fallback) - das ist der
    -- tatsächliche native GTA-"Zielwegpunkt" (gelber Leuchtstrahl + GPS-
    -- Route), unabhängig von einem bestimmten Blip-Objekt. SetBlipRoute
    -- auf dem Stations-Blip allein reichte nicht: der Blip wird bei jedem
    -- Stations-Sync (client/stations.lua, passiert bei JEDER Bank-/Preis-
    -- änderung IRGENDEINER Station im Umkreis) komplett neu erstellt, was
    -- eine zuvor gesetzte Route auf dem alten Blip-Handle sofort wieder
    -- verwirft - der alte Wegpunkt zum Abholpunkt blieb dadurch stehen.
    local cfg = Config.StationById[WCC_JobStationId]
    if cfg then
        SetNewWaypoint(cfg.coords.x, cfg.coords.y)
    end

    local stationBlip = WCC_GetStationBlip and WCC_GetStationBlip(WCC_JobStationId)
    if stationBlip then
        SetBlipRoute(stationBlip, true)
        SetBlipRouteColour(stationBlip, 5)
    end
end

-- ------------------------------------------------------------
-- Abladen an der Tankstelle
-- ------------------------------------------------------------

function WCC_UnloadTruck()
    if not WCC_JobActive then return end

    if not lib.progressBar({
        duration = Config.JobUnloadDuration,
        label = 'Mietlkw wird abgeladen...',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
    }) then
        return
    end

    local result = lib.callback.await('wcc_fuel:unloadTruck', false)
    if not result or not result.ok then
        lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = (result and result.reason) or 'Abladen fehlgeschlagen (keine Antwort vom Server).', type = 'error', duration = 5000 })
        return
    end

    lib.notify({ position = 'bottom-right',
        title = 'Trucking-Job',
        description = ('%.0f Liter abgeladen. Stationstank: %.0f / %d Liter.'):format(result.pumped, result.stationTank, result.stationCapacity),
        type = 'success',
        duration = 5000,
    })

    if result.finished then
        lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = 'Job abgeschlossen, Mietlkw wird zurückgegeben.', type = 'inform', duration = 5000 })
        EndJob()
    end
end

-- ------------------------------------------------------------
-- Dauerhafter GTA-Online-Missionstext unten ("Fahre zu ~y~Ort~s~") -
-- solange der Job läuft, egal ob Hin- oder Rückweg. Läuft über
-- BeginTextCommandPrint/EndTextCommandPrint (das native "Print"-Subtitle,
-- das GTA Online selbst für Missionsziele nutzt) statt Hilfetext/3D-Text -
-- muss dafür jeden Frame mit kurzer Dauer neu aufgerufen werden, sonst
-- verblasst es nach der jeweiligen duration wieder. ~y~...~s~ ist GTAs
-- eigener Textfarb-Code (y = gelb, s = zurück auf Standardfarbe).
-- ------------------------------------------------------------

CreateThread(function()
    while true do
        local wait = 500

        if WCC_JobActive then
            wait = 0
            local text = nil

            if pickupCoords then
                -- Hinweg: noch nicht beladen
                text = ('Fahre zum Abholpunkt: ~y~%s~s~'):format(pickupLabel or 'Ölfeld')
            else
                -- Rückweg: beladen, zurück zur eigenen Tankstelle
                local cfg = Config.StationById[WCC_JobStationId]
                local liveName = WCC_FuelStations and WCC_FuelStations[WCC_JobStationId] and WCC_FuelStations[WCC_JobStationId].name
                local stationName = liveName or (cfg and cfg.name) or 'deiner Tankstelle'
                text = ('Fahre zurück zu deiner ~y~%s~s~'):format(stationName)
            end

            if text then
                BeginTextCommandPrint('STRING')
                AddTextComponentSubstringPlayerName(text)
                EndTextCommandPrint(600, true)
            end
        end

        Wait(wait)
    end
end)

-- ------------------------------------------------------------
-- Job starten
-- ------------------------------------------------------------

function WCC_StartJob(stationId)
    if WCC_JobActive then
        lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = 'Du hast bereits einen laufenden Job.', type = 'error', duration = 5000 })
        return
    end

    local result = lib.callback.await('wcc_fuel:startJob', false, stationId)
    if not result or not result.ok then
        lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = (result and result.reason) or 'Job konnte nicht gestartet werden (keine Antwort vom Server).', type = 'error', duration = 5000 })
        return
    end

    WCC_JobActive = true
    WCC_JobStationId = stationId

    local cfg = Config.StationById[stationId]

    -- LKW + Tankanhänger an der Tankstelle spawnen
    lib.requestModel(Config.JobTruckModel)
    lib.requestModel(Config.JobTrailerModel)

    -- Eigener, in der Config einstellbarer Spawnpunkt (jobTruckSpawnCoords)
    -- statt fest neben der Zapfsäule - solange der noch nicht befüllt wurde
    -- (0,0,0,0 Platzhalter), wird wie bisher neben cfg.coords gespawnt.
    local spawnPoint = cfg.jobTruckSpawnCoords
    local hasCustomSpawn = spawnPoint and (spawnPoint.x ~= 0.0 or spawnPoint.y ~= 0.0 or spawnPoint.z ~= 0.0)
    local heading = hasCustomSpawn and (spawnPoint.w or 0.0) or 0.0
    local spawnCoords = hasCustomSpawn and vector3(spawnPoint.x, spawnPoint.y, spawnPoint.z) or cfg.coords

    local truckOffsetX = hasCustomSpawn and 0.0 or 4.0
    local trailerOffsetX = hasCustomSpawn and 6.0 or 12.0

    jobTruck = CreateVehicle(Config.JobTruckModel, spawnCoords.x + truckOffsetX, spawnCoords.y, spawnCoords.z, heading, true, false)
    jobTrailer = CreateVehicle(Config.JobTrailerModel, spawnCoords.x + trailerOffsetX, spawnCoords.y, spawnCoords.z, heading, true, false)

    SetVehicleOnGroundProperly(jobTruck)
    SetVehicleOnGroundProperly(jobTrailer)
    AttachVehicleToTrailer(jobTruck, jobTrailer, 3.5)

    SetEntityAsMissionEntity(jobTruck, true, true)
    SetEntityAsMissionEntity(jobTrailer, true, true)

    SetVehicleNumberPlateText(jobTruck, 'WCCFUEL')
    SetVehicleFuelLevel(jobTruck, 100.0)

    -- Explizit entriegelt spawnen (0 = entriegelt) - manche Server haben
    -- Fahrzeugschlüssel-/Anti-Diebstahl-Ressourcen, die frisch erstellte
    -- Fahrzeuge ohne zugewiesenen Besitzer automatisch verriegeln. Dadurch
    -- kam man nach dem Aussteigen (z.B. am Abholpunkt) nicht mehr rein.
    -- Der Wartungs-Thread weiter unten hält beide Fahrzeuge zusätzlich
    -- dauerhaft entriegelt, solange der Job läuft.
    SetVehicleDoorsLocked(jobTruck, 0)
    SetVehicleDoorsLocked(jobTrailer, 0)

    TaskWarpPedIntoVehicle(PlayerPedId(), jobTruck, -1)

    SetModelAsNoLongerNeeded(Config.JobTruckModel)
    SetModelAsNoLongerNeeded(Config.JobTrailerModel)

    -- Blip + Wegpunkt zum Abholpunkt
    local p = result.pickup
    pickupBlip = AddBlipForCoord(p.x, p.y, p.z)
    SetBlipSprite(pickupBlip, 477)
    SetBlipColour(pickupBlip, 5)
    SetBlipRoute(pickupBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(p.label or 'Abholpunkt')
    EndTextCommandSetBlipName(pickupBlip)

    -- Beladen läuft über native Marker + [E] statt ox_target (siehe
    -- Marker-Thread weiter unten) - kein eigenes Zone-Objekt mehr nötig.
    pickupCoords = vector3(p.x, p.y, p.z)
    pickupLabel = p.label or 'Abholpunkt'

    lib.notify({ position = 'bottom-right', title = 'Trucking-Job', description = ('Fahre zum Abholpunkt: %s'):format(p.label or ''), type = 'inform', duration = 5000 })
end

-- ------------------------------------------------------------
-- Marker + [E] am Abholpunkt zum Beladen (ox_target-frei, siehe Punkt 2)
-- ------------------------------------------------------------

CreateThread(function()
    while true do
        local wait = 500

        if pickupCoords then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local dist = #(coords - pickupCoords)

            -- 5x weiter sichtbar als vorher (15.0 -> 75.0), damit der
            -- Abholpunkt schon von der anderen Straßenseite/aus der Ferne
            -- erkennbar ist, nicht erst wenn man quasi davor steht.
            if dist < 75.0 then
                wait = 0

                -- Großer, pulsierender Ring wie ein GTA-Online-Rennen-
                -- Checkpoint (man fährt mit dem LKW mittendurch), statt
                -- eines kleinen, kaum sichtbaren Markers.
                local pulse = (math.sin(GetGameTimer() / 350.0) + 1.0) / 2.0 -- 0..1
                local alpha = math.floor(120 + pulse * 100)
                DrawMarker(1, pickupCoords.x, pickupCoords.y, pickupCoords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 7.0, 7.0, 3.0, 255, 176, 32, alpha, false, true, 2, false, nil, nil, false)

                if dist < Config.MarkerInteractionDistance then
                    local ped = PlayerPedId()
                    -- Nur beladbar, wenn man selbst im ZUGEWIESENEN Miet-LKW
                    -- sitzt (Fahrersitz) - zu Fuß oder mit einem beliebigen
                    -- eigenen Fahrzeug darf hier nichts passieren, sonst
                    -- könnte man den Sprit ohne echten LKW+Anhänger "abholen".
                    -- NUR der LKW selbst muss exakt im (kleinen) Marker-
                    -- Punkt stehen (dist oben misst die Spielerposition, der
                    -- Spieler sitzt ja im LKW) - der Anhänger muss NICHT mehr
                    -- exakt im selben Punkt/noch angekuppelt sein, sondern
                    -- nur irgendwo im 20m-Umkreis des Abholpunkts stehen
                    -- (z.B. auch abgekoppelt daneben geparkt).
                    local trailerNearby = jobTrailer and DoesEntityExist(jobTrailer)
                        and #(GetEntityCoords(jobTrailer) - pickupCoords) <= 20.0

                    local inJobTruck = jobTruck and DoesEntityExist(jobTruck)
                        and GetVehiclePedIsIn(ped, false) == jobTruck
                        and GetPedInVehicleSeat(jobTruck, -1) == ped
                        and trailerNearby

                    if inJobTruck then
                        WF_DrawText3D(pickupCoords + vector3(0.0, 0.0, 1.0), ('[E] Mietlkw beladen (%s)'):format(pickupLabel or ''))
                        if IsControlJustPressed(0, 38) then
                            DoLoadTruck()
                        end
                    else
                        WF_DrawText3D(pickupCoords + vector3(0.0, 0.0, 1.0), 'Du musst mit dem Miet-LKW hier sein (Anhänger im Umkreis von 20m), um zu beladen.')
                    end
                end
            end
        end

        Wait(wait)
    end
end)

-- ------------------------------------------------------------
-- Job abbrechen, wenn LKW/Anhänger zerstört wurde ODER schlicht nicht mehr
-- existiert (z.B. durch Entity-Cleanup, Server-Restart der Ressource o.ä.) -
-- vorher wurde nur "zerstört" geprüft und nur beim LKW, nicht beim
-- Anhänger; verschwand das Fahrzeug einfach (DoesEntityExist == false),
-- blieb der Job für immer "aktiv" hängen. Bei Verlust: Strafe aus der
-- Tankstellen-Bank abziehen (server-seitig, nie unter 0) und den Spieler
-- zurück zur Tankstelle teleportieren.
-- ------------------------------------------------------------

local function IsVehicleGone(veh)
    return not veh or veh == 0 or not DoesEntityExist(veh) or IsEntityDead(veh) or GetEntityHealth(veh) <= 0
end

CreateThread(function()
    while true do
        Wait(2000)

        if WCC_JobActive then
            -- Solange der Job läuft: dauerhaft entriegelt halten, falls eine
            -- andere Ressource die Fahrzeuge zwischenzeitlich verriegelt.
            if jobTruck and DoesEntityExist(jobTruck) then SetVehicleDoorsLocked(jobTruck, 0) end
            if jobTrailer and DoesEntityExist(jobTrailer) then SetVehicleDoorsLocked(jobTrailer, 0) end

            if IsVehicleGone(jobTruck) or IsVehicleGone(jobTrailer) then
                local stationId = WCC_JobStationId
                local cfg = stationId and Config.StationById[stationId]

                local result = lib.callback.await('wcc_fuel:jobVehicleLost', false)
                if result and result.ok and result.deducted and result.deducted > 0 then
                    lib.notify({ position = 'bottom-right',
                        title = 'Trucking-Job',
                        description = ('Mietlkw/-anhänger verloren. Strafe: %d$ von der Tankstellen-Bank (%s) abgezogen.'):format(result.deducted, result.stationName or 'deine Station'),
                        type = 'error',
                        duration = 7000,
                    })
                else
                    lib.notify({ position = 'bottom-right',
                        title = 'Trucking-Job',
                        description = 'Mietlkw/-anhänger verloren. Job abgebrochen (Tankstellen-Bank hatte kein Guthaben mehr für die Strafe).',
                        type = 'error',
                        duration = 7000,
                    })
                end

                EndJob()

                if cfg then
                    DoScreenFadeOut(300)
                    Wait(350)
                    local ped = PlayerPedId()
                    SetEntityCoords(ped, cfg.coords.x, cfg.coords.y, cfg.coords.z, false, false, false, true)
                    Wait(200)
                    DoScreenFadeIn(400)
                end
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    if WCC_JobActive then
        EndJob()
    end
end)
