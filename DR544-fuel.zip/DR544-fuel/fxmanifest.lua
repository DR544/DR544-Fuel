fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'you'
description 'WCC Fuel - Tankstellen-Wirtschaftssystem (ESX Legacy, ox_target, ox_lib, oxmysql), Ersatz fuer LegacyFuel'
version '1.0.0'

shared_script '@ox_lib/init.lua'
shared_script 'config.lua'

ui_page 'web/index.html'

files {
    'web/index.html',
}

client_scripts {
    'client/main.lua',
    'client/nui_state.lua',
    'client/rope.lua',
    'client/pump_resolver.lua',
    'client/refuel.lua',
    'client/target.lua',
    'client/stations.lua',
    'client/markers.lua',
    'client/marker_ui.lua',
    'client/job.lua',
    'client/bossmenu_bridge.lua',
    'client/bossmenu_ui.lua',
    'client/debug_scan.lua',
}

server_scripts {
    'server/main.lua',
    'server/stations.lua',
    'server/fuel.lua',
    'server/job.lua',
    'server/employees.lua',
    'server/exports.lua',
    'server/debug_scan.lua',
}

dependencies {
    'es_extended',
    'ox_lib',
    'ox_target',
    'oxmysql',
}
