-- ============================================================
-- wcc_fuel - fix_ownerless_prices.sql
-- Einmaliges Korrektur-Script: setzt bei allen besitzerlosen Tankstellen
-- (owner_identifier IS NULL), deren aktueller Preis außerhalb der
-- konfigurierten Spanne (Config.OwnerlessFuelPriceMin/Max = 13.0/18.0)
-- liegt, einen neuen zufälligen Preis innerhalb 13,00 - 18,00 $.
--
-- Betrifft NUR alte/manuell abweichende Datensätze - neue sowie beim
-- Einziehen (Repossession) zurückgesetzte Stationen bekommen ihren
-- Zufallspreis ohnehin schon automatisch aus dieser Spanne (siehe
-- server/main.lua WccFuel_RandomOwnerlessPrice() und
-- server/stations.lua ~Zeile 307).
--
-- Einmal ausführen, dann kann diese Datei wieder gelöscht werden.
-- ============================================================

UPDATE `wcc_fuel_stations`
SET `price` = ROUND(13.0 + (RAND() * (18.0 - 13.0)), 2)
WHERE `owner_identifier` IS NULL
  AND (`price` < 13.0 OR `price` > 18.0);
