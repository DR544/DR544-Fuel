-- ============================================================
-- wcc_fuel - server/exports.lua
-- Exporte für die Phone-App (wcc_fuelmanager) und für andere
-- Ressourcen (LegacyFuel-Kompatibilität).
-- ============================================================

-- Liefert öffentliche Stationsdaten (für die Kunden-Liste der App)
local function GetStationsData()
    local stations = {}

    for id, s in pairs(WccFuel.Stations) do
        local cfg = Config.StationById[id]
        stations[#stations + 1] = {
            id = id,
            name = s.name,
            price = s.price,
            hasOwner = s.ownerIdentifier ~= nil,
            coords = { x = cfg.coords.x, y = cfg.coords.y, z = cfg.coords.z },
        }
    end

    table.sort(stations, function(a, b) return a.id < b.id end)

    return stations
end
exports('GetStationsData', GetStationsData)

-- Kaufverlauf für die App (identifier -> callback(rows))
exports('GetFuelHistoryForIdentifier', GetFuelHistoryForIdentifier)

-- Eigene Tankstellen des Spielers inkl. Boss-Daten (Callback wird
-- clientseitig ohnehin per lib.callback direkt aufgerufen, dieser Export
-- ist die Server->Server-Variante für die Phone-Bridge).
local function GetMyStationsForIdentifier(identifier, cb)
    local owned = {}

    for id, s in pairs(WccFuel.Stations) do
        if s.ownerIdentifier == identifier then
            owned[#owned + 1] = {
                id = s.id,
                name = s.name,
                price = s.price,
                level = s.level,
                truckLevel = s.truckLevel,
                tankLiters = s.tankLiters,
                tankCapacity = Config.StationTankCapacityByLevel[s.level],
                truckCapacity = Config.TruckCapacityByLevel[s.truckLevel],
                bank = s.bank,
                lastDeposit = s.lastDeposit,
                blip = s.blip,
                nextLevelCost = Config.StationLevelUpCost[s.level],
                nextTruckLevelCost = Config.TruckLevelUpCost[s.truckLevel],
            }
        end
    end

    table.sort(owned, function(a, b) return a.id < b.id end)
    cb(owned)
end
exports('GetMyStationsForIdentifier', GetMyStationsForIdentifier)

-- ------------------------------------------------------------
-- LegacyFuel-Kompatibilität (server-seitig genutzt manche Scripts nicht,
-- die eigentliche Kompat-Schicht liegt größtenteils clientseitig, siehe
-- client/main.lua - dieser Export deckt reine Server-Abfragen ab)
-- ------------------------------------------------------------

local function GetFuel(plate, cb)
    if not plate then cb(Config.DefaultFuelLevel) return end
    plate = plate:gsub('%s+', ''):upper()

    local result = exports.oxmysql:scalarSync('SELECT `fuel` FROM `wcc_fuel_vehicles` WHERE `plate` = ?', { plate })
    cb(tonumber(result) or Config.DefaultFuelLevel)
end
exports('GetFuel', GetFuel)

-- Identifier-Auflösung (ESX-Identifier mit License-Fallback) als Export,
-- damit wcc_fuelmanager (und andere Ressourcen) nicht ihre eigene, ggf.
-- abweichende Kopie dieser Logik pflegen müssen.
exports('GetIdentifier', GetIdentifier)

-- ------------------------------------------------------------
-- Vertrauenswürdiger Fuel-Credit für andere Ressourcen (z.B.
-- wcc_chargingstations), die über den externen SetFuel/GetFuel-Pfad
-- (client/main.lua, WccFuel_SetFuel -> 'wcc_fuel:externalFuelUpdate')
-- den Tankstand eines Fahrzeugs ERHÖHEN müssen (z.B. während des Ladens
-- eines E-Autos), ohne dass unser Anti-Cheat das als Cheat-Versuch
-- verwirft. Nur über Server-zu-Server-Exports aufrufbar (nicht von
-- Clients auslösbar), daher sicher genug, um den src-Abgleich zu
-- überspringen (siehe WccFuel_SetExternalCredit in server/fuel.lua).
exports('GrantFuelCredit', function(plate, maxFuel, ttlSeconds)
    WccFuel_SetExternalCredit(plate, maxFuel, ttlSeconds, true, nil)
end)
