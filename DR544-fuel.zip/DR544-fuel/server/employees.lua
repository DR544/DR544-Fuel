-- ============================================================
-- wcc_fuel - server/employees.lua
-- Mitarbeiter-Verwaltung (max 3 je Tankstelle, nur Besitzer) +
-- automatische Lohn-Auszahlung alle 12 Echtzeit-Stunden.
-- ============================================================

local function IsOwner(src, stationId)
    local s = WccFuel.Stations[stationId]
    if not s or not s.ownerIdentifier then return false end
    return s.ownerIdentifier == GetIdentifier(src)
end

-- ------------------------------------------------------------
-- Mitarbeiterliste abrufen (Boss-Menü)
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:getEmployees', function(src, stationId)
    if not IsOwner(src, stationId) then return {} end

    local rows = exports.oxmysql:querySync(
        'SELECT `identifier`, `name`, `wage`, `hired_at` FROM `wcc_fuel_employees` WHERE `station_id` = ?',
        { stationId }
    )

    return rows or {}
end)

-- Sucht online Spieler für die Mitarbeiter-Auswahl im Boss-Menü - erkennt
-- automatisch, ob eingegeben wurde:
--   - eine Server-ID (Eingabe besteht NUR aus Ziffern) - dann reicht schon
--     1 Zeichen, da IDs auch einstellig sein können (z.B. "3"), es wird
--     exakt ODER per Präfix verglichen (z.B. "1" findet auch 1, 12, 19)
--   - ein RP-Name (Eingabe enthält Buchstaben) - mind. 2 Zeichen, dabei
--     müssen ALLE eingegebenen Wörter im Namen vorkommen, Reihenfolge
--     egal ("Mustermann Max" findet denselben Spieler wie "Max Mustermann")
lib.callback.register('wcc_fuel:searchPlayers', function(src, query)
    query = tostring(query or ''):match('^%s*(.-)%s*$') -- trim

    if query == '' then return {} end

    local isNumeric = query:match('^%d+$') ~= nil
    if not isNumeric and #query < 2 then return {} end

    local terms = {}
    if not isNumeric then
        for word in query:lower():gmatch('%S+') do
            terms[#terms + 1] = word
        end
    end

    local results = {}
    for _, playerIdStr in ipairs(GetPlayers()) do
        local playerId = tonumber(playerIdStr)
        local xPlayer = ESX.GetPlayerFromId(playerId)

        if xPlayer then
            -- RP-Name (ESX Identity) bevorzugt, Rockstar-/Steam-Name als
            -- Fallback falls kein Identity-System aktiv ist.
            local name = (xPlayer.getName and xPlayer.getName()) or GetPlayerName(playerId) or 'Unbekannt'
            local matched

            if isNumeric then
                local idStr = tostring(playerId)
                matched = idStr == query or idStr:sub(1, #query) == query
            else
                local nameLower = name:lower()
                matched = true
                for _, term in ipairs(terms) do
                    if not nameLower:find(term, 1, true) then
                        matched = false
                        break
                    end
                end
            end

            if matched then
                results[#results + 1] = { identifier = xPlayer.identifier, name = name, source = playerId }
            end
        end
        if #results >= 10 then break end
    end

    return results
end)

-- ------------------------------------------------------------
-- Mitarbeiter hinzufügen
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:addEmployee', function(src, stationId, targetIdentifier, targetName)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    if not targetIdentifier or targetIdentifier == '' then
        return { ok = false, reason = 'Ungültiger Spieler.' }
    end

    if targetIdentifier == GetIdentifier(src) then
        return { ok = false, reason = 'Du kannst dich nicht selbst als Mitarbeiter hinzufügen.' }
    end

    local count = exports.oxmysql:scalarSync('SELECT COUNT(*) FROM `wcc_fuel_employees` WHERE `station_id` = ?', { stationId })
    if (tonumber(count) or 0) >= Config.MaxEmployeesPerStation then
        return { ok = false, reason = ('Maximal %d Mitarbeiter je Tankstelle erlaubt.'):format(Config.MaxEmployeesPerStation) }
    end

    local ok = pcall(function()
        exports.oxmysql:insert(
            'INSERT INTO `wcc_fuel_employees` (`station_id`, `identifier`, `name`, `wage`, `hired_at`) VALUES (?, ?, ?, 0, ?)',
            { stationId, targetIdentifier, targetName or 'Unbekannt', os.time() }
        )
    end)

    if not ok then
        return { ok = false, reason = 'Dieser Spieler ist bereits Mitarbeiter dieser Tankstelle.' }
    end

    return { ok = true }
end)

-- ------------------------------------------------------------
-- Mitarbeiter entfernen
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:removeEmployee', function(src, stationId, targetIdentifier)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    exports.oxmysql:execute('DELETE FROM `wcc_fuel_employees` WHERE `station_id` = ? AND `identifier` = ?', { stationId, targetIdentifier })

    return { ok = true }
end)

-- ------------------------------------------------------------
-- Lohn eines Mitarbeiters ändern
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:setEmployeeWage', function(src, stationId, targetIdentifier, wage)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    wage = math.max(0, math.floor(tonumber(wage) or 0))

    exports.oxmysql:execute('UPDATE `wcc_fuel_employees` SET `wage` = ? WHERE `station_id` = ? AND `identifier` = ?', { wage, stationId, targetIdentifier })

    return { ok = true }
end)

-- ------------------------------------------------------------
-- Lohn-Auszahlungs-Intervall je Station einstellen - NUR der Besitzer,
-- NUR über das Boss-Menü VOR ORT (die Phone-App ruft diesen Callback
-- bewusst nicht auf, siehe wcc_fuelmanager/ui/index.html).
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:setWageInterval', function(src, stationId, hours)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    hours = tonumber(hours)
    local allowed = false
    for _, h in ipairs(Config.WageIntervalOptions) do
        if h == hours then allowed = true break end
    end
    if not allowed then
        return { ok = false, reason = 'Ungültiges Intervall.' }
    end

    local s = WccFuel.Stations[stationId]
    s.wagePayoutIntervalHours = hours

    PersistStation(stationId)

    return { ok = true, station = s }
end)

-- ------------------------------------------------------------
-- Automatische Lohn-Auszahlung, Intervall je Station einstellbar (siehe
-- oben, Standard Config.DefaultWageIntervalHours).
-- Läuft unabhängig davon, ob der Mitarbeiter online ist: Ist er online,
-- wird direkt aufs Bankkonto gezahlt. Ist er offline, wird der Lohn
-- direkt in der `users`-Tabelle (ESX Bankkonto) gutgeschrieben, sofern
-- die Spalte existiert - andernfalls beim nächsten Login nachgeholt, da
-- ESX beim Verbinden ohnehin die Account-Werte aus der DB lädt.
-- ------------------------------------------------------------

local function PayWagesForStation(stationId, s)
    if s.bank <= 0 then return end

    local employees = exports.oxmysql:querySync('SELECT `identifier`, `wage` FROM `wcc_fuel_employees` WHERE `station_id` = ?', { stationId })
    if not employees then return end

    for _, emp in ipairs(employees) do
        if emp.wage and emp.wage > 0 and s.bank >= emp.wage then
            s.bank = s.bank - emp.wage

            -- Online? Direkt über ESX auszahlen.
            local paid = false
            for _, playerId in ipairs(GetPlayers()) do
                local numId = tonumber(playerId)
                if GetIdentifier(numId) == emp.identifier then
                    local xTarget = ESX.GetPlayerFromId(numId)
                    if xTarget then
                        xTarget.addAccountMoney(Config.PaymentAccount, emp.wage, 'Lohn: ' .. s.name)
                        paid = true
                    end
                    break
                end
            end

            -- Offline: direkt in der DB gutschreiben (ESX Standard-Tabelle
            -- `users`, Spalte `bank`). ANPASSEN falls dein Server ein
            -- abweichendes Bankkonto-System nutzt (z.B. eigenes Bank-Resource).
            if not paid then
                exports.oxmysql:execute('UPDATE `users` SET `bank` = `bank` + ? WHERE `identifier` = ?', { emp.wage, emp.identifier })
            end

            exports.oxmysql:insert(
                'INSERT INTO `wcc_fuel_wage_log` (`station_id`, `identifier`, `amount`, `timestamp`) VALUES (?, ?, ?, ?)',
                { stationId, emp.identifier, emp.wage, os.time() }
            )
        end
    end

    PersistStation(stationId)
end

-- Prüft alle 5 Minuten JEDE Station einzeln, ob ihr eigenes (einstellbares)
-- Lohn-Intervall abgelaufen ist, statt global alle Stationen im selben,
-- festen Takt auszuzahlen - so wirkt sich ein individuell eingestelltes
-- Intervall (1h/3h/6h/12h/24h) auch wirklich pro Station aus.
local WAGE_CHECK_INTERVAL_MS = 5 * 60 * 1000

CreateThread(function()
    Wait(15000)
    while true do
        Wait(WAGE_CHECK_INTERVAL_MS)

        local now = os.time()
        for id, s in pairs(WccFuel.Stations) do
            if s.ownerIdentifier then
                local intervalSeconds = (s.wagePayoutIntervalHours or Config.DefaultWageIntervalHours) * 3600
                if now - (s.lastWagePayout or 0) >= intervalSeconds then
                    local ok, err = pcall(PayWagesForStation, id, s)
                    if not ok then
                        print('[wcc_fuel] Fehler bei Lohn-Auszahlung Station ' .. id .. ': ' .. tostring(err))
                    end
                    s.lastWagePayout = now
                    PersistStation(id)
                end
            end
        end
    end
end)
