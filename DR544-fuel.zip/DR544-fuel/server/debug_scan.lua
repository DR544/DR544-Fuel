-- ============================================================
-- wcc_fuel - server/debug_scan.lua
-- Serverseitige Berechtigungsprüfung für /fuelscanpumps (client/debug_scan.lua).
-- Bewusst auf genau eine License beschränkt statt eines allgemeinen
-- ACE-/Admin-Gruppen-Systems - reines Entwickler-Diagnose-Tool.
-- ============================================================

-- TODO/ANPASSEN: weitere Debug-Admin-Identitäten hier ergänzen, falls nötig.
local DEBUG_ADMIN_LICENSES = {
    ['license:7983531ed736c3986d460c1a40cacdafa741443c'] = true,
}

local function IsDebugAdmin(src)
    local license = GetPlayerIdentifierByType(src, 'license')
    return license ~= nil and DEBUG_ADMIN_LICENSES[license] == true
end

lib.callback.register('wcc_fuel:debugCheckPumpScanPermission', function(src)
    return IsDebugAdmin(src)
end)
