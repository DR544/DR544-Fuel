-- ============================================================
-- wcc_fuel - server/main.lua
-- DB-Setup, geladener Live-Zustand der Tankstellen, gemeinsame
-- Hilfsfunktionen (Identifier, Notify, Persistenz).
-- ============================================================

ESX = exports['es_extended']:getSharedObject()

-- Live-Zustand je Tankstelle (Index = station_id aus Config.Stations).
-- WccFuel.Stations[id] = {
--   id, name, price, level, truckLevel, tankLiters, bank,
--   ownerIdentifier, lastDeposit, lastNonEmpty, blip = { sprite, color },
-- }
WccFuel = WccFuel or {}
WccFuel.Stations = {}

-- ------------------------------------------------------------
-- Hilfsfunktionen
-- ------------------------------------------------------------

function GetIdentifier(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer and xPlayer.identifier then
        return xPlayer.identifier
    end

    return GetPlayerIdentifierByType(src, 'license')
end

function Notify(src, description, type, title)
    TriggerClientEvent('ox_lib:notify', src, {
        title = title or 'Tankstellen',
        description = description,
        type = type or 'inform',
        position = 'bottom-right',
    })
end

-- Distanz-Check zwischen Spielerposition und einem vec3 (Anti-Cheat).
function IsPlayerNearCoords(src, coords, maxDistance)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end

    local playerCoords = GetEntityCoords(ped)
    local dist = #(playerCoords - coords)
    return dist <= maxDistance, dist
end

-- ------------------------------------------------------------
-- DB-Setup
-- ------------------------------------------------------------

local function InitDatabase()
    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS `wcc_fuel_stations` (
            `station_id` INT NOT NULL PRIMARY KEY,
            `owner_identifier` VARCHAR(64) DEFAULT NULL,
            `name` VARCHAR(64) NOT NULL,
            `price` FLOAT NOT NULL DEFAULT 1.90,
            `level` TINYINT NOT NULL DEFAULT 1,
            `truck_level` TINYINT NOT NULL DEFAULT 1,
            `comms_level` TINYINT NOT NULL DEFAULT 1,
            `tank_liters` FLOAT NOT NULL DEFAULT 0,
            `bank` INT NOT NULL DEFAULT 0,
            `last_deposit` INT NOT NULL DEFAULT 0,
            `last_nonempty` INT NOT NULL DEFAULT 0,
            `blip_sprite` INT NOT NULL DEFAULT 361,
            `blip_color` INT NOT NULL DEFAULT 5,
            `wage_interval_hours` TINYINT NOT NULL DEFAULT 12,
            `last_wage_payout` INT NOT NULL DEFAULT 0,
            `created_at` INT NOT NULL DEFAULT 0
        )
    ]])

    -- Migration für bereits bestehende Installationen (CREATE TABLE IF NOT
    -- EXISTS legt bei einer schon vorhandenen Tabelle keine neuen Spalten
    -- an) - MariaDB/MySQL 8 unterstützen ADD COLUMN IF NOT EXISTS, daher
    -- hier absichtlich ohne zusätzliches pcall-Handling um "Column exists"-
    -- Fehler bei jedem Neustart in der Konsole zu vermeiden.
    exports.oxmysql:execute([[
        ALTER TABLE `wcc_fuel_stations`
            ADD COLUMN IF NOT EXISTS `wage_interval_hours` TINYINT NOT NULL DEFAULT 12,
            ADD COLUMN IF NOT EXISTS `last_wage_payout` INT NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS `comms_level` TINYINT NOT NULL DEFAULT 1
    ]])

    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS `wcc_fuel_employees` (
            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `station_id` INT NOT NULL,
            `identifier` VARCHAR(64) NOT NULL,
            `name` VARCHAR(64) DEFAULT NULL,
            `wage` INT NOT NULL DEFAULT 0,
            `hired_at` INT NOT NULL DEFAULT 0,
            UNIQUE KEY `station_identifier` (`station_id`, `identifier`)
        )
    ]])

    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS `wcc_fuel_vehicles` (
            `plate` VARCHAR(16) NOT NULL PRIMARY KEY,
            `fuel` FLOAT NOT NULL DEFAULT 100.0,
            `updated_at` INT NOT NULL DEFAULT 0
        )
    ]])

    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS `wcc_fuel_transactions` (
            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `identifier` VARCHAR(64) NOT NULL,
            `station_id` INT DEFAULT NULL,
            `station_name` VARCHAR(64) DEFAULT NULL,
            `plate` VARCHAR(16) DEFAULT NULL,
            `liters` FLOAT NOT NULL,
            `price_per_liter` FLOAT NOT NULL,
            `total_cost` INT NOT NULL,
            `timestamp` INT NOT NULL
        )
    ]])

    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS `wcc_fuel_wage_log` (
            `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `station_id` INT NOT NULL,
            `identifier` VARCHAR(64) NOT NULL,
            `amount` INT NOT NULL,
            `timestamp` INT NOT NULL
        )
    ]])
end

-- Zufälliger Spritpreis für eine Station OHNE Besitzer, innerhalb der
-- konfigurierten Bandbreite (Config.OwnerlessFuelPriceMin/Max), auf 2
-- Nachkommastellen gerundet.
function WccFuel_RandomOwnerlessPrice()
    local min = Config.OwnerlessFuelPriceMin
    local max = Config.OwnerlessFuelPriceMax
    local value = min + math.random() * (max - min)
    return math.floor(value * 100 + 0.5) / 100
end

-- Baut aus einer DB-Zeile (oder nil = Standardwerte) den Live-Zustand
-- für eine Station gemäß Config.StationById[id] auf. Gibt als zweiten
-- Rückgabewert true zurück, wenn ein neuer Zufallspreis vergeben wurde
-- (= muss danach einmalig persistiert werden, damit er bei einem Neustart
-- stabil bleibt statt sich jedes Mal neu zu würfeln).
local function BuildStationState(cfg, row)
    local price, priceIsNew = row and row.price, false
    if not price then
        price = WccFuel_RandomOwnerlessPrice()
        priceIsNew = true
    end

    return {
        id = cfg.id,
        name = row and row.name or cfg.name,
        price = price,
        level = row and row.level or 1,
        truckLevel = row and row.truck_level or 1,
        commsLevel = row and row.comms_level or 1,
        tankLiters = row and row.tank_liters or 0.0,
        bank = row and row.bank or 0,
        ownerIdentifier = row and row.owner_identifier or nil,
        lastDeposit = row and row.last_deposit or 0,
        lastNonEmpty = row and row.last_nonempty or os.time(),
        blip = {
            sprite = row and row.blip_sprite or Config.DefaultBlip.sprite,
            color = row and row.blip_color or Config.DefaultBlip.color,
        },
        wagePayoutIntervalHours = (row and row.wage_interval_hours) or Config.DefaultWageIntervalHours,
        lastWagePayout = (row and row.last_wage_payout) or 0,
    }, priceIsNew
end

-- Persistiert den kompletten Live-Zustand einer Station in die DB.
function PersistStation(id)
    local s = WccFuel.Stations[id]
    if not s then return end

    exports.oxmysql:execute([[
        INSERT INTO `wcc_fuel_stations`
            (`station_id`, `owner_identifier`, `name`, `price`, `level`, `truck_level`, `comms_level`,
             `tank_liters`, `bank`, `last_deposit`, `last_nonempty`, `blip_sprite`, `blip_color`,
             `wage_interval_hours`, `last_wage_payout`, `created_at`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            `owner_identifier` = VALUES(`owner_identifier`),
            `name` = VALUES(`name`),
            `price` = VALUES(`price`),
            `level` = VALUES(`level`),
            `truck_level` = VALUES(`truck_level`),
            `comms_level` = VALUES(`comms_level`),
            `tank_liters` = VALUES(`tank_liters`),
            `bank` = VALUES(`bank`),
            `last_deposit` = VALUES(`last_deposit`),
            `last_nonempty` = VALUES(`last_nonempty`),
            `blip_sprite` = VALUES(`blip_sprite`),
            `blip_color` = VALUES(`blip_color`),
            `wage_interval_hours` = VALUES(`wage_interval_hours`),
            `last_wage_payout` = VALUES(`last_wage_payout`)
    ]], {
        s.id, s.ownerIdentifier, s.name, s.price, s.level, s.truckLevel, s.commsLevel,
        s.tankLiters, s.bank, s.lastDeposit, s.lastNonEmpty, s.blip.sprite, s.blip.color,
        s.wagePayoutIntervalHours, s.lastWagePayout, os.time(),
    })
end

-- Broadcastet den öffentlich relevanten Zustand aller Stationen an alle
-- Clients (Blips, Namen, Preise) - keine sensiblen Bank-/Level-Up-Daten.
function BroadcastStations()
    local publicData = {}
    for id, s in pairs(WccFuel.Stations) do
        publicData[id] = {
            id = s.id,
            name = s.name,
            price = s.price,
            hasOwner = s.ownerIdentifier ~= nil,
            tankLiters = s.tankLiters,
            blip = s.blip,
        }
    end
    TriggerClientEvent('wcc_fuel:syncStations', -1, publicData)
end

RegisterNetEvent('wcc_fuel:requestSync', function()
    local publicData = {}
    for id, s in pairs(WccFuel.Stations) do
        publicData[id] = {
            id = s.id,
            name = s.name,
            price = s.price,
            hasOwner = s.ownerIdentifier ~= nil,
            tankLiters = s.tankLiters,
            blip = s.blip,
        }
    end
    TriggerClientEvent('wcc_fuel:syncStations', source, publicData)
end)

CreateThread(function()
    InitDatabase()

    -- kurze Wartezeit, damit CREATE TABLE sicher durch ist, bevor gelesen wird
    Wait(500)

    exports.oxmysql:query('SELECT * FROM `wcc_fuel_stations`', {}, function(rows)
        local byId = {}
        if rows then
            for _, row in ipairs(rows) do
                byId[row.station_id] = row
            end
        end

        for _, cfg in ipairs(Config.Stations) do
            local state, priceIsNew = BuildStationState(cfg, byId[cfg.id])
            WccFuel.Stations[cfg.id] = state

            -- Neu gewürfelten Preis sofort persistieren, damit er bei einem
            -- Neustart stabil bleibt statt sich jedes Mal neu zu würfeln.
            if priceIsNew then
                PersistStation(cfg.id)
            end
        end

        if Config.Debug then
            print(('[wcc_fuel] %d Tankstellen geladen.'):format(#Config.Stations))
        end

        BroadcastStations()
    end)
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    for id in pairs(WccFuel.Stations) do
        PersistStation(id)
    end
end)
