-- ============================================================
-- wcc_fuel - server/stations.lua
-- Kauf, Besitzer-Einstellungen (Name/Preis/Blip), Level-System,
-- Tankstellen-Bank (Ein-/Auszahlung), Inaktivitäts-Refund.
-- ============================================================

-- Anzahl der Stationen, die ein Identifier bereits besitzt.
local function CountOwnedStations(identifier)
    local count = 0
    for _, s in pairs(WccFuel.Stations) do
        if s.ownerIdentifier == identifier then
            count = count + 1
        end
    end
    return count
end

-- Prüft, ob src der Besitzer der Station ist (serverseitig, niemals dem
-- Client vertrauen).
local function IsOwner(src, stationId)
    local s = WccFuel.Stations[stationId]
    if not s or not s.ownerIdentifier then return false end
    return s.ownerIdentifier == GetIdentifier(src)
end

-- ------------------------------------------------------------
-- Kauf
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:buyStation', function(src, stationId)
    local cfg = Config.StationById[stationId]
    local s = WccFuel.Stations[stationId]
    if not cfg or not s then return { ok = false, reason = 'Ungültige Tankstelle.' } end

    if s.ownerIdentifier then
        return { ok = false, reason = 'Diese Tankstelle gehört bereits jemandem.' }
    end

    local mc = cfg.buyMarkerCoords
    local near = IsPlayerNearCoords(src, vector3(mc.x, mc.y, mc.z), Config.MarkerInteractionDistance + 2.0)
    if not near then
        return { ok = false, reason = 'Du bist nicht am Kauf-Marker dieser Tankstelle.' }
    end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return { ok = false, reason = 'Spielerdaten nicht gefunden.' } end

    local identifier = GetIdentifier(src)
    if CountOwnedStations(identifier) >= Config.MaxStationsPerPlayer then
        return { ok = false, reason = ('Du besitzt bereits das Maximum von %d Tankstellen.'):format(Config.MaxStationsPerPlayer) }
    end

    local account = xPlayer.getAccount(Config.PaymentAccount)
    if not account or account.money < cfg.buyPrice then
        return { ok = false, reason = 'Nicht genug Geld, um diese Tankstelle zu kaufen.' }
    end

    xPlayer.removeAccountMoney(Config.PaymentAccount, cfg.buyPrice, 'Kauf Tankstelle: ' .. cfg.name)

    s.ownerIdentifier = identifier
    s.name = cfg.name
    s.price = Config.MinOwnerFuelPrice
    s.level = 1
    s.truckLevel = 1
    s.commsLevel = 1
    s.tankLiters = 0
    s.bank = 0
    s.lastDeposit = 0
    s.lastNonEmpty = os.time()
    s.blip = { sprite = Config.DefaultBlip.sprite, color = Config.DefaultBlip.color }
    s.wagePayoutIntervalHours = Config.DefaultWageIntervalHours
    s.lastWagePayout = os.time()

    PersistStation(stationId)
    BroadcastStations()

    Notify(src, ('Du hast "%s" für %d$ gekauft!'):format(cfg.name, cfg.buyPrice), 'success')

    return { ok = true }
end)

-- ------------------------------------------------------------
-- Besitzer-Einstellungen (Name / Preis / Blip)
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:updateStationSettings', function(src, stationId, name, price, blipSprite, blipColor)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    local s = WccFuel.Stations[stationId]

    if type(name) == 'string' and #name >= 3 and #name <= 40 then
        s.name = name
    end

    price = tonumber(price)
    if price then
        price = math.max(Config.MinOwnerFuelPrice, math.min(Config.MaxOwnerFuelPrice, price))
        s.price = math.floor(price * 100 + 0.5) / 100
    end

    blipSprite = tonumber(blipSprite)
    blipColor = tonumber(blipColor)
    if blipSprite then s.blip.sprite = math.floor(blipSprite) end
    if blipColor then s.blip.color = math.floor(blipColor) end

    PersistStation(stationId)
    BroadcastStations()

    return { ok = true, station = s }
end)

-- ------------------------------------------------------------
-- Level-System (Stations-Level & LKW-Level)
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:levelUpStation', function(src, stationId)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    local s = WccFuel.Stations[stationId]

    if s.level >= Config.MaxStationLevel then
        return { ok = false, reason = 'Maximales Level bereits erreicht.' }
    end

    local cost = Config.StationLevelUpCost[s.level]
    if not cost then return { ok = false, reason = 'Kein Upgrade-Preis definiert.' } end

    if s.bank < cost then
        return { ok = false, reason = ('Nicht genug Guthaben in der Tankstellen-Bank (%d$ benötigt).'):format(cost) }
    end

    s.bank = s.bank - cost
    s.level = s.level + 1

    PersistStation(stationId)
    BroadcastStations()

    return { ok = true, station = s }
end)

lib.callback.register('wcc_fuel:levelUpTruck', function(src, stationId)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    local s = WccFuel.Stations[stationId]

    if s.truckLevel >= Config.MaxStationLevel then
        return { ok = false, reason = 'Maximales LKW-Level bereits erreicht.' }
    end

    local cost = Config.TruckLevelUpCost[s.truckLevel]
    if not cost then return { ok = false, reason = 'Kein Upgrade-Preis definiert.' } end

    if s.bank < cost then
        return { ok = false, reason = ('Nicht genug Guthaben in der Tankstellen-Bank (%d$ benötigt).'):format(cost) }
    end

    s.bank = s.bank - cost
    s.truckLevel = s.truckLevel + 1

    PersistStation(stationId)
    BroadcastStations()

    return { ok = true, station = s }
end)

-- Kommunikations-Level: bringt die zufälligen Job-Abholpunkte näher an die
-- Station heran (siehe GetJobPickupGroupForLevel in server/job.lua) -
-- unabhängig vom Stations-/Tank-Level.
lib.callback.register('wcc_fuel:levelUpComms', function(src, stationId)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    local s = WccFuel.Stations[stationId]

    if s.commsLevel >= Config.MaxStationLevel then
        return { ok = false, reason = 'Maximales Kommunikations-Level bereits erreicht.' }
    end

    local cost = Config.CommsLevelUpCost[s.commsLevel]
    if not cost then return { ok = false, reason = 'Kein Upgrade-Preis definiert.' } end

    if s.bank < cost then
        return { ok = false, reason = ('Nicht genug Guthaben in der Tankstellen-Bank (%d$ benötigt).'):format(cost) }
    end

    s.bank = s.bank - cost
    s.commsLevel = s.commsLevel + 1

    PersistStation(stationId)
    BroadcastStations()

    return { ok = true, station = s }
end)

-- ------------------------------------------------------------
-- Tankstellen-Bank: Einzahlen (max. 30.000$, alle 12h) / Auszahlen
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:depositBank', function(src, stationId, amount)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    local s = WccFuel.Stations[stationId]
    amount = math.floor(tonumber(amount) or 0)

    if amount <= 0 or amount > Config.MaxDepositPerTransaction then
        return { ok = false, reason = ('Einzahlung muss zwischen 1$ und %d$ liegen.'):format(Config.MaxDepositPerTransaction) }
    end

    local now = os.time()
    local remainingCooldown = Config.DepositCooldownSeconds - (now - s.lastDeposit)
    if s.lastDeposit > 0 and remainingCooldown > 0 then
        return { ok = false, reason = ('Nächste Einzahlung erst in %d Minuten möglich.'):format(math.ceil(remainingCooldown / 60)) }
    end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return { ok = false, reason = 'Spielerdaten nicht gefunden.' } end

    local account = xPlayer.getAccount(Config.PaymentAccount)
    if not account or account.money < amount then
        return { ok = false, reason = 'Nicht genug Geld für diese Einzahlung.' }
    end

    xPlayer.removeAccountMoney(Config.PaymentAccount, amount, 'Einzahlung Tankstellen-Bank: ' .. s.name)

    s.bank = s.bank + amount
    s.lastDeposit = now

    PersistStation(stationId)

    return { ok = true, station = s }
end)

lib.callback.register('wcc_fuel:withdrawBank', function(src, stationId, amount)
    if not IsOwner(src, stationId) then
        return { ok = false, reason = 'Du bist nicht der Besitzer dieser Tankstelle.' }
    end

    local s = WccFuel.Stations[stationId]
    amount = math.floor(tonumber(amount) or 0)

    if amount <= 0 or amount > s.bank then
        return { ok = false, reason = 'Ungültiger Betrag oder nicht genug Guthaben in der Bank.' }
    end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return { ok = false, reason = 'Spielerdaten nicht gefunden.' } end

    s.bank = s.bank - amount
    xPlayer.addAccountMoney(Config.PaymentAccount, amount, 'Auszahlung Tankstellen-Bank: ' .. s.name)

    PersistStation(stationId)

    return { ok = true, station = s }
end)

-- ------------------------------------------------------------
-- Inaktivitäts-Refund: Ist der Tank Config.EmptyRefundDays Tage AM STÜCK
-- leer (0 Liter), verliert der Besitzer die Station automatisch.
-- Es zählt ausschließlich der Tankstand, NICHT die Online-Zeit des
-- Besitzers (siehe README).
-- ------------------------------------------------------------

local function RepossessStation(stationId)
    local s = WccFuel.Stations[stationId]
    local cfg = Config.StationById[stationId]
    if not s or not s.ownerIdentifier then return end

    local previousOwner = s.ownerIdentifier
    local refundAmount = 0

    if Config.RefundBankOnRepossession and s.bank > 0 then
        refundAmount = s.bank

        -- Ist der ehemalige Besitzer online, direkt aufs Bankkonto auszahlen.
        -- Ist er offline, verfällt der Restwert (kein Offline-Banking in
        -- ESX Legacy standardmäßig verfügbar) - siehe README.
        local targetSrc = nil
        for _, playerId in ipairs(GetPlayers()) do
            if GetIdentifier(tonumber(playerId)) == previousOwner then
                targetSrc = tonumber(playerId)
                break
            end
        end

        if targetSrc then
            local xTarget = ESX.GetPlayerFromId(targetSrc)
            if xTarget then
                xTarget.addAccountMoney(Config.PaymentAccount, refundAmount, 'Restwert eingezogene Tankstelle: ' .. s.name)
                Notify(targetSrc, ('Deine Tankstelle "%s" wurde wegen 3 Tagen leerem Tank eingezogen. Du erhältst %d$ Restwert.'):format(s.name, refundAmount), 'error')
            end
        end
    end

    -- Station komplett auf Standard zurücksetzen - neuer Zufallspreis
    -- (ownerlose Station), nicht der alte Besitzerpreis.
    s.ownerIdentifier = nil
    s.name = cfg.name
    s.price = WccFuel_RandomOwnerlessPrice()
    s.level = 1
    s.truckLevel = 1
    s.commsLevel = 1
    s.tankLiters = 0
    s.bank = 0
    s.lastDeposit = 0
    s.lastNonEmpty = os.time()
    s.blip = { sprite = Config.DefaultBlip.sprite, color = Config.DefaultBlip.color }
    s.wagePayoutIntervalHours = Config.DefaultWageIntervalHours
    s.lastWagePayout = os.time()

    exports.oxmysql:execute('DELETE FROM `wcc_fuel_employees` WHERE `station_id` = ?', { stationId })

    PersistStation(stationId)
    BroadcastStations()

    print(('[wcc_fuel] Tankstelle "%s" wurde wegen Inaktivität (leerer Tank) eingezogen. Vorheriger Besitzer: %s'):format(cfg.name, previousOwner))
end

local function CheckInactiveStations()
    local now = os.time()
    local thresholdSeconds = Config.EmptyRefundDays * 24 * 3600

    for id, s in pairs(WccFuel.Stations) do
        if s.ownerIdentifier then
            if s.tankLiters > 0 then
                -- Tank nicht leer -> Timer zurücksetzen
                s.lastNonEmpty = now
            elseif (now - s.lastNonEmpty) >= thresholdSeconds then
                RepossessStation(id)
            end
        end
    end
end

CreateThread(function()
    Wait(10000) -- kurz nach dem Laden der Stationen starten
    while true do
        Wait(Config.InactivityCheckInterval)
        local ok, err = pcall(CheckInactiveStations)
        if not ok then
            print('[wcc_fuel] Fehler bei Inaktivitäts-Check: ' .. tostring(err))
        end
    end
end)

-- ------------------------------------------------------------
-- Liefert den Live-Zustand EINER Station inkl. sensibler Boss-Daten
-- (nur für den Besitzer selbst gedacht, wird per Callback abgefragt)
-- ------------------------------------------------------------

-- Prüft, ob identifier Mitarbeiter (NICHT Besitzer) von stationId ist.
local function IsEmployeeOf(identifier, stationId)
    local row = exports.oxmysql:scalarSync(
        'SELECT 1 FROM `wcc_fuel_employees` WHERE `station_id` = ? AND `identifier` = ? LIMIT 1',
        { stationId, identifier }
    )
    return row ~= nil
end

-- Liefert ALLE Stationen, an denen src beteiligt ist - als Besitzer (volle
-- Daten inkl. Bank/Upgrades/Lohn-Intervall) ODER als Mitarbeiter (bewusst
-- stark eingeschränkte Daten: nur Name/Level/Tankstand - explizit KEINE
-- Bank, KEINE Upgrade-Kosten, KEINE Lohn-Daten). "role" steuert im
-- Boss-Menü/der App, welche Tabs/Aktionen überhaupt angezeigt werden -
-- serverseitig ist jede sensible Aktion (Bank, Upgrades, Mitarbeiter
-- verwalten) ohnehin zusätzlich per IsOwner() abgesichert.
lib.callback.register('wcc_fuel:getMyStations', function(src)
    local identifier = GetIdentifier(src)
    local result = {}

    for id, s in pairs(WccFuel.Stations) do
        if s.ownerIdentifier == identifier then
            result[#result + 1] = {
                id = s.id,
                role = 'owner',
                name = s.name,
                price = s.price,
                level = s.level,
                truckLevel = s.truckLevel,
                commsLevel = s.commsLevel,
                tankLiters = s.tankLiters,
                tankCapacity = Config.StationTankCapacityByLevel[s.level],
                truckCapacity = Config.TruckCapacityByLevel[s.truckLevel],
                bank = s.bank,
                lastDeposit = s.lastDeposit,
                blip = s.blip,
                nextLevelCost = Config.StationLevelUpCost[s.level],
                nextTruckLevelCost = Config.TruckLevelUpCost[s.truckLevel],
                nextCommsLevelCost = Config.CommsLevelUpCost[s.commsLevel],
                wagePayoutIntervalHours = s.wagePayoutIntervalHours,
            }
        elseif IsEmployeeOf(identifier, id) then
            result[#result + 1] = {
                id = s.id,
                role = 'employee',
                name = s.name,
                price = s.price,
                level = s.level,
                tankLiters = s.tankLiters,
                tankCapacity = Config.StationTankCapacityByLevel[s.level],
                truckCapacity = Config.TruckCapacityByLevel[s.truckLevel],
            }
        end
    end

    table.sort(result, function(a, b) return a.id < b.id end)

    return result
end)
