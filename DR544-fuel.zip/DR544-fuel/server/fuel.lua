-- ============================================================
-- wcc_fuel - server/fuel.lua
-- Fahrzeug-Tankstand laden/speichern (normaler Fahrbetrieb, unverändert) +
-- Live-Tank-Session (Prop/Rope-Tanken) mit periodischem Billing-Thread,
-- sinngemäß 1:1 vom Lade-Modell aus wcc_chargingstations/server/main.lua
-- übernommen (requestStart/ProcessSessionBilling/requestStop/playerDropped),
-- für Sprit/Liter neu geschrieben.
-- ============================================================

-- ------------------------------------------------------------
-- Fahrzeug-Tankstand laden/speichern (normales Fahren, UNVERÄNDERT)
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:loadVehicleFuel', function(src, plate)
    if not plate or plate == '' then return Config.DefaultFuelLevel end

    plate = plate:gsub('%s+', ''):upper()

    local result = exports.oxmysql:scalarSync('SELECT `fuel` FROM `wcc_fuel_vehicles` WHERE `plate` = ?', { plate })
    if result then
        return tonumber(result) or Config.DefaultFuelLevel
    end

    return Config.DefaultFuelLevel
end)

-- saveVehicleFuel wird ausschließlich vom periodischen Verbrauchs-Save des
-- normalen Fahrbetriebs genutzt (client/main.lua) - WÄHREND einer laufenden
-- Tank-Session (client/refuel.lua) wird dieses Event bewusst NICHT mehr
-- ausgelöst, der Billing-Thread unten schreibt den Tankstand während des
-- Tankens direkt und autoritativ selbst in die DB (siehe ProcessRefuelBilling).
--
-- Da eine Erhöhung des gespeicherten Tankstands durch den Client jetzt
-- NIE mehr legitim ist (Tanken läuft server-autoritativ, normales Fahren
-- kann den Tank nur leeren), wird jede Erhöhung ohne Ausnahme verworfen -
-- der frühere pendingRefuelCredit-Mechanismus für den eigentlichen
-- Tankvorgang entfällt damit ersatzlos.
RegisterNetEvent('wcc_fuel:saveVehicleFuel', function(netId, plate, fuel)
    local src = source
    if not plate or plate == '' then return end

    plate = plate:gsub('%s+', ''):upper()
    fuel = math.max(0.0, math.min(100.0, tonumber(fuel) or 0.0))

    local veh = NetworkGetEntityFromNetworkId(tonumber(netId) or 0)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end

    local actualPlate = GetVehicleNumberPlateText(veh):gsub('%s+', ''):upper()
    if actualPlate ~= plate then return end

    local driverPed = GetPedInVehicleSeat(veh, -1)
    if driverPed == 0 or driverPed ~= GetPlayerPed(src) then return end

    -- WICHTIG: erst in eine Variable schreiben, dann erst tonumber() drauf -
    -- oxmysql:scalarSync liefert bei keinem Treffer manchmal GAR KEINEN
    -- Rückgabewert (0 Werte statt eines expliziten nil), wodurch
    -- tonumber(exports...:scalarSync(...)) mit 0 Argumenten aufgerufen wird
    -- und crasht ("bad argument #1 to 'tonumber' (value expected)").
    -- tonumber(currentRaw) bekommt garantiert genau 1 Argument (ggf. nil).
    local currentRaw = exports.oxmysql:scalarSync('SELECT `fuel` FROM `wcc_fuel_vehicles` WHERE `plate` = ?', { plate })
    local current = tonumber(currentRaw)

    if current and fuel > current + 0.5 then
        -- Erhöhung ohne laufende Server-Session -> Cheat-Versuch, ignorieren.
        return
    end

    exports.oxmysql:execute([[
        INSERT INTO `wcc_fuel_vehicles` (`plate`, `fuel`, `updated_at`)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE `fuel` = VALUES(`fuel`), `updated_at` = VALUES(`updated_at`)
    ]], { plate, fuel, os.time() })
end)

-- ------------------------------------------------------------
-- Externe Fuel-Updates (z.B. wcc_chargingstations während des E-Auto-
-- Ladens) - EIGENER Event-Name/Pfad, bewusst GETRENNT vom normalen
-- Verbrauchs-Save oben (wcc_fuel:saveVehicleFuel).
--
-- Hintergrund/Bug, den das hier behebt ("LegacyFuel-Bug"): Beim Laden steht
-- der Spieler meist NEBEN dem Fahrzeug (lädt), nicht als Fahrer DRIN - der
-- Fahrer-Pflicht-Check oben würde jedes SetFuel während des Ladens also
-- verwerfen, wodurch der Akkustand nach Ab-/Anmelden bzw. Fahrzeug-Neuladen
-- wieder auf dem alten (niedrigen) Wert steht, obwohl gerade geladen wurde.
--
-- Dieser Pfad prüft weiterhin Fahrzeug-Existenz + Kennzeichen-Übereinstimmung,
-- aber OHNE Fahrer-Sitzplatz-Pflicht. Für Erhöhungen (Laden = steigender
-- Wert) braucht es trotzdem einen Cheat-Schutz: externalCredits[plate], das
-- normalerweise durch den eigenen Tankvorgang (an den src gebunden) gesetzt
-- wird, ODER durch einen "trusted"-Credit von exports('GrantFuelCredit', ...)
-- (siehe server/exports.lua) - dieser ist NICHT an eine src gebunden, weil er
-- nur server-zu-server (z.B. von wcc_chargingstations) aufrufbar ist, nie
-- direkt von einem Client.
-- ------------------------------------------------------------

-- plate -> { maxFuel, expires (os.time), trusted, src }
WccFuel_ExternalCredits = WccFuel_ExternalCredits or {}

-- Wird von exports.lua (GrantFuelCredit) sowie potenziell zukünftig von
-- eigenen, an einen Spieler gebundenen Tankvorgängen genutzt.
function WccFuel_SetExternalCredit(plate, maxFuel, ttlSeconds, trusted, srcForCredit)
    if not plate or plate == '' then return end
    plate = plate:gsub('%s+', ''):upper()

    WccFuel_ExternalCredits[plate] = {
        maxFuel = math.max(0.0, math.min(100.0, tonumber(maxFuel) or 100.0)),
        expires = os.time() + (tonumber(ttlSeconds) or 8),
        trusted = trusted and true or false,
        src = srcForCredit,
    }
end

RegisterNetEvent('wcc_fuel:externalFuelUpdate', function(netId, plate, fuel)
    local src = source
    if not plate or plate == '' then return end

    plate = plate:gsub('%s+', ''):upper()
    fuel = math.max(0.0, math.min(100.0, tonumber(fuel) or 0.0))

    local veh = NetworkGetEntityFromNetworkId(tonumber(netId) or 0)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end

    -- Fahrzeug muss zum angegebenen Kennzeichen passen, ABER KEINE
    -- Fahrer-Sitzplatz-Pflicht (Spieler steht beim Laden meist daneben).
    local actualPlate = GetVehicleNumberPlateText(veh):gsub('%s+', ''):upper()
    if actualPlate ~= plate then return end

    -- WICHTIG: erst in eine Variable schreiben, dann erst tonumber() drauf -
    -- oxmysql:scalarSync liefert bei keinem Treffer manchmal GAR KEINEN
    -- Rückgabewert (0 Werte statt eines expliziten nil), wodurch
    -- tonumber(exports...:scalarSync(...)) mit 0 Argumenten aufgerufen wird
    -- und crasht ("bad argument #1 to 'tonumber' (value expected)").
    -- tonumber(currentRaw) bekommt garantiert genau 1 Argument (ggf. nil).
    local currentRaw = exports.oxmysql:scalarSync('SELECT `fuel` FROM `wcc_fuel_vehicles` WHERE `plate` = ?', { plate })
    local current = tonumber(currentRaw)

    if current and fuel > current + 0.5 then
        -- Erhöhung: nur mit gültigem Credit erlauben.
        local credit = WccFuel_ExternalCredits[plate]

        if not credit or credit.expires < os.time() then
            return
        end

        if fuel > credit.maxFuel + 0.5 then
            return
        end

        -- Normale (nicht-"trusted") Credits sind an eine bestimmte src
        -- gebunden (z.B. der eigene Tankvorgang) - "trusted"-Credits
        -- (aus GrantFuelCredit, server-zu-server) überspringen diesen
        -- Abgleich bewusst, weil sie nicht an einen bestimmten Spieler
        -- gebunden sind (der Ladevorgang wird ja serverseitig von
        -- wcc_chargingstations verwaltet, nicht von diesem src).
        if not credit.trusted and credit.src ~= src then
            return
        end
    end

    exports.oxmysql:execute([[
        INSERT INTO `wcc_fuel_vehicles` (`plate`, `fuel`, `updated_at`)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE `fuel` = VALUES(`fuel`), `updated_at` = VALUES(`updated_at`)
    ]], { plate, fuel, os.time() })
end)

-- ------------------------------------------------------------
-- Log-Hilfsfunktion (wiederverwendet für Session-Abschluss)
-- ------------------------------------------------------------

local function LogTransaction(identifier, stationId, stationName, plate, liters, pricePerLiter, totalCost)
    if liters <= 0 then return end

    exports.oxmysql:insert([[
        INSERT INTO `wcc_fuel_transactions`
            (`identifier`, `station_id`, `station_name`, `plate`, `liters`, `price_per_liter`, `total_cost`, `timestamp`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ]], { identifier, stationId, stationName, plate, liters, pricePerLiter, totalCost, os.time() })
end

-- ------------------------------------------------------------
-- Live-Tank-Sessions
-- ------------------------------------------------------------
-- sessions[src] = {
--   src, identifier, netId, plate, stationId, stationName, pricePerLiter,
--   lastBillTime, totalLiters, totalCost, unbilledCost, budgetDollars,
--   startFuelPercent, capacityLiters, hasStationOwner,
-- }
local sessions = {}

local function SavePlateFuel(plate, fuel)
    if not plate or plate == '' then return end
    exports.oxmysql:execute([[
        INSERT INTO `wcc_fuel_vehicles` (`plate`, `fuel`, `updated_at`)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE `fuel` = VALUES(`fuel`), `updated_at` = VALUES(`updated_at`)
    ]], { plate, fuel, os.time() })
end

-- ------------------------------------------------------------
-- Tank-Session starten
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:requestStartRefuel', function(src, stationId, netId, plate)
    local cfg = Config.StationById[stationId]
    local s = WccFuel.Stations[stationId]
    if not cfg or not s then return { ok = false, reason = 'Ungültige Tankstelle.' } end

    if sessions[src] then
        return { ok = false, reason = 'Es läuft bereits ein Tankvorgang.' }
    end

    -- cfg.coords ist nur die grobe Näherungskoordinate der Station (Pumpen
    -- werden per Radius zugeordnet, siehe Config.PumpStationLinkRadius) -
    -- die tatsächliche, vom Spieler angeklickte Zapfsäule kennt der Server
    -- hier nicht (nur stationId/netId/plate werden übergeben). Deshalb
    -- Config.PumpStationLinkRadius statt der viel kleineren
    -- Config.MaxDistanceFromPump als Toleranz verwenden, sonst lehnt der
    -- Server Sessions an echten, weiter entfernten Zapfsäulen fälschlich ab,
    -- obwohl der Client (der die echte Pumpen-Position kennt) sie erlaubt hat.
    local near = IsPlayerNearCoords(src, cfg.coords, Config.PumpStationLinkRadius + 5.0)
    if not near then
        return { ok = false, reason = 'Du bist nicht an der Zapfsäule.' }
    end

    local veh = NetworkGetEntityFromNetworkId(tonumber(netId) or 0)
    if not veh or veh == 0 or not DoesEntityExist(veh) then
        return { ok = false, reason = 'Fahrzeug nicht gefunden.' }
    end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return { ok = false, reason = 'Spielerdaten nicht gefunden.' } end

    local identifier = GetIdentifier(src)
    if not identifier then return { ok = false, reason = 'Identifier konnte nicht ermittelt werden.' } end

    local account = xPlayer.getAccount(Config.PaymentAccount)
    if not account or account.money < 1 then
        return { ok = false, reason = 'Nicht genug Geld auf dem Konto, um zu tanken.' }
    end

    -- Bei Stationen MIT Besitzer: Session darf nicht starten, wenn der
    -- Stationstank bereits leer ist.
    if s.ownerIdentifier and s.tankLiters <= 0 then
        return { ok = false, reason = 'Diese Tankstelle hat gerade keinen Sprit mehr auf Lager.' }
    end

    plate = plate and plate:gsub('%s+', ''):upper() or (GetVehicleNumberPlateText(veh):gsub('%s+', ''):upper())

    -- Siehe Kommentar weiter oben: erst Variable, dann tonumber(), sonst
    -- crasht scalarSync() ohne Treffer den tonumber()-Aufruf mit 0 Argumenten.
    local startFuelRaw = exports.oxmysql:scalarSync('SELECT `fuel` FROM `wcc_fuel_vehicles` WHERE `plate` = ?', { plate })
    local startFuelPercent = tonumber(startFuelRaw) or Config.DefaultFuelLevel

    if startFuelPercent >= 100.0 then
        return { ok = false, reason = 'Der Tank ist bereits voll.' }
    end

    -- s.price ist für Stationen ohne Besitzer bereits der beim Laden/Erstellen
    -- gewürfelte, stabile Preis (Config.OwnerlessFuelPriceMin/Max), für
    -- Stationen mit Besitzer der von diesem festgelegte Preis - in beiden
    -- Fällen also einfach der aktuelle Stationspreis.
    local pricePerLiter = s.price

    sessions[src] = {
        src = src,
        identifier = identifier,
        netId = netId,
        plate = plate,
        stationId = stationId,
        stationName = s.name,
        pricePerLiter = pricePerLiter,
        lastBillTime = os.time(),
        totalLiters = 0.0,
        totalCost = 0,
        unbilledCost = 0.0,
        budgetDollars = math.floor(account.money),
        startFuelPercent = startFuelPercent,
        capacityLiters = Config.LitersPerFullTank,
        hasStationOwner = s.ownerIdentifier ~= nil,
    }

    return { ok = true, pricePerLiter = pricePerLiter }
end)

-- ------------------------------------------------------------
-- Periodische Abrechnung (verbindlich, unabhängig vom Client)
-- ------------------------------------------------------------

local function EndSession(src, session, forcedMessage)
    LogTransaction(session.identifier, session.stationId, session.stationName, session.plate, session.totalLiters, session.pricePerLiter, session.totalCost)
    sessions[src] = nil

    if forcedMessage then
        -- totalLiters/totalCost werden zusätzlich mitgeschickt (früher nur
        -- forcedMessage), damit z.B. wcc_fuelmanager auch bei abgebrochenem
        -- statt komplett vollem Tankvorgang die Rechnung als Handy-Push
        -- anzeigen kann. client/refuel.lua ignoriert die zusätzlichen
        -- Parameter einfach, falls dort nicht gebraucht.
        TriggerClientEvent('wcc_fuel:forceStopped', src, forcedMessage, session.totalLiters, session.totalCost)
    else
        TriggerClientEvent('wcc_fuel:refuelComplete', src, session.totalLiters, session.totalCost)
    end
end

local function ProcessSessionBilling(src, session)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then
        sessions[src] = nil
        return
    end

    local s = WccFuel.Stations[session.stationId]
    if not s then
        EndSession(src, session, 'Tankstelle nicht mehr verfügbar.')
        return
    end

    -- Bei Stationen mit Besitzer: während des Tankens leert sich zusätzlich
    -- der Stationstank - läuft er während der Session leer, wird sofort
    -- gestoppt (kein "Sprit aus dem Nichts").
    if session.hasStationOwner and s.tankLiters <= 0 then
        EndSession(src, session, 'Die Tankstelle hat während des Tankens keinen Sprit mehr - Vorgang beendet.')
        return
    end

    if session.totalCost >= session.budgetDollars then
        EndSession(src, session, 'Kontostand aufgebraucht. Tankvorgang beendet.')
        return
    end

    local now = os.time()
    local elapsed = now - session.lastBillTime
    if elapsed <= 0 then return end

    session.lastBillTime = now

    local fuelGainPercent = math.min(100.0 - session.startFuelPercent, (elapsed / Config.MaxFullTankSeconds) * 100.0)
    local litersWanted = (elapsed / Config.MaxFullTankSeconds) * session.capacityLiters

    -- Bei Stationen mit Besitzer: nicht mehr Liter abzapfen, als der
    -- Stationstank noch hergibt.
    if session.hasStationOwner then
        litersWanted = math.min(litersWanted, s.tankLiters)
    end

    if litersWanted <= 0 then return end

    local cost = litersWanted * session.pricePerLiter
    session.unbilledCost = session.unbilledCost + cost

    local wholeDollars = math.floor(session.unbilledCost)
    local remainingBudget = session.budgetDollars - session.totalCost
    local billableDollars = math.min(wholeDollars, remainingBudget)

    -- Liter proportional zum tatsächlich abgerechneten Betrag begrenzen,
    -- damit niemals mehr getankt wird, als bezahlt werden konnte.
    local billableLiters = litersWanted
    if wholeDollars > 0 and billableDollars < wholeDollars then
        billableLiters = litersWanted * (billableDollars / wholeDollars)
    end

    if billableDollars > 0 then
        xPlayer.removeAccountMoney(Config.PaymentAccount, billableDollars, 'Tanken: ' .. session.stationName)
        session.unbilledCost = session.unbilledCost - billableDollars
        session.totalCost = session.totalCost + billableDollars
    end

    session.totalLiters = session.totalLiters + billableLiters

    if session.hasStationOwner then
        s.tankLiters = math.max(0, s.tankLiters - billableLiters)
        s.lastNonEmpty = os.time()

        local ownerShare = math.floor(billableDollars * (1 - Config.TaxRate))
        local taxShare = billableDollars - ownerShare
        s.bank = s.bank + ownerShare

        if taxShare > 0 then
            TriggerEvent('esx_addonaccount:getSharedAccount', Config.GovernmentAccount, function(account)
                if account then account.addMoney(taxShare) end
            end)
        end

        PersistStation(session.stationId)
        BroadcastStations()
    end

    local newFuelPercent = math.min(100.0, session.startFuelPercent + (session.totalLiters / session.capacityLiters) * 100.0)
    SavePlateFuel(session.plate, newFuelPercent)

    TriggerClientEvent('wcc_fuel:refuelTickUpdate', src, newFuelPercent, session.totalLiters, session.totalCost)

    if session.totalCost >= session.budgetDollars then
        EndSession(src, session, 'Kontostand aufgebraucht. Tankvorgang beendet.')
        return
    end

    if newFuelPercent >= 100.0 then
        -- Letzten angefangenen Dollar noch fällig stellen, gedeckelt durch
        -- das verbleibende Budget.
        local finalDollars = math.ceil(session.unbilledCost)
        local finalRemainingBudget = session.budgetDollars - session.totalCost
        local finalBillable = math.min(finalDollars, finalRemainingBudget)
        if finalBillable > 0 then
            xPlayer.removeAccountMoney(Config.PaymentAccount, finalBillable, 'Tanken: ' .. session.stationName)
            session.totalCost = session.totalCost + finalBillable
        end

        EndSession(src, session, nil)
    end
end

CreateThread(function()
    while true do
        Wait(Config.RefuelBillingInterval * 1000)

        for src, session in pairs(sessions) do
            local ok, err = pcall(ProcessSessionBilling, src, session)
            if not ok then
                print(('[wcc_fuel][billing] FEHLER bei src=%s: %s'):format(src, tostring(err)))
            end
        end
    end
end)

-- ------------------------------------------------------------
-- Tank-Session manuell/erzwungen beenden
-- ------------------------------------------------------------

RegisterNetEvent('wcc_fuel:requestStopRefuel', function(netId, reason)
    local src = source
    local session = sessions[src]
    if not session then return end

    sessions[src] = nil

    LogTransaction(session.identifier, session.stationId, session.stationName, session.plate, session.totalLiters, session.pricePerLiter, session.totalCost)

    if reason ~= 'full' then
        TriggerClientEvent('wcc_fuel:refuelComplete', src, session.totalLiters, session.totalCost)
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    local session = sessions[src]
    if session then
        LogTransaction(session.identifier, session.stationId, session.stationName, session.plate, session.totalLiters, session.pricePerLiter, session.totalCost)
        sessions[src] = nil
    end
end)

-- ------------------------------------------------------------
-- Kaufverlauf (letzte Tankvorgänge) für die Phone-App
-- ------------------------------------------------------------

function GetFuelHistoryForIdentifier(identifier, cb)
    if not identifier then cb({}) return end

    exports.oxmysql:query([[
        SELECT `station_name`, `liters`, `price_per_liter`, `total_cost`, `plate`, `timestamp`
        FROM `wcc_fuel_transactions`
        WHERE `identifier` = ?
        ORDER BY `timestamp` DESC
        LIMIT 50
    ]], { identifier }, function(rows)
        cb(rows or {})
    end)
end
