-- ============================================================
-- wcc_fuel - server/job.lua
-- Validiert Beladen (am Abholpunkt) und Abladen (an der eigenen
-- Tankstelle) des Trucking-Jobs. Merkt sich pro Spieler, ob und wie
-- viel gerade geladen ist (Server-Autorität, Client kann nichts fälschen).
-- ============================================================

-- src -> { stationId, pickupCoords, loaded (Liter), truckCapacity }
local activeJobs = {}

-- Fixes Kennzeichen, das client/job.lua dem gespawnten Miet-LKW gibt
-- (SetVehicleNumberPlateText(jobTruck, 'WCCFUEL')). Damit lässt sich
-- serverseitig verbindlich prüfen, dass wirklich im zugewiesenen Miet-LKW
-- gesessen wird (mit Anhänger) - nicht zu Fuß oder in einem beliebigen
-- eigenen Fahrzeug.
local JOB_TRUCK_PLATE = 'WCCFUEL'

-- Maximale Entfernung (Meter) zwischen LKW und Anhänger, wenn dieser NICHT
-- mehr direkt eingehakt ist (siehe IsInJobTruck) - z.B. nach hartem Bremsen
-- kurz abgekoppelt, aber noch "dabei".
local TRAILER_MAX_DISTANCE = 20.0

-- true, wenn src gerade als Fahrer im Miet-LKW sitzt (nur der LKW selbst
-- muss "im Punkt" sein, siehe client/job.lua) UND der Tankanhänger dabei
-- ist - entweder noch direkt eingehakt (Idealfall) ODER zumindest in
-- TRAILER_MAX_DISTANCE Metern Nähe zum LKW (z.B. kurz abgekoppelt).
local function IsInJobTruck(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end

    local veh = GetVehiclePedIsIn(ped, false)
    if not veh or veh == 0 then return false end
    if GetPedInVehicleSeat(veh, -1) ~= ped then return false end

    local plate = GetVehicleNumberPlateText(veh):gsub('%s+', '')
    if plate ~= JOB_TRUCK_PLATE then return false end

    -- GetVehicleTrailerVehicle ist eine CLIENT-ONLY Native (existiert
    -- serverseitig gar nicht - "attempt to call a nil value"), deshalb NUR
    -- über die Distanz zum nächsten Anhänger-Fahrzeug prüfen. Deckt sowohl
    -- "noch eingehakt" (Distanz dann ~0m) als auch "kurz abgekoppelt,
    -- aber noch in der Nähe" gleichermaßen ab.
    local truckCoords = GetEntityCoords(veh)
    local trailerModelHash = GetHashKey(Config.JobTrailerModel)
    local pool = GetGamePool('CVehicle')
    for _, v in ipairs(pool) do
        if v ~= veh and GetEntityModel(v) == trailerModelHash then
            if #(truckCoords - GetEntityCoords(v)) <= TRAILER_MAX_DISTANCE then
                return true
            end
        end
    end

    return false
end

-- Prüft, ob src nah genug an EINEM der beiden relevanten Punkte der Station
-- ist (Zapfsäule ODER der [E]-Marker vor dem Gebäude, siehe
-- cfg.buyMarkerCoords) - Job wird über den Marker gestartet/abgeladen, der
-- je nach Station mehrere Meter von der Zapfsäule entfernt stehen kann,
-- daher darf hier nicht mehr nur cfg.coords geprüft werden.
local function IsNearStation(src, cfg, radius)
    if IsPlayerNearCoords(src, cfg.coords, radius) then return true end
    if cfg.buyMarkerCoords and IsPlayerNearCoords(src, vector3(cfg.buyMarkerCoords.x, cfg.buyMarkerCoords.y, cfg.buyMarkerCoords.z), radius) then
        return true
    end
    return false
end

-- Prüft, ob der Spieler Besitzer ODER Mitarbeiter der Station ist.
local function CanWorkForStation(identifier, stationId)
    local s = WccFuel.Stations[stationId]
    if not s then return false end
    if s.ownerIdentifier == identifier then return true end

    local isEmployee = exports.oxmysql:scalarSync(
        'SELECT 1 FROM `wcc_fuel_employees` WHERE `station_id` = ? AND `identifier` = ? LIMIT 1',
        { stationId, identifier }
    )
    return isEmployee ~= nil
end

-- ------------------------------------------------------------
-- Bestimmt DYNAMISCH pro Station, welche 3 Abholpunkte ein Kommunikations-
-- Level bekommt: Config.JobPickupPoints ist ein flacher Pool aller Punkte
-- (nicht fest zugeordnet). Hier wird die Entfernung JEDES Punktes zur
-- übergebenen Station berechnet, absteigend sortiert (weiteste zuerst) und
-- in Dreiergruppen aufgeteilt - Level 1 (= kein Kommunikations-Upgrade)
-- bekommt IMMER die am weitesten entfernte Gruppe, jedes höhere Level
-- (Upgrade "Kommunikation" im Boss-Menü) eine näher gelegene. So passt
-- sich die "Weg-Distanz" automatisch an, WO die jeweilige Station auf der
-- Karte liegt (z.B. Station in Paleto -> Level 1 liegt für die tendenziell
-- im Süden/Hafen, Station am Würfelpark -> Level 1 tendenziell im Norden/
-- Paleto - jeweils das für GENAU DIESE Station am weitesten Entfernte).
-- Gibt es mehr Level als volle Dreiergruppen im Pool, bleiben die
-- obersten Level auf der nächstgelegenen Gruppe stehen (statt wie früher
-- fälschlich auf die allerweiteste zurückzufallen).
function GetJobPickupGroupForLevel(cfg, level)
    local stationCoords = vector3(cfg.coords.x, cfg.coords.y, cfg.coords.z)

    local pool = {}
    for _, p in ipairs(Config.JobPickupPoints) do
        local pointCoords = vector3(p.coords.x, p.coords.y, p.coords.z)
        pool[#pool + 1] = { coords = p.coords, label = p.label, dist = #(stationCoords - pointCoords) }
    end

    table.sort(pool, function(a, b) return a.dist > b.dist end) -- weiteste zuerst

    local numGroups = math.max(1, math.floor(#pool / 3))
    local groupIndex = math.min(math.max(1, level), numGroups)

    local startIdx = (groupIndex - 1) * 3 + 1
    local endIdx = math.min(#pool, groupIndex * 3)

    local group = {}
    for i = startIdx, endIdx do
        group[#group + 1] = { coords = pool[i].coords, label = pool[i].label }
    end

    return group
end

-- ------------------------------------------------------------
-- Job starten: prüft Berechtigung, merkt sich die Session
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:startJob', function(src, stationId)
    local s = WccFuel.Stations[stationId]
    if not s or not s.ownerIdentifier then
        return { ok = false, reason = 'Diese Tankstelle hat keinen Besitzer.' }
    end

    local identifier = GetIdentifier(src)
    if not CanWorkForStation(identifier, stationId) then
        return { ok = false, reason = 'Du arbeitest nicht für diese Tankstelle.' }
    end

    if activeJobs[src] then
        return { ok = false, reason = 'Du hast bereits einen laufenden Job.' }
    end

    -- Server-seitige Distanzprüfung (Marker-Interaktion in client/markers.lua
    -- ist rein UI-seitig, hier nochmal verbindlich gegen den Client-Trick
    -- abgesichert - "irgendwo" den Job anfordern reicht nicht).
    local cfg = Config.StationById[stationId]
    if not cfg or not IsNearStation(src, cfg, Config.MaxDistanceToPump + 10.0) then
        return { ok = false, reason = 'Du musst an deiner Tankstelle sein, um den Job zu starten.' }
    end

    -- WICHTIG: bewusst s.commsLevel (Kommunikations-Upgrade), NICHT
    -- s.level (Stations-/Tank-Level) - wie nah die Abholpunkte liegen,
    -- hängt jetzt ausschließlich vom separat upgradebaren Kommunikations-
    -- Level ab (Level 1/kein Upgrade = immer die 3 am weitesten
    -- entfernten Punkte).
    local points = GetJobPickupGroupForLevel(cfg, s.commsLevel)
    if #points == 0 then points = { Config.JobPickupPoints[1] } end -- sollte nie passieren, reiner Notanker
    local pickup = points[math.random(1, #points)]

    activeJobs[src] = {
        stationId = stationId,
        pickupCoords = vector3(pickup.coords.x, pickup.coords.y, pickup.coords.z),
        loaded = 0,
        truckCapacity = Config.TruckCapacityByLevel[s.truckLevel],
    }

    return { ok = true, pickup = { x = pickup.coords.x, y = pickup.coords.y, z = pickup.coords.z, w = pickup.coords.w, label = pickup.label } }
end)

-- ------------------------------------------------------------
-- Beladen am Abholpunkt
-- ------------------------------------------------------------

-- pcall-gewrappt: ein unerwarteter Laufzeitfehler hier würde sonst
-- KOMPLETT ohne Antwort an den Client bleiben - lib.callback.await gibt
-- dann nach dem Timeout nil zurück statt { ok = false, ... }, was clientseitig
-- zu "attempt to index a nil value" führte (siehe client/job.lua) und dabei
-- RemovePickupZone()/den Phasenwechsel im Missionstext nie erreichte -
-- Route/Text blieben für immer auf "Fahre zum Abholpunkt" hängen.
lib.callback.register('wcc_fuel:loadTruck', function(src)
    local ok, result = pcall(function()
        local job = activeJobs[src]
        if not job then return { ok = false, reason = 'Kein aktiver Job.' } end

        local near = IsPlayerNearCoords(src, job.pickupCoords, Config.JobMaxDistanceToPoint)
        if not near then
            return { ok = false, reason = 'Du bist nicht am Abholpunkt.' }
        end

        if not IsInJobTruck(src) then
            return { ok = false, reason = 'Du musst als Fahrer im Miet-LKW (mit Anhänger) sein, um zu beladen.' }
        end

        if job.loaded >= job.truckCapacity then
            return { ok = false, reason = 'Der LKW ist bereits voll beladen.' }
        end

        job.loaded = job.truckCapacity

        return { ok = true, loaded = job.loaded, capacity = job.truckCapacity }
    end)

    if not ok then
        print(('[wcc_fuel] Fehler in wcc_fuel:loadTruck (src=%s): %s'):format(src, tostring(result)))
        return { ok = false, reason = 'Interner Fehler beim Beladen (siehe Server-Konsole).' }
    end

    return result
end)

-- ------------------------------------------------------------
-- Abladen an der eigenen Tankstelle
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:unloadTruck', function(src)
    local job = activeJobs[src]
    if not job then return { ok = false, reason = 'Kein aktiver Job.' } end

    if job.loaded <= 0 then
        return { ok = false, reason = 'Der LKW ist leer, es gibt nichts abzuladen.' }
    end

    local cfg = Config.StationById[job.stationId]
    local s = WccFuel.Stations[job.stationId]
    if not cfg or not s then
        activeJobs[src] = nil
        return { ok = false, reason = 'Tankstelle nicht gefunden.' }
    end

    -- Abladepunkt ist jetzt der LKW-Spawnpunkt (jobTruckSpawnCoords), NICHT
    -- mehr der allgemeine Kauf-/Boss-Marker - der Spieler soll den Mietlkw
    -- dort abgeben, wo er ihn auch bekommen hat.
    local unloadCoords = (cfg.jobTruckSpawnCoords and (cfg.jobTruckSpawnCoords.x ~= 0.0 or cfg.jobTruckSpawnCoords.y ~= 0.0))
        and vector3(cfg.jobTruckSpawnCoords.x, cfg.jobTruckSpawnCoords.y, cfg.jobTruckSpawnCoords.z)
        or cfg.coords

    local near = IsPlayerNearCoords(src, unloadCoords, Config.MarkerInteractionDistance + 3.0)
    if not near then
        return { ok = false, reason = 'Du bist nicht am Mietlkw-Abgabepunkt.' }
    end

    if not IsInJobTruck(src) then
        return { ok = false, reason = 'Du musst als Fahrer im Miet-LKW (mit Anhänger) sein, um abzuladen.' }
    end

    local capacity = Config.StationTankCapacityByLevel[s.level]
    local space = capacity - s.tankLiters
    local pumped = math.min(job.loaded, space)

    s.tankLiters = s.tankLiters + pumped
    s.lastNonEmpty = os.time()
    job.loaded = job.loaded - pumped

    PersistStation(job.stationId)
    BroadcastStations()

    local finished = job.loaded <= 0
    if finished then
        activeJobs[src] = nil
    end

    return { ok = true, pumped = pumped, remaining = job.loaded, stationTank = s.tankLiters, stationCapacity = capacity, finished = finished }
end)

-- ------------------------------------------------------------
-- Miet-LKW/-Anhänger während eines laufenden Jobs zerstört/verschwunden:
-- Strafe aus der Tankstellen-Bank abziehen (NICHT vom Spieler - der Job
-- gehört der Station) und die Session beenden. Client meldet dies (er
-- erkennt Zerstörung/Nichtexistenz der Fahrzeuge lokal), hier läuft die
-- eigentliche, serverautoritative Verbuchung - Client kann den Betrag
-- nicht fälschen, da nur src (nicht der Betrag) vom Client kommt.
-- ------------------------------------------------------------

lib.callback.register('wcc_fuel:jobVehicleLost', function(src)
    local job = activeJobs[src]
    if not job then return { ok = false, reason = 'Kein aktiver Job.' } end

    local s = WccFuel.Stations[job.stationId]
    activeJobs[src] = nil

    if not s then
        return { ok = true, deducted = 0, newBank = 0, stationName = nil }
    end

    -- Nie mehr abziehen als aktuell in der Bank vorhanden ist - die Bank
    -- darf dadurch nicht negativ werden.
    local penalty = math.min(Config.JobVehicleLossPenalty, s.bank)
    s.bank = s.bank - penalty

    PersistStation(job.stationId)
    BroadcastStations()

    return { ok = true, deducted = penalty, newBank = s.bank, stationName = s.name }
end)

-- ------------------------------------------------------------
-- Job abbrechen (z.B. Fahrzeug zerstört/Spieler disconnected)
-- ------------------------------------------------------------

RegisterNetEvent('wcc_fuel:cancelJob', function()
    activeJobs[source] = nil
end)

AddEventHandler('playerDropped', function()
    activeJobs[source] = nil
end)
