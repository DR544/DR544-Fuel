# wcc_fuel

Tankstellen-Wirtschaftssystem für ESX Legacy: kompletter LegacyFuel-Ersatz
(Fahrzeug-Tankstand, Verbrauchssimulation) + käufliche, upgradbare
Tankstellen mit Besitz, Mitarbeitern, Trucking-Job und Tankstellen-Bank.

Baustil/Referenz: `wcc_chargingstations` (ESX Legacy, ox_lib, ox_target,
oxmysql, deutsche Kommentare).

## Abhängigkeiten

- `es_extended` (ESX Legacy)
- `ox_lib`
- `ox_target`
- `oxmysql`

## Installation

1. Ressourcenordner `wcc_fuel` in `resources/` kopieren.
2. `install.sql` in die Datenbank einspielen (optional - die Tabellen
   werden beim ersten Start auch automatisch per `oxmysql:execute`
   angelegt, siehe `server/main.lua`).
3. `ensure wcc_fuel` in der `server.cfg` **vor** allen HUD-/Fuel-
   abhängigen Ressourcen starten, falls andere Scripts `LegacyFuel`
   Events/Exports nutzen (Kompatibilitätsschicht, siehe unten).
4. Falls du bisher `LegacyFuel` selbst nutzt: `LegacyFuel` aus der
   `server.cfg` entfernen bzw. NICHT gleichzeitig mit `wcc_fuel` starten
   (beide würden sonst um den Tankstand konkurrieren).
5. `Config.GovernmentAccount` (Standard: `society_government`) prüfen und
   ggf. an deine ESX-Installation anpassen.

## Wichtigste Features

- **Fahrzeug-Tanken**: Tankstand 0-100%, RPM-/Speed-/Klassen-abhängiger
  Verbrauch (`client/main.lua`), Motor blockiert bei leerem Tank,
  Fahrzeug-Tankstand wird in `wcc_fuel_vehicles` (plate -> fuel)
  persistiert.
- **LegacyFuel-Kompatibilität**: `LegacyFuel:SetFuel` Event sowie
  `exports['LegacyFuel']:GetFuel/SetFuel` funktionieren weiterhin für
  andere Ressourcen (z.B. Fuel-HUDs), siehe `Config.EnableLegacyFuelCompat`.
  Eigene Exports: `exports['wcc_fuel']:GetFuel(veh)` /
  `exports['wcc_fuel']:SetFuel(veh, value)` (Client).
- **~30 Standard-GTA-Tankstellen** mit Blip. Tanken läuft über eine kleine
  Zapfpistolen-Prop + Rope-Mechanik (analog `wcc_chargingstations`), Kaufen/
  Boss-Menü/Job-Start/Abladen laufen über native `DrawMarker` + `[E]`.
  **`ox_target` wird in dieser Ressource ausschließlich noch für die
  Zapfpistole verwendet** (nehmen/zurückbringen/einstecken/abziehen).
- **Tanken (Prop/Rope/Live-Session)**: An jeder Station hängt eine kleine
  Zapfpistole (`Config.CableNozzleProp`, Vanilla-Prop, kein eigener Stream
  nötig) in einer Halterung an den Pumpen-Koordinaten. Sie wird mit ox_target
  genommen (`client/target.lua`), per Rope (`client/rope.lua`) an Hand/
  Fahrzeug gehängt und am Fahrzeug eingesteckt - danach startet server-
  seitig eine Live-Session (`server/fuel.lua`, `wcc_fuel:requestStartRefuel`),
  die alle `Config.RefuelBillingInterval` Sekunden abrechnet, den Tankstand
  DIREKT in der DB fortschreibt und per `wcc_fuel:refuelTickUpdate` an den
  Client meldet (3D-Text über dem Fahrzeug zeigt Liter/Preis/Kosten/
  Restzeit). Bei Stationen MIT Besitzer wird während des Tankens gleichzeitig
  der Stationstank geleert; läuft er leer, wird die Session sofort
  server-seitig beendet (`forceStopped`).
- **Kauf/Besitz**: Kaufpreis 200.000 - 400.000$ je Station (Lage-
  abhängig verteilt), max. 3 Stationen pro Spieler.
- **Level-System (max. 10)**: Tank-Kapazität 5.000L - 50.000L,
  Level-Up-Kosten 10.000$ - 150.000$ (gestaffelt), zahlbar aus der
  Tankstellen-Bank.
- **LKW-Level (separat, max. 10)**: Ladekapazität 1.000L - 7.500L,
  eigene Upgrade-Kostenkurve (5.000$ - 80.000$).
- **Tankstellen-Bank**: Einzahlung max. 30.000$ / 12h-Cooldown
  (serverseitig in der DB, nicht durch Reconnect umgehbar), Auszahlung
  frei (nur Besitzer).
- **Trucking-Job**: 3 Abholpunkte pro Level (30 gesamt), LKW (`packer`) +
  Tankanhänger (`tanker`) spawnen an der Station, Beladen (Marker + `[E]`
  am Abholpunkt) / Abladen (Marker + `[E]`/`[H]` an der Station) +
  Progressbar. Nutzbar von Besitzer UND Mitarbeitern.
- **Mitarbeiter**: max. 3 je Station, Lohn (0 = kein Lohn) wird alle 12h
  automatisch aus der Tankstellen-Bank ausgezahlt (online: direkt aufs
  ESX-Bankkonto, offline: direkt in der `users`-Tabelle gutgeschrieben).
- **Inaktivitäts-Refund**: Ist der Stationstank 3 Tage AM STÜCK leer (0
  Liter), wird die Station automatisch zurückgesetzt. Es zählt NUR der
  Tankstand, nicht die Online-Zeit des Besitzers.
- **Bezahlung beim Tanken**: Bei Stationen MIT Besitzer gehen 70% des
  Betrags in die Tankstellen-Bank, 30% Steuer an
  `Config.GovernmentAccount`. Ohne Besitzer gilt immer der
  Standardpreis, kein Spritmangel möglich.

## Getroffene Default-Entscheidungen (nicht explizit vorgegeben)

- **Society-Account für Steuer**: `society_government` (ESX-Standard).
  **PRÜFEN**: Manche Server nutzen einen abweichenden Namen - in
  `config.lua` (`Config.GovernmentAccount`) anpassen. Die Steuer wird
  aktuell direkt per `TriggerEvent('esx_addonaccount:getSharedAccount', ...)`
  gutgeschrieben (siehe `server/fuel.lua`) - falls dein Server
  `esx_addonaccount` nicht nutzt, hier anpassen.
- **Fahrzeug-Tankstand-Speicherung**: eigene Tabelle
  `wcc_fuel_vehicles` (plate -> fuel), da ESX Legacy `owned_vehicles`
  standardmäßig KEINE eigene `fuel`-Spalte besitzt. **PRÜFEN**: Falls
  dein Server bereits eine `fuel`-Spalte in `owned_vehicles` pflegt
  (z.B. durch ein anderes Fuel-Script), kannst du optional darauf
  umstellen (`server/fuel.lua`, `wcc_fuel:loadVehicleFuel` /
  `wcc_fuel:saveVehicleFuel`).
- **Tankstellen-Koordinaten**: ca. 30 realistische Näherungen an
  bekannte GTA-V-Tankstellen-Standorte (Strawberry, Route 68 (mehrfach),
  Sandy Shores, Grapeseed, Paleto Bay, LSIA, Vespucci, Rockford,
  Downtown, Vinewood Hills, Grand Senora Desert, Harmony, etc.). Die
  Koordinaten müssen laut Vorgabe nicht pixelgenau sein - vor
  Produktiveinsatz empfiehlt es sich, sie einmal im Spiel zu
  überprüfen/leicht zu justieren.
- **Kaufpreise**: zwischen 200.000$ (ländlich) und 400.000$ (LSIA,
  Rockford Hills - teure Stadtlagen), plausibel nach Lage gestaffelt.
- **Level-Up-Kostenkurve**: leicht progressiv gestaffelt zwischen
  10.000$ (Level 1->2) und 150.000$ (Level 9->10).
- **LKW-Upgrade-Kostenkurve**: 5.000$ - 80.000$, ca. halb so teuer wie
  die Stations-Level-Kurve (LKW-Kapazität ist ein "kleineres" Upgrade).
- **Inaktivitäts-Verhalten bei Verlust**: Bank-Guthaben der Station wird
  bei Verlust an den Ex-Besitzer ausgezahlt, SOFERN er zum Zeitpunkt des
  Checks online ist (direkt aufs ESX-Bankkonto). Ist er offline,
  verfällt der Restwert (kein Offline-Banking-System in ESX Legacy
  standardmäßig verfügbar) - siehe `server/stations.lua`,
  `RepossessStation`.
- **Job-Abholpunkte**: realistische Näherungen an Industrie-/Ölfeld-/
  Hafenarealen (Grand Senora, Sandy Shores Ölfelder, Paleto Industrie,
  Route 68 Raffinerie, Elysian Island, LS-Terminal, La Mesa, Davis
  Quartz, El Burro Heights, Vespucci Kanal), 3 pro Level, je höher das
  Stationslevel desto näher an zentraleren/günstigeren Punkten.
- **Verbrauchssimulation**: eigene, an LegacyFuel angelehnte (nicht
  kopierte) Berechnung aus RPM-Anteil + Geschwindigkeits-Faktor +
  Fahrzeugklassen-Multiplikator (`Config.FuelConsumptionClassMultiplier`).
- **Preis-/Mengen-Validierung**: ALLE kritischen Aktionen (Kauf,
  Einzahlung, Level-Up, Auszahlung, Tanken, Job-Abgabe) werden
  ausschließlich serverseitig berechnet/geprüft (Distanz-Check per
  `IsPlayerNearCoords`, Cooldowns/Beträge server-autoritativ) - dem
  Client wird an keiner Stelle vertraut.

## Wichtige Exporte (für die Phone-App `wcc_fuelmanager` bzw. andere Scripts)

- `exports['wcc_fuel']:GetStationsData()` - öffentliche Stationsliste
  (Name, Preis, Besitzstatus, Koordinaten).
- `exports['wcc_fuel']:GetFuelHistoryForIdentifier(identifier, cb)` -
  Tankverlauf.
- `exports['wcc_fuel']:GetMyStationsForIdentifier(identifier, cb)` -
  eigene Stationen inkl. Boss-Daten.
- `exports['wcc_fuel']:GetFuel(veh)` / `exports['wcc_fuel']:SetFuel(veh, value)`
  (Client) - LegacyFuel-kompatibel.

Boss-Menü-Aktionen laufen als `ox_lib`-Callbacks direkt gegen diese
Ressource (`wcc_fuel:buyStation`, `wcc_fuel:updateStationSettings`,
`wcc_fuel:levelUpStation`, `wcc_fuel:levelUpTruck`,
`wcc_fuel:depositBank`, `wcc_fuel:withdrawBank`, `wcc_fuel:getEmployees`,
`wcc_fuel:searchPlayers`, `wcc_fuel:addEmployee`,
`wcc_fuel:removeEmployee`, `wcc_fuel:setEmployeeWage`,
`wcc_fuel:startJob`, `wcc_fuel:loadTruck`, `wcc_fuel:unloadTruck`) - da
`ox_lib`-Callback-Namen global sind, kann jede andere Ressource
(insb. `wcc_fuelmanager`) sie direkt aufrufen, ohne Umweg über Exports.

## Kauf-Marker (`buyMarkerCoords`) - WICHTIG, bitte prüfen

Jede Station bekommt in `config.lua` automatisch ein
`cfg.buyMarkerCoords` (vec4) generiert, falls keins manuell gesetzt ist:
standardmäßig einfach `cfg.coords + (3, 3, 0)`, also ein grober Punkt
IRGENDWO neben der Zapfsäule - **nicht** zwangsläufig vor dem
Tankstellen-Shop/-Gebäude. Das ist bewusst nur ein Platzhalter. Bitte nach
dem ersten Start jede der ~30 Stationen einmal ingame besuchen und in
`Config.Stations` ein festes Feld ergänzen, z.B.:

```lua
{ id = 1, name = 'Route 68 Tankstelle', coords = vec3(...), blipCoords = vec3(...),
  buyPrice = 210000, buyMarkerCoords = vec4(49.9, 2780.1, 58.0, 160.0) },
```

Dort erscheint dann der `[E]`-Kauf-/Boss-/Job-Marker (siehe
`client/markers.lua`).

## Offene Punkte für den Betreiber (manuell prüfen)

1. `Config.GovernmentAccount` an die eigene ESX-Installation anpassen.
2. Prüfen, ob `owned_vehicles` bereits eine `fuel`-Spalte besitzt -
   falls ja, ggf. auf diese umstellen statt der eigenen
   `wcc_fuel_vehicles`-Tabelle.
3. Balancing (Preise, Kaufpreise, Level-Kosten, Verbrauchsrate) an den
   eigenen Server-Wirtschaftsmaßstab anpassen.
4. Tankstellen-Koordinaten im Spiel gegenprüfen/nachjustieren.
5. **`buyMarkerCoords` pro Station manuell vor das jeweilige
   Tankstellen-Gebäude verschieben** (siehe Abschnitt oben - Platzhalter-
   Default reicht nicht für den Produktivbetrieb).
6. `Config.CableNozzleProp` (Standard: `prop_cs_fuel_nozle`, Vanilla-Prop)
   ggf. gegen ein eigenes Streaming-Modell tauschen, falls gewünscht.
7. `Config.MaxFullTankSeconds` / `Config.RefuelBillingInterval` an die
   gewünschte Tankgeschwindigkeit/Abrechnungsgranularität anpassen.
8. `LegacyFuel` (falls installiert) deaktivieren, um Konflikte beim
   Fahrzeug-Tankstand zu vermeiden.
