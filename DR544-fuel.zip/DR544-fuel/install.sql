-- ============================================================
-- wcc_fuel - install.sql
-- Wird beim Ressourcenstart automatisch per oxmysql ausgeführt
-- (siehe server/main.lua), hier nur als Referenz/manuelles Setup.
-- ============================================================

-- Tankstellen: Besitz, Preis, Level, Bank, Blip-Konfig, Timestamps
CREATE TABLE IF NOT EXISTS `wcc_fuel_stations` (
  `station_id` INT NOT NULL PRIMARY KEY,
  `owner_identifier` VARCHAR(64) DEFAULT NULL,
  `name` VARCHAR(64) NOT NULL,
  `price` FLOAT NOT NULL DEFAULT 1.90,
  `level` TINYINT NOT NULL DEFAULT 1,
  `truck_level` TINYINT NOT NULL DEFAULT 1,
  `comms_level` TINYINT NOT NULL DEFAULT 1,
  `tank_liters` FLOAT NOT NULL DEFAULT 0,
  `bank` INT NOT NULL DEFAULT 0,
  `last_deposit` INT NOT NULL DEFAULT 0,
  `last_nonempty` INT NOT NULL DEFAULT 0,
  `blip_sprite` INT NOT NULL DEFAULT 361,
  `blip_color` INT NOT NULL DEFAULT 5,
  `wage_interval_hours` TINYINT NOT NULL DEFAULT 12,
  `last_wage_payout` INT NOT NULL DEFAULT 0,
  `created_at` INT NOT NULL DEFAULT 0
);

-- Mitarbeiter je Tankstelle
CREATE TABLE IF NOT EXISTS `wcc_fuel_employees` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `station_id` INT NOT NULL,
  `identifier` VARCHAR(64) NOT NULL,
  `name` VARCHAR(64) DEFAULT NULL,
  `wage` INT NOT NULL DEFAULT 0,
  `hired_at` INT NOT NULL DEFAULT 0,
  UNIQUE KEY `station_identifier` (`station_id`, `identifier`)
);

-- Fahrzeug-Tankstand (Ersatz für eine ggf. fehlende `fuel`-Spalte in
-- owned_vehicles). Nutzt das Kennzeichen (plate) als Schlüssel, analog zu
-- LegacyFuel. Falls dein Server bereits eine `fuel`-Spalte in
-- `owned_vehicles` pflegt, kann optional darauf umgestellt werden
-- (siehe README, Abschnitt "Fahrzeug-Tankstand-Speicherung").
CREATE TABLE IF NOT EXISTS `wcc_fuel_vehicles` (
  `plate` VARCHAR(16) NOT NULL PRIMARY KEY,
  `fuel` FLOAT NOT NULL DEFAULT 100.0,
  `updated_at` INT NOT NULL DEFAULT 0
);

-- Transaktions-Log (Tankvorgänge) - Kaufverlauf in der Phone-App +
-- Anti-Cheat-Nachvollziehbarkeit
CREATE TABLE IF NOT EXISTS `wcc_fuel_transactions` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `identifier` VARCHAR(64) NOT NULL,
  `station_id` INT DEFAULT NULL,
  `station_name` VARCHAR(64) DEFAULT NULL,
  `plate` VARCHAR(16) DEFAULT NULL,
  `liters` FLOAT NOT NULL,
  `price_per_liter` FLOAT NOT NULL,
  `total_cost` INT NOT NULL,
  `timestamp` INT NOT NULL
);

-- Lohn-Log (ausgezahlte Löhne je Mitarbeiter)
CREATE TABLE IF NOT EXISTS `wcc_fuel_wage_log` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `station_id` INT NOT NULL,
  `identifier` VARCHAR(64) NOT NULL,
  `amount` INT NOT NULL,
  `timestamp` INT NOT NULL
);
